/* =========================================================================
   TOBOROCHI · Backend standalone (capa de datos)
   ---------------------------------------------------------------------
   Esta es la "base de datos" de la versión standalone: reemplaza la
   capability "db" del Artifact de Claude por un almacén equivalente
   persistido en el propio navegador (localStorage), con la MISMA interfaz
   (doc/collection/get/set/add/delete/onSnapshot) que usa el resto de la
   aplicación (js/app.js) — así el resto del código no tuvo que cambiar.

   Qué significa esto en la práctica:
   - Los datos quedan guardados en ESTE navegador, en ESTA computadora.
     Abrir index.html en otra PC (o en otro navegador) arranca con los
     datos de referencia (js/database-seed.js), no con los que cargaste acá.
   - Borrar el historial/datos de navegación de este sitio borra la base.
   - No hay "compartido con el equipo" ni Comité en vivo: para eso conviene
     seguir usando el Artifact publicado en claude.ai (con backend en la
     nube), no esta versión.
   - Por eso, en esta versión standalone cualquiera que abra el archivo es
     tratado como editor (STATE.isAdmin = true): no hay control de acceso
     real, la única barrera es la contraseña propia del backoffice ("coco").
   ========================================================================= */

const TOBOROCHI_LOCAL_DB_KEY = "toborochi_dashboard_db_v1";

function makeLocalDb(storageKey){
  function load(){
    try{
      const raw = localStorage.getItem(storageKey);
      return raw ? JSON.parse(raw) : { meta:{}, cols:{} };
    }catch(e){ return { meta:{}, cols:{} }; }
  }
  function save(){
    try{ localStorage.setItem(storageKey, JSON.stringify(state)); }
    catch(e){ /* cuota de localStorage llena u otro error — los datos siguen disponibles en memoria durante esta sesión del navegador */ }
  }
  const state = load();
  state.meta = state.meta || {};
  state.cols = state.cols || {};
  const listeners = { meta:{}, cols:{} };

  function notifyDoc(path){
    (listeners.meta[path]||[]).forEach(cb=>{
      const exists = Object.prototype.hasOwnProperty.call(state.meta, path);
      cb({ exists, data: ()=>clone(state.meta[path]) });
    });
  }
  function notifyCol(name){
    (listeners.cols[name]||[]).forEach(cb=>{
      const items = state.cols[name] || {};
      const docs = Object.keys(items).map(id=>({ id, data: ()=>clone(items[id]) }));
      cb({ docs });
    });
  }
  function newId(){
    return "id" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }

  function docRef(path){
    return {
      async get(){
        const exists = Object.prototype.hasOwnProperty.call(state.meta, path);
        return { exists, data: ()=>clone(state.meta[path]) };
      },
      async set(data){
        state.meta[path] = clone(data);
        save();
        notifyDoc(path);
      },
      onSnapshot(cb){
        listeners.meta[path] = listeners.meta[path] || [];
        listeners.meta[path].push(cb);
        const exists = Object.prototype.hasOwnProperty.call(state.meta, path);
        cb({ exists, data: ()=>clone(state.meta[path]) });
        return ()=>{ listeners.meta[path] = (listeners.meta[path]||[]).filter(f=>f!==cb); };
      }
    };
  }
  function colRef(name){
    state.cols[name] = state.cols[name] || {};
    return {
      doc(id){
        return {
          async set(data){
            state.cols[name] = state.cols[name] || {};
            state.cols[name][id] = clone(data);
            save();
            notifyCol(name);
          },
          async delete(){
            if(state.cols[name]) delete state.cols[name][id];
            save();
            notifyCol(name);
          }
        };
      },
      async add(data){
        const id = newId();
        state.cols[name] = state.cols[name] || {};
        state.cols[name][id] = clone(data);
        save();
        notifyCol(name);
        return { id };
      },
      onSnapshot(cb){
        listeners.cols[name] = listeners.cols[name] || [];
        listeners.cols[name].push(cb);
        const items = state.cols[name] || {};
        cb({ docs: Object.keys(items).map(id=>({ id, data: ()=>clone(items[id]) })) });
        return ()=>{ listeners.cols[name] = (listeners.cols[name]||[]).filter(f=>f!==cb); };
      }
    };
  }

  return {
    doc(path){ return docRef(path); },
    collection(name){ return colRef(name); }
  };
}

async function initData(){
  let db = null;
  try{ db = makeLocalDb(TOBOROCHI_LOCAL_DB_KEY); }catch(e){ db = null; }
  STATE.db = db;

  if(!db){
    // localStorage no disponible (navegación privada muy restrictiva, cuota
    // agotada, etc.) — se degrada a modo demo de sólo lectura, igual que la
    // versión Artifact cuando no hay capability "db".
    STATE.offline = true;
    STATE.config = clone(SEED.config);
    Object.keys(STATE.collections).forEach(k=>{
      STATE.collections[k] = (SEED[k]||[]).map((d,i)=>({id:"seed-"+k+"-"+i, ...clone(d)}));
    });
    STATE.ready = true;
    render();
    return;
  }

  // Versión standalone: quien abre el archivo en su propio navegador ES el
  // editor — no hay usuarios de sólo lectura separados por permisos de
  // Artifact. El acceso de escritura al backoffice sigue protegido por su
  // propia contraseña ("coco"), independiente de esto.
  STATE.isAdmin = true;

  // Sembrado inicial si la base local todavía está vacía (primera vez que
  // se abre este archivo en este navegador).
  const cfgSnap = await db.doc("meta/config").get();
  if(!cfgSnap.exists){
    try{
      await db.doc("meta/config").set(SEED.config);
      for(const col of Object.keys(SEED)){
        if(col==="config") continue;
        for(const item of SEED[col]) await db.collection(col).add(item);
      }
      toast("Base de datos local inicializada con la información de referencia.");
    }catch(e){ /* no debería fallar en localStorage, pero por las dudas no se interrumpe el arranque */ }
  }

  // Config: doc único con snapshot "en vivo" (local, este navegador).
  db.doc("meta/config").onSnapshot(snap=>{
    STATE.config = snap.exists ? snap.data() : clone(SEED.config);
    STATE.ready = true;
    render();
  });

  // Colecciones: snapshot "en vivo" (local, este navegador).
  Object.keys(STATE.collections).forEach(col=>{
    db.collection(col).onSnapshot(qs=>{
      STATE.collections[col] = qs.docs.map(d=>({...d.data(), id:d.id}));
      render();
    });
  });
}

async function dbSet(col, id, data){
  if(!STATE.db){ toast("Modo demo: sin conexión a la base de datos.", true); return; }
  try{
    const before = id ? (STATE.collections[col]||[]).find(i=>i.id===id) : null;
    if(id) await STATE.db.collection(col).doc(id).set(data);
    else await STATE.db.collection(col).add(data);
    logAudit(before ? "edicion" : "alta", col, id, diffFields(before, data));
    toast("Guardado.");
  }catch(e){ toast("No se pudo guardar (" + (e.code||"error") + ").", true); }
}
async function dbDelete(col, id){
  if(!STATE.db){ toast("Modo demo: sin conexión a la base de datos.", true); return; }
  try{
    const before = (STATE.collections[col]||[]).find(i=>i.id===id);
    await STATE.db.collection(col).doc(id).delete();
    logAudit("eliminacion", col, id, diffFields(before, null));
    toast("Eliminado.");
  }
  catch(e){ toast("No se pudo eliminar.", true); }
}
async function dbSetConfig(data){
  if(!STATE.db){ toast("Modo demo: sin conexión a la base de datos.", true); return; }
  try{
    const before = STATE.config;
    await STATE.db.doc("meta/config").set({...STATE.config, ...data, fechaActualizacion: todayISO()});
    logAudit("edicion", "config", null, diffFieldsPartial(before, data));
    toast("Configuración actualizada.");
  }
  catch(e){ toast("No se pudo guardar la configuración.", true); }
}

/* ---------------------------------------------------------------------
   REGISTRO DE EDICIONES (auditoría) — cada alta/edición/eliminación hecha
   desde el backoffice (incluida la configuración general) queda registrada
   con quién, cuándo, y qué campos cambiaron. Se guarda en su propia
   colección ("auditoria"), visible en el backoffice en modo solo lectura.
--------------------------------------------------------------------- */
function diffFields(before, after){
  const out = [];
  const keys = new Set([...Object.keys(before||{}), ...Object.keys(after||{})]);
  keys.forEach(k=>{
    if(k==="id") return;
    const a = before ? before[k] : undefined;
    const b = after ? after[k] : undefined;
    const av = JSON.stringify(a===undefined?null:a);
    const bv = JSON.stringify(b===undefined?null:b);
    if(av !== bv) out.push({ campo:k, anterior:(a===undefined||a===null||a==="")?"—":a, nuevo:(b===undefined||b===null||b==="")?"—":b });
  });
  return out;
}
function diffFieldsPartial(before, patch){
  const out = [];
  Object.keys(patch||{}).forEach(k=>{
    if(k==="fechaActualizacion") return;
    const a = before ? before[k] : undefined;
    const b = patch[k];
    const av = JSON.stringify(a===undefined?null:a);
    const bv = JSON.stringify(b===undefined?null:b);
    if(av !== bv) out.push({ campo:k, anterior:(a===undefined||a===null||a==="")?"—":a, nuevo:(b===undefined||b===null||b==="")?"—":b });
  });
  return out;
}
async function logAudit(tipo, col, id, cambios){
  if(!STATE.db || col==="auditoria" || !cambios || !cambios.length) return;
  try{
    await STATE.db.collection("auditoria").add({
      fecha: new Date().toISOString(),
      coleccion: col,
      docId: id || null,
      tipo,
      cambios,
      usuario: (typeof ROLE_LABELS!=="undefined" && ROLE_LABELS[STATE.role]) || STATE.role || "—"
    });
  }catch(e){ /* un fallo al auditar no debe interrumpir el guardado principal */ }
}
