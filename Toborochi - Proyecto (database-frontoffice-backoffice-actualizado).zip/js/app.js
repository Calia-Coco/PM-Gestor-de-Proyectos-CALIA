/* =========================================================================
   TOBOROCHI · Dashboard Ejecutivo + Backoffice (front-end)
   Persistencia: js/backend.js (base local en localStorage — ver ese
   archivo). Si el navegador no soporta localStorage, se degrada a modo
   demo de sólo lectura con los datos de referencia de database-seed.js.
   ========================================================================= */


const ICONS = {
  resumen:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
  cronograma:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 3v3M16 3v3"/><path d="M7 13h5M7 17h3"/></svg>',
  presupuesto:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 20V10M9 20V4M15 20v-7M21 20V8"/></svg>',
  riesgos:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4M12 17h.01"/></svg>',
  problemas:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg>',
  cambios:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h11l-3-3M20 17H9l3 3"/></svg>',
  decisiones:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h11"/></svg>',
  hitos:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 3v18M5 4h11l-2 3 2 3H5"/></svg>',
  minutas:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M9 13h6M9 17h6"/></svg>',
  backoffice:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 0 1-4 0v-.09A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.55-1H3a2 2 0 0 1 0-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.55V3a2 2 0 0 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9a1.7 1.7 0 0 0 1.55 1H21a2 2 0 0 1 0 4h-.09a1.7 1.7 0 0 0-1.55 1z"/></svg>',
  grid:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/></svg>',
  edt:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="2" width="6" height="5" rx="1.3"/><rect x="2" y="16" width="6" height="5" rx="1.3"/><rect x="16" y="16" width="6" height="5" rx="1.3"/><path d="M12 7v4M12 11H5v5M12 11h7v5"/></svg>',
  equipo:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c.6-3.4 3.2-5.5 6.5-5.5s5.9 2.1 6.5 5.5"/><circle cx="18" cy="7" r="2.4"/><path d="M15.7 14.3c2.6.4 4.4 2.2 4.8 4.7"/></svg>',
};

/* ---------------------------------------------------------------------
   1) DATOS SEMILLA — construidos a partir del Kick Off (19/08/2026) y el
   Acta de Comité (31/08/2026). Se usan (a) para inicializar la base de
   datos la primera vez que alguien con permisos de edición abre el panel,
   y (b) como demo de sólo lectura si la capacidad "db" no está disponible.
   Cifras de presupuesto/contratos se dejan en null: no estaban definidas
   en el material fuente (ver "Supuestos" en el backoffice → Config).
--------------------------------------------------------------------- */

// SEED = snapshot congelado de la base de datos EN VIVO del Artifact al
// 07/09/2026 (incluye avanceFisicoPct=7, desviacionCronograma, R-60, los
// 45 registros de gantt de la ronda 3, etc.). Se usa como fallback offline
// (sin capability db, p.ej. este archivo .html abierto localmente) y para
// re-sembrar una base vacía. Actualizar manualmente si la base en vivo cambia.

/* ---------------------------------------------------------------------
   2) ESQUEMAS del backoffice — describen los formularios genéricos de
   alta/edición para cada colección.
--------------------------------------------------------------------- */

const RAG_OPTS = [["verde","Verde"],["amarillo","Ámbar"],["rojo","Rojo"],["gris","Sin iniciar"]];
const SCHEMAS = {
  frentes: {
    label:"Frentes de trabajo (EDT)", icon:"resumen", cols:["codigo","nombre","semaforo","avancePct"],
    fields:[
      {key:"codigo", label:"Código EDT", type:"text", hint:"Ej. F1 — usado para vincular tareas y riesgos a este frente."},
      {key:"orden", label:"Orden", type:"number"},
      {key:"nombre", label:"Frente / dimensión", type:"text", full:true},
      {key:"semaforo", label:"Semáforo", type:"select", options:RAG_OPTS},
      {key:"avancePct", label:"Avance físico (%)", type:"number"},
      {key:"comentario", label:"Comentario ejecutivo", type:"textline", full:true},
      {key:"presupuestoPlan", label:"Presupuesto planificado (USD)", type:"number", hint:"Déjalo vacío si aún no está consolidado — se mostrará como “sin datos” en vez de inventar una cifra."},
      {key:"costoReal", label:"Costo real a la fecha (USD)", type:"number"},
    ],
  },
  gantt: {
    label:"Cronograma (Gantt)", icon:"cronograma", cols:["nombre","fase","frenteCodigo","inicioPlan","finPlan","avance","estado"],
    fields:[
      {key:"nombre", label:"Tarea / entregable", type:"text", full:true},
      {key:"fase", label:"Fase", type:"text"},
      {key:"frenteCodigo", label:"Frente EDT (código)", type:"text", hint:"Código del frente al que pertenece (F1–F6). Ver Backoffice → Frentes."},
      {key:"responsable", label:"Responsable", type:"text"},
      {key:"inicioPlan", label:"Inicio plan", type:"date"},
      {key:"finPlan", label:"Fin plan", type:"date"},
      {key:"inicioReal", label:"Inicio real", type:"date"},
      {key:"finReal", label:"Fin real", type:"date"},
      {key:"avance", label:"Avance (%)", type:"number"},
      {key:"estado", label:"Estado", type:"select", options:[["pendiente","Pendiente"],["en_curso","En curso"],["completado","Completado"],["en_riesgo","En riesgo"]]},
      {key:"dependencias", label:"Depende de (tareas predecesoras)", type:"tags", full:true, hint:"Una por línea, con el nombre EXACTO de la tarea predecesora (tal como aparece en “Tarea / entregable”). Se dibuja como flecha en el Gantt. Déjalo vacío si no se conoce la dependencia real — no se debe inventar."},
      {key:"riesgoId", label:"Riesgo asociado (código)", type:"text", hint:"Código del riesgo que justifica el atraso de esta tarea (ver pestaña Riesgos, ej. AG-01). Sólo se usa cuando la tarea muestra bandera de atraso."},
    ],
  },
  riesgos: {
    label:"Riesgos", icon:"riesgos", cols:["codigo","descripcion","probabilidad","impacto","estado"],
    fields:[
      {key:"codigo", label:"Código", type:"text"},
      {key:"frenteCodigo", label:"Frente EDT (código)", type:"text", hint:"Sólo cuando el grupo del riesgo corresponde claramente a un frente (F1–F6). Déjalo vacío antes que forzar una relación dudosa."},
      {key:"categoria", label:"Categoría / grupo", type:"text"},
      {key:"descripcion", label:"Descripción del riesgo", type:"textline", full:true},
      {key:"probabilidad", label:"Probabilidad (1 Baja–3 Alta)", type:"select", options:[[1,"1 · Baja"],[2,"2 · Media"],[3,"3 · Alta"]]},
      {key:"impacto", label:"Impacto (1 Bajo–3 Alto)", type:"select", options:[[1,"1 · Bajo"],[2,"2 · Medio"],[3,"3 · Alto"]]},
      {key:"disparador", label:"Causa principal / disparador", type:"textline", full:true},
      {key:"impactoNegocio", label:"Impacto en el negocio", type:"textline", full:true},
      {key:"estrategia", label:"Estrategia de respuesta", type:"select", options:[["Evitar","Evitar"],["Mitigar","Mitigar"],["Transferir","Transferir"],["Aceptar","Aceptar"],["Transferir / Aceptar con seguimiento","Transferir / Aceptar con seguimiento"]]},
      {key:"plan", label:"Plan de mitigación / contingencia", type:"textline", full:true},
      {key:"responsable", label:"Líder del plan", type:"text"},
      {key:"equipoResponsable", label:"Equipo responsable", type:"text", full:true},
      {key:"proveedores", label:"Proveedores involucrados", type:"text"},
      {key:"identificadoPor", label:"Identificado por", type:"text"},
      {key:"fechaLimite", label:"Fecha límite del plan", type:"date"},
      {key:"etapa", label:"Etapa de ejecución del plan", type:"select", options:[["","—"],["Elaboración de la Estrategia","Elaboración de la Estrategia"],["Primer y Segundo Upgrade Técnico","Primer y Segundo Upgrade Técnico"],["Migración Final","Migración Final"],["Soporte Post Producción","Soporte Post Producción"],["Cierre","Cierre"]]},
      {key:"estado", label:"Estado", type:"select", options:[["identificado","Identificado"],["en_evaluacion","En evaluación"],["planificado","Planificado"],["en_seguimiento","En seguimiento"],["mitigado","Mitigado"],["materializado","Materializado"],["cerrado","Cerrado"],["cancelado","Cancelado"]]},
      {key:"observacionesGSE", label:"Observaciones GSE", type:"textline", full:true},
      {key:"accionObservacion", label:"Acción a la observación", type:"textline", full:true},
      {key:"esTop", label:"Riesgo TOP", type:"select", options:[[true,"Sí"],[false,"No"]]},
    ],
  },
  problemas: {
    label:"Problemas / bloqueos", icon:"problemas", cols:["alertaRoja","codigo","descripcion","escalamiento","estado"],
    fields:[
      {key:"codigo", label:"Código", type:"text"},
      {key:"frenteCodigo", label:"Frente EDT (código)", type:"text"},
      {key:"descripcion", label:"Descripción", type:"textline", full:true},
      {key:"impacto", label:"Impacto si no se resuelve", type:"textline", full:true},
      {key:"origen", label:"Origen / frente", type:"text"},
      {key:"responsable", label:"Responsable", type:"text"},
      {key:"decisionRequerida", label:"Decisión / acción requerida", type:"textline", full:true},
      {key:"escalamiento", label:"Nivel de escalamiento", type:"text"},
      {key:"estado", label:"Estado", type:"select", options:[["abierto","Abierto"],["en_curso","En curso"],["resuelto","Resuelto"]]},
      {key:"fechaApertura", label:"Fecha de apertura", type:"date"},
      {key:"resolucion", label:"Resolución", type:"textline", full:true, hint:"Qué se hizo (o se va a hacer) para cerrar este problema."},
      {key:"alertaRoja", label:"Marcar con bandera roja (alerta de escalación urgente)", type:"checkbox", full:true, hint:"Actívala para que este problema se destaque como alerta crítica en la vista ejecutiva. Desmárcala cuando deje de requerir escalación urgente."},
      {key:"actualizaciones", label:"Historial de actualizaciones — una por línea: fecha (AAAA-MM-DD) | autor | nota", type:"updates", full:true},
    ],
  },
  cambios: {
    label:"Control de cambios", icon:"cambios", cols:["codigo","descripcion","estado"],
    fields:[
      {key:"codigo", label:"Código", type:"text"},
      {key:"descripcion", label:"Descripción del cambio", type:"textline", full:true},
      {key:"tipoImpacto", label:"Impacta a (alcance, costo, cronograma)", type:"tags", full:true},
      {key:"analisis", label:"Análisis de impacto", type:"textline", full:true},
      {key:"solicitante", label:"Solicitante", type:"text"},
      {key:"fechaSolicitud", label:"Fecha de solicitud", type:"date"},
      {key:"estado", label:"Estado", type:"select", options:[["propuesto","Propuesto"],["en_evaluacion","En evaluación"],["aprobado","Aprobado"],["rechazado","Rechazado"]]},
    ],
  },
  decisiones: {
    label:"Decisiones del Comité", icon:"decisiones", cols:["codigo","tema","fechaLimite","estado"],
    fields:[
      {key:"codigo", label:"Código", type:"text"},
      {key:"tema", label:"Tema", type:"text", full:true},
      {key:"contexto", label:"Contexto", type:"textline", full:true},
      {key:"opciones", label:"Opciones (una por línea)", type:"tags", full:true},
      {key:"recomendacion", label:"Recomendación del PM", type:"textline", full:true},
      {key:"resultadoEsperado", label:"Resultado esperado", type:"textline", full:true},
      {key:"fechaLimite", label:"Fecha límite de decisión", type:"date"},
      {key:"responsableDecision", label:"Quién decide", type:"text"},
      {key:"estado", label:"Estado", type:"select", options:[["pendiente","Pendiente"],["tomada","Tomada"]]},
      {key:"decisionTomada", label:"Decisión tomada (si aplica)", type:"textline", full:true},
    ],
  },
  hitos: {
    label:"Hitos", icon:"hitos", cols:["nombre","fecha","estado"],
    fields:[
      {key:"nombre", label:"Hito", type:"text", full:true},
      {key:"fecha", label:"Fecha", type:"date"},
      {key:"estado", label:"Estado", type:"select", options:[["pendiente","Pendiente"],["en_curso","En curso"],["completado","Completado"],["en_riesgo","En riesgo"]]},
    ],
  },
  contratos: {
    label:"Contratos", icon:"presupuesto", cols:["proveedor","numeroContrato","monto","estado"],
    fields:[
      {key:"proveedor", label:"Proveedor", type:"text"},
      {key:"numeroContrato", label:"N° de contrato", type:"text"},
      {key:"alcance", label:"Alcance contratado", type:"textline", full:true},
      {key:"monto", label:"Monto contrato (USD)", type:"number"},
      {key:"montoEjecutado", label:"Monto ejecutado (USD)", type:"number"},
      {key:"modalidadPago", label:"Modalidad de pago", type:"text"},
      {key:"estado", label:"Estado", type:"select", options:[["activo","Activo"],["pendiente_firma","Pendiente de firma"],["cerrado","Cerrado"]]},
      {key:"notaRiesgoProveedor", label:"Nota de riesgo del proveedor (para evaluar riesgos de cronograma)", type:"textline", full:true},
    ],
  },
  minutas: {
    label:"Minutas de Comité", icon:"minutas", cols:["fecha","tema"],
    fields:[
      {key:"fecha", label:"Fecha de la sesión", type:"date"},
      {key:"tema", label:"Tema de la sesión", type:"text", full:true},
      {key:"participantes", label:"Participantes (uno por línea)", type:"tags", full:true},
      {key:"decisiones", label:"Decisiones (una por línea)", type:"tags", full:true},
      {key:"recomendaciones", label:"Recomendaciones (una por línea)", type:"tags", full:true},
      {key:"acciones", label:"Acciones — una por línea: acción | responsable | fecha", type:"actions3", full:true},
    ],
  },
};

/* ---------------------------------------------------------------------
   3) ESTADO EN MEMORIA + CAPA DE DATOS
--------------------------------------------------------------------- */
const STATE = {
  ready:false,
  db:null,
  isAdmin:false,
  offline:false,
  backofficeUnlocked: (()=>{ try{ return sessionStorage.getItem("toborochi_backoffice_unlocked")==="1"; }catch(e){ return false; } })(),
  role:null, // "comite" | "pmo" | "tecnico" — elegido en el login, gatea NAV y las vistas.
  route:"resumen",
  config: SEED.config,
  collections: { frentes:[], gantt:[], riesgos:[], problemas:[], cambios:[], decisiones:[], hitos:[], contratos:[], minutas:[], auditoria:[] },
};

/* ---------------------------------------------------------------------
   LOGIN POR ROL — filtro simple del lado del cliente (no es autenticación
   real; las 3 contraseñas quedan visibles en el código fuente). Sirve
   sólo para separar qué ve cada audiencia (Comité / PMO / Equipo Técnico).
--------------------------------------------------------------------- */
const ROLE_PASSWORDS = { comite:"toborochi", pmo:"proyectos", tecnico:"1234" };
const ROLE_LABELS = { comite:"Comité Ejecutivo", pmo:"PMO Integrada", tecnico:"Equipo Técnico" };
const ROLE_DEFAULT_ROUTE = { comite:"resumen", pmo:"pmo-estado", tecnico:"tec-resumen" };
let pendingRole = null;

function showApp(role){
  STATE.role = role;
  try{ sessionStorage.setItem("toborochi_role", role); }catch(e){}
  document.getElementById("loginScreen").hidden = true;
  document.getElementById("app").hidden = false;
  const sub = document.querySelector("#sidebar .brand .sub");
  if(sub) sub.textContent = ROLE_LABELS[role];
  STATE.route = ROLE_DEFAULT_ROUTE[role];
  location.hash = STATE.route;
  render();
  resetIdleTimer();
}
function showLogin(auto){
  STATE.role = null;
  try{ sessionStorage.removeItem("toborochi_role"); }catch(e){}
  document.getElementById("app").hidden = true;
  document.getElementById("loginScreen").hidden = false;
  pendingRole = null;
  document.getElementById("loginRoles").hidden = false;
  document.getElementById("loginPassForm").hidden = true;
  const inp = document.getElementById("loginPassInput");
  if(inp) inp.value = "";
  const err = document.getElementById("loginError");
  if(err) err.hidden = true;
  if(idleTimer){ clearTimeout(idleTimer); idleTimer = null; }
  if(auto) toast("Sesión cerrada por inactividad (2 min).");
}

/* ---------------------------------------------------------------------
   CIERRE DE SESIÓN POR INACTIVIDAD — sin interacción durante 2 minutos,
   vuelve sola a la pantalla de login. No es una medida de seguridad real
   (las contraseñas son un filtro simple, ver arriba); sirve para que un
   tablero abierto en una pantalla compartida (p.ej. en una sala del
   Comité) no quede expuesto indefinidamente.
--------------------------------------------------------------------- */
const IDLE_TIMEOUT_MS = 2*60*1000;
let idleTimer = null;
function resetIdleTimer(){
  if(idleTimer){ clearTimeout(idleTimer); idleTimer = null; }
  if(!STATE.role) return; // nada que cerrar si ya está en el login
  idleTimer = setTimeout(()=>{ if(STATE.role) showLogin(true); }, IDLE_TIMEOUT_MS);
}
["mousemove","mousedown","keydown","scroll","touchstart","click","input"].forEach(evt=>{
  document.addEventListener(evt, resetIdleTimer, {passive:true});
});
function initLogin(){
  const logo = document.querySelector(".topbar-logo");
  const loginLogo = document.getElementById("loginLogoToborochi");
  if(logo && loginLogo) loginLogo.src = logo.src;

  document.querySelectorAll(".role-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      pendingRole = btn.dataset.role;
      document.getElementById("loginRoles").hidden = true;
      document.getElementById("loginPassForm").hidden = false;
      document.getElementById("loginPassRole").textContent = ROLE_LABELS[pendingRole];
      document.getElementById("loginError").hidden = true;
      const inp = document.getElementById("loginPassInput");
      inp.value = "";
      inp.focus();
    });
  });
  document.getElementById("loginBack").addEventListener("click", ()=>{
    pendingRole = null;
    document.getElementById("loginRoles").hidden = false;
    document.getElementById("loginPassForm").hidden = true;
  });
  document.getElementById("loginPassForm").addEventListener("submit", (e)=>{
    e.preventDefault();
    if(!pendingRole) return;
    const val = document.getElementById("loginPassInput").value;
    if(val === ROLE_PASSWORDS[pendingRole]){
      showApp(pendingRole);
    } else {
      const err = document.getElementById("loginError");
      err.hidden = false;
      const card = document.querySelector(".login-card");
      card.classList.remove("role-shake"); void card.offsetWidth; card.classList.add("role-shake");
      document.getElementById("loginPassInput").focus();
    }
  });

  // Restaurar el rol si ya se había elegido en esta pestaña (conveniencia
  // por visor, no es una sesión persistente entre dispositivos).
  let savedRole = null;
  try{ savedRole = sessionStorage.getItem("toborochi_role"); }catch(e){}
  if(savedRole && ROLE_PASSWORDS[savedRole]){
    STATE.role = savedRole;
    document.getElementById("loginScreen").hidden = true;
    document.getElementById("app").hidden = false;
    const sub = document.querySelector("#sidebar .brand .sub");
    if(sub) sub.textContent = ROLE_LABELS[savedRole];
    resetIdleTimer();
  }
}

const clone = (x) => JSON.parse(JSON.stringify(x));
const uid = () => Math.random().toString(36).slice(2,10);


/* ---------------------------------------------------------------------
   UTILIDADES COMPARTIDAS — formato de fecha/monto y notificaciones toast.
--------------------------------------------------------------------- */
const fmtDate = (s) => { if(!s) return "—"; const d=new Date(s+"T00:00:00"); if(isNaN(d)) return s; return d.toLocaleDateString("es-BO",{day:"2-digit",month:"short",year:"numeric"}); };
const fmtMoney = (n,cur) => { if(n===null||n===undefined||n==="") return "Por definir"; return new Intl.NumberFormat("es-BO",{style:"currency",currency:cur||"USD",maximumFractionDigits:0}).format(n); };
const daysBetween = (a,b) => Math.round((new Date(b)-new Date(a))/86400000);

/* Aviso de "dato desactualizado" — los KPIs ejecutivos (avance físico,
   desviación de cronograma) son overrides que confirma el PM, no un
   cálculo automático; nunca se recalculan solos. Lo único que sí es
   automático es avisar cuando pasó mucho tiempo desde la última vez que
   el PM los confirmó, para que sepa que conviene revisarlos en Backoffice
   contra el avance real del cronograma. */
function diasDesdeActualizacion(fechaISO){
  if(!fechaISO) return null;
  return daysBetween(fechaISO, todayISO());
}
function staleBadgeHTML(fechaISO, umbral){
  const dias = diasDesdeActualizacion(fechaISO);
  if(dias===null || dias<(umbral||7)) return "";
  return `<span class="chip amarillo" title="Los KPIs ejecutivos (avance físico, desviación de cronograma) no se recalculan solos — hace ${dias} días que no se confirman contra el avance real del cronograma. Revisar en Backoffice → Configuración general." style="margin-left:8px;">⚠ Revisar avance — hace ${dias} días</span>`;
}
const todayISO = () => new Date().toISOString().slice(0,10);

function toast(msg, isErr){
  const t = document.createElement("div");
  t.className = "toast" + (isErr?" err":"");
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>{ t.style.opacity="0"; t.style.transform="translateY(6px)"; }, 2200);
  setTimeout(()=>t.remove(), 2500);
}

/* ---------------------------------------------------------------------
   4) NAVEGACIÓN
--------------------------------------------------------------------- */

const NAV_COMITE = [
  {group:"Vista ejecutiva", items:[
    {id:"resumen", label:"Resumen ejecutivo", icon:"resumen"},
    {id:"edt", label:"Estructura del proyecto (EDT)", icon:"resumen"},
    {id:"cronograma", label:"Cronograma", icon:"cronograma"},
    {id:"riesgos", label:"Mapa de riesgos", icon:"riesgos"},
    {id:"presupuesto", label:"Presupuesto y contratos", icon:"presupuesto"},
    {id:"problemas", label:"Problemas y bloqueos", icon:"problemas"},
    {id:"decisiones", label:"Decisiones del Comité", icon:"decisiones"},
    {id:"hitos", label:"Próximos hitos", icon:"hitos"},
    {id:"minutas", label:"Bitácora de Comité", icon:"minutas"},
  ]},
  {group:"Administración", items:[
    {id:"backoffice", label:"Backoffice", icon:"backoffice"},
  ]},
];
const NAV_PMO = [
  {group:"PMO Integrada", items:[
    {id:"pmo-estado", label:"Estado del proyecto", icon:"resumen"},
    {id:"pmo-dominios", label:"8 Dominios de desempeño", icon:"grid"},
  ]},
];
const NAV_TECNICO = [
  {group:"Equipo Técnico", items:[
    {id:"tec-resumen", label:"Datos generales", icon:"resumen"},
    {id:"tec-cronograma", label:"Cronograma", icon:"cronograma"},
    {id:"tec-gantt-persona", label:"Gantt por persona", icon:"equipo"},
    {id:"tec-edt", label:"EDT gráfico", icon:"edt"},
    {id:"tec-riesgos", label:"Riesgos del equipo técnico", icon:"riesgos"},
    {id:"tec-bitacora", label:"Bitácora — planning de lunes", icon:"minutas"},
    {id:"tec-proximos", label:"Próximos pasos (actas)", icon:"hitos"},
  ]},
];
function getNav(){ return {comite:NAV_COMITE, pmo:NAV_PMO, tecnico:NAV_TECNICO}[STATE.role] || NAV_COMITE; }

function closeMobileMenu(){
  const sb = document.getElementById("sidebar");
  const bd = document.getElementById("sidebarBackdrop");
  const btn = document.getElementById("menuBtn");
  if(sb) sb.classList.remove("open");
  if(bd) bd.classList.remove("show");
  if(btn){ btn.textContent = "☰"; btn.setAttribute("aria-expanded","false"); }
}
function toggleMobileMenu(){
  const sb = document.getElementById("sidebar");
  const bd = document.getElementById("sidebarBackdrop");
  const btn = document.getElementById("menuBtn");
  const opening = !sb.classList.contains("open");
  sb.classList.toggle("open", opening);
  if(bd) bd.classList.toggle("show", opening);
  if(btn){ btn.textContent = opening ? "✕" : "☰"; btn.setAttribute("aria-expanded", opening ? "true" : "false"); }
}
document.getElementById("menuBtn").addEventListener("click", toggleMobileMenu);
document.getElementById("sidebarBackdrop").addEventListener("click", closeMobileMenu);
function setRoute(r){ STATE.route = r; location.hash = r; render(); window.scrollTo(0,0); closeMobileMenu(); }
window.addEventListener("hashchange", ()=>{ if(!STATE.role) return; const r=location.hash.replace("#",""); if(r){ STATE.route=r; render(); } });
function routeBase(r){ return (r||"resumen").split(":")[0]; }
function routeParam(r){ const i=(r||"").indexOf(":"); return i===-1?null:r.slice(i+1); }

function renderNav(){
  const el = document.getElementById("navPrimary");
  el.innerHTML = getNav().map(g=>`
    <div class="navgroup-label">${g.group}</div>
    ${g.items.map(it=>{
      if(it.id==="backoffice" && !STATE.isAdmin && !STATE.offline) return "";
      let count = "";
      if(it.id==="riesgos") count = STATE.collections.riesgos.filter(r=>r.esTop).length;
      if(it.id==="problemas") count = STATE.collections.problemas.filter(p=>p.estado!=="resuelto").length;
      if(it.id==="decisiones") count = STATE.collections.decisiones.filter(d=>d.estado==="pendiente").length;
      const hot = (it.id==="decisiones" && count>0) || (it.id==="problemas" && count>0);
      return `<button class="navitem ${routeBase(STATE.route)===it.id?'active':''}" data-route="${it.id}">${ICONS[it.icon]}<span>${it.label}</span>${count!==""?`<span class="count ${hot?'hot':''}">${count}</span>`:""}</button>`;
    }).join("")}
  `).join("");
  el.querySelectorAll("[data-route]").forEach(b=>b.addEventListener("click", ()=>setRoute(b.dataset.route)));

  const pill = document.getElementById("accessPill");
  const title = document.getElementById("accessTitle");
  const desc = document.getElementById("accessDesc");
  const roleLbl = ROLE_LABELS[STATE.role] || "Vista ejecutiva";
  if(STATE.offline){
    title.textContent = "Modo demo";
    desc.textContent = "Sin conexión a base de datos: datos de referencia, sólo lectura. Acceso: " + roleLbl + ".";
    pill.innerHTML = `<span class="accesspill viewer">● Sólo lectura</span>`;
  } else if(STATE.isAdmin){
    title.textContent = "Backoffice habilitado";
    desc.textContent = "Tienes permiso de edición en este artefacto. Acceso: " + roleLbl + ".";
    pill.innerHTML = `<span class="accesspill editor">● Editor</span>`;
  } else {
    title.textContent = roleLbl;
    desc.textContent = "Vista de sólo lectura.";
    pill.innerHTML = `<span class="accesspill viewer">● Sólo lectura</span>`;
  }
  const swBtn = document.getElementById("switchRoleBtn");
  if(swBtn) swBtn.onclick = showLogin;
}

document.getElementById("viewRoot").addEventListener("click", (e)=>{
  const toggle = e.target.closest("[data-toggle]");
  if(toggle){
    const row = document.getElementById(toggle.dataset.toggle);
    if(row){ row.hidden = !row.hidden; toggle.classList.toggle("open", !row.hidden); }
    return;
  }
  const btn = e.target.closest("[data-route]");
  if(btn){ setRoute(btn.dataset.route); }
});

/* ---------------------------------------------------------------------
   5) HELPERS DE VISTA (RAG, riesgo, EVM…)
--------------------------------------------------------------------- */

const RAG_LABEL = {verde:"En progreso", amarillo:"Atención", rojo:"Crítico", gris:"Sin iniciar"};
const RAG_VARNAME = {verde:"green", amarillo:"amber", rojo:"red", gris:"gray"};
function ragVar(rag){ return "var(--rag-" + (RAG_VARNAME[rag]||"gray") + ")"; }
function chip(rag, textOverride){ return `<span class="chip ${rag}">${textOverride||RAG_LABEL[rag]||rag}</span>`; }
/* Recuadro suave de color combinado para las tarjetas KPI: mezcla el color
   semántico (RAG o nivel de riesgo) con la superficie de tarjeta. */
const RAG_TINT_VAR = {verde:"--tint-rag-green-soft", amarillo:"--tint-rag-amber-soft", rojo:"--tint-rag-red-soft", gris:"--tint-rag-gray-soft"};
function ragTintVar(rag){ return "var(" + (RAG_TINT_VAR[rag]||"--tint-rag-gray-soft") + ")"; }

/* Clasificación de riesgos en 4 niveles (Crítico/Alto/Medio/Bajo) sobre
   una matriz de probabilidad × impacto 1–3 (productos posibles: 1,2,3,4,6,9).
   Umbrales alineados al diccionario oficial de la Matriz de Riesgos del
   proyecto: Bajo 1–3, Medio 4–5, Alto 6–7, Crítico 8–9. */
const RISK_TIERS = [
  {key:"critico", label:"Crítico", min:8},
  {key:"alto", label:"Alto", min:6},
  {key:"medio", label:"Medio", min:4},
  {key:"bajo", label:"Bajo", min:1},
];
function riskLevel(prob, imp){
  const score = (prob||0)*(imp||0);
  const tier = RISK_TIERS.find(t=>score>=t.min);
  return {tier:tier.key, label:tier.label, score};
}
function riskVar(tierKey){ return "var(--risk-" + tierKey + ")"; }
function riskBadge(tierKey, label){ return `<span class="riskbadge ${tierKey}">${label||RISK_TIERS.find(t=>t.key===tierKey).label}</span>`; }
/* Color RAG del chip de estado, sobre el vocabulario oficial de 8 estados
   del diccionario de la Matriz de Riesgos (identificado…cancelado). */
const RISK_ESTADO_RAG = {
  identificado:"gris", en_evaluacion:"amarillo", planificado:"amarillo", en_seguimiento:"amarillo",
  mitigado:"verde", cerrado:"verde", materializado:"rojo", cancelado:"gris",
};
function riskEstadoRag(estado){ return RISK_ESTADO_RAG[estado] || "amarillo"; }
const RISK_ESTADO_LABEL = {
  identificado:"Identificado", en_evaluacion:"En evaluación", planificado:"Planificado",
  en_seguimiento:"En seguimiento", mitigado:"Mitigado", materializado:"Materializado",
  cerrado:"Cerrado", cancelado:"Cancelado",
};
function riskEstadoLabel(estado){ return RISK_ESTADO_LABEL[estado] || estado || "—"; }
const RISK_TINT_VAR = {critico:"--tint-risk-critico-soft", alto:"--tint-risk-alto-soft", medio:"--tint-rag-amber-soft", bajo:"--tint-rag-green-soft"};
function riskTintVar(tierKey){ return "var(" + (RISK_TINT_VAR[tierKey]||"--tint-rag-gray-soft") + ")"; }

function ganttRange(){
  const dates=[];
  STATE.collections.gantt.forEach(t=>{ if(t.inicioPlan) dates.push(t.inicioPlan); if(t.finPlan) dates.push(t.finPlan); });
  STATE.collections.hitos.forEach(h=>{ if(h.fecha) dates.push(h.fecha); });
  if(!dates.length) return {start:new Date("2026-06-01"), end:new Date("2027-08-01")};
  const start = new Date(Math.min(...dates.map(d=>+new Date(d))));
  const end = new Date(Math.max(...dates.map(d=>+new Date(d))));
  start.setDate(1);
  end.setMonth(end.getMonth()+1, 1);
  return {start, end};
}
function monthsBetween(start,end){
  const out=[]; let d=new Date(start);
  while(d<end){ out.push(new Date(d)); d.setMonth(d.getMonth()+1); }
  return out;
}
function pctOfRange(date, start, end){
  return Math.max(0, Math.min(100, ((new Date(date)-start)/(end-start))*100));
}

/* Ruta crítica (aproximada) — el cronograma no trae dependencias explícitas
   entre actividades (ver Supuestos en Backoffice → Config), así que se
   aproxima la ruta crítica encadenando, desde la última actividad hacia
   atrás, la tarea predecesora cuyo fin queda más pegado (≤3 días de holgura)
   al inicio de la actividad actual. Donde ese encadenamiento se corta hay
   holgura real (float) y esa tarea queda fuera de la ruta crítica. */
function computeCriticalPath(tasks){
  const CP_TOLERANCIA_DIAS = 3;
  const withDates = tasks.filter(t=>t.inicioPlan && t.finPlan);
  const critical = new Set();
  if(!withDates.length) return critical;
  const sorted = [...withDates].sort((a,b)=>new Date(a.finPlan)-new Date(b.finPlan));
  let current = sorted[sorted.length-1];
  critical.add(current);
  while(true){
    const candidatos = sorted.filter(t=>t!==current && new Date(t.finPlan)<=new Date(current.inicioPlan));
    if(!candidatos.length) break;
    candidatos.sort((a,b)=>new Date(b.finPlan)-new Date(a.finPlan));
    const pred = candidatos[0];
    if(daysBetween(pred.finPlan, current.inicioPlan) > CP_TOLERANCIA_DIAS) break;
    critical.add(pred);
    current = pred;
  }
  return critical;
}

/* ---------------------------------------------------------------------
   EVM simplificado (curva S, SPI) — a partir del % de avance de cada
   tarea del Gantt, sin histórico de snapshots (ver supuestos). El CPI se
   retiró como métrica de la plataforma a pedido del PM.
--------------------------------------------------------------------- */
function computeSCurve(tasks){
  const withDates = (tasks||[]).filter(t=>t.inicioPlan && t.finPlan);
  if(!withDates.length) return null;
  const start = new Date(Math.min(...withDates.map(t=>+new Date(t.inicioPlan))));
  const end = new Date(Math.max(...withDates.map(t=>+new Date(t.finPlan))));
  const monthStart = new Date(start.getFullYear(), start.getMonth(), 1);
  const monthEndExcl = new Date(end.getFullYear(), end.getMonth()+1, 1);
  const months = monthsBetween(monthStart, monthEndExcl);
  const weight = 1/withDates.length;
  const fracAt = (t, at) => {
    const s=new Date(t.inicioPlan), e=new Date(t.finPlan);
    if(at<=s) return 0; if(at>=e) return 1; return (at-s)/(e-s);
  };
  const planCum = months.map(m=>{
    const checkpoint = new Date(m.getFullYear(), m.getMonth()+1, 0);
    return withDates.reduce((sum,t)=>sum + fracAt(t,checkpoint)*weight, 0) * 100;
  });
  const today = new Date();
  const realPct = withDates.reduce((sum,t)=>sum + ((t.avance||0)/100)*weight, 0) * 100;
  const planTodayPct = withDates.reduce((sum,t)=>sum + fracAt(t,today)*weight, 0) * 100;
  return {months, planCum, start, end, realPct, planTodayPct, n:withDates.length};
}
function computeSPI(scurve){
  if(!scurve || scurve.planTodayPct<0.5) return null;
  return scurve.realPct/scurve.planTodayPct;
}
// El promedio simple sin ponderar de computeSCurve() (misma limitación que
// avanceGeneral, ver supuestos EVM) sobreestima mucho el "planificado a
// hoy" cuando el Gantt mezcla fases de meses con subtareas de 1 día. Por
// eso el punto "real" ya se sobreescribe con el avance físico confirmado
// por el PM (avanceFisicoPct); aquí además se reescala toda la curva
// planificada para que su valor a la fecha de corte coincida con
// avancePlanificadoPct (otro override de PM: "qué tanto deberíamos haber
// avanzado según el plan"), preservando la forma de la curva S. Si ese
// campo no está definido, se deja el cálculo automático sin tocar.
function applyScheduleOverrides(scurve, c, avanceGeneral){
  if(!scurve) return scurve;
  scurve.realPct = avanceGeneral;
  const planTarget = (c.avancePlanificadoPct!=null) ? c.avancePlanificadoPct : null;
  const n = scurve.months.length;
  if(planTarget!=null && n>1){
    // Punto de corte "hoy" en el mismo eje fraccional (0..1) que usa el
    // trazo real en svgSCurve, para que el reescalado quede alineado con
    // dónde cae el punto real en el dibujo.
    const totalMs = scurve.end - scurve.start;
    const todayFrac = totalMs>0 ? Math.min(Math.max((new Date()-scurve.start)/totalMs,0),1) : 0;
    const todayIdx = todayFrac*(n-1);
    const i0 = Math.floor(todayIdx), i1 = Math.min(i0+1, n-1), f = todayIdx-i0;
    const rawToday = scurve.planCum[i0] + (scurve.planCum[i1]-scurve.planCum[i0])*f;
    // Tramo ya transcurrido: se reescala proporcionalmente para que el
    // valor "a hoy" coincida con planTarget (el override del PM), sin
    // tocar la forma relativa entre esos meses.
    // Tramo futuro: se remapea linealmente de [rawToday,100] a
    // [planTarget,100] para que la curva siga llegando a 100% en la
    // fecha de cierre, conservando la curvatura original del tramo.
    scurve.planCum = scurve.planCum.map((p,i)=>{
      if(i<=todayIdx){
        return rawToday>0.01 ? Math.min(100, p*(planTarget/rawToday)) : planTarget;
      }
      const denom = 100-rawToday;
      return denom>0.01 ? Math.min(100, planTarget + (100-planTarget)*((p-rawToday)/denom)) : 100;
    });
    scurve.planTodayPct = planTarget;
  }
  return scurve;
}
function metricPill(label, value, isGood){
  if(value===null||value===undefined||isNaN(value)) return `<span class="metricpill na"><span class="mlabel">${label}</span>s/d</span>`;
  const cls = isGood===null?'':(isGood?'good':'bad');
  return `<span class="metricpill ${cls}"><span class="mlabel">${label}</span>${value.toFixed(2)}</span>`;
}

/* ---------------------------------------------------------------------
   Mini-gráficos SVG (sin librerías) para tarjetas y casillas del EDT.
--------------------------------------------------------------------- */
function svgRing(pct, color, size, stroke){
  size = size||40; stroke = stroke||5;
  const r=(size-stroke)/2, c=2*Math.PI*r, p=Math.min(Math.max(pct||0,0),100), off=c*(1-p/100);
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="var(--surface-3)" stroke-width="${stroke}"/>
    <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}" transform="rotate(-90 ${size/2} ${size/2})"/>
  </svg>`;
}
function svgStackBar(counts, colors, w, h){
  w=w||140; h=h||10;
  const total = counts.reduce((a,b)=>a+b,0)||1;
  let x=0;
  const rects = counts.map((v,i)=>{
    const width=(v/total)*w;
    const r = v>0 ? `<rect x="${x.toFixed(1)}" y="0" width="${Math.max(width,0).toFixed(1)}" height="${h}" fill="${colors[i]}"/>` : "";
    x+=width; return r;
  }).join("");
  return `<svg width="100%" height="${h}" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" style="border-radius:4px; overflow:hidden; display:block;"><rect width="${w}" height="${h}" fill="var(--surface-3)"/>${rects}</svg>`;
}
function svgGauge(pctElapsed, w, h){
  w=w||140; h=h||8;
  const p = Math.min(Math.max(pctElapsed||0,0),100);
  return `<svg width="100%" height="${h}" viewBox="0 0 ${w} ${h}"><rect x="0" y="0" width="${w}" height="${h}" rx="${h/2}" fill="var(--surface-3)"/><rect x="0" y="0" width="${(p/100*w).toFixed(1)}" height="${h}" rx="${h/2}" fill="var(--accent)"/></svg>`;
}
function svgSCurve(scurve, opts){
  opts = opts||{}; const w=opts.w||180, h=opts.h||52, big=!!opts.big, pad=big?28:4;
  if(!scurve || scurve.months.length<2){
    return `<div class="hint" style="font-size:11.5px;">Fechas insuficientes en el Gantt para trazar la curva S.</div>`;
  }
  const n = scurve.months.length;
  const xAt = (i) => pad + (i/(n-1))*(w-2*pad);
  const yAt = (pct) => (h-pad) - (Math.min(pct,100)/100)*(h-2*pad);
  const planPath = scurve.planCum.map((p,i)=>`${i===0?'M':'L'}${xAt(i).toFixed(1)},${yAt(p).toFixed(1)}`).join(" ");
  const totalMs = scurve.end - scurve.start;
  const todayMs = Math.min(Math.max(new Date()-scurve.start,0), totalMs);
  const todayX = pad + (totalMs>0?(todayMs/totalMs):0)*(w-2*pad);
  const todayYReal = yAt(scurve.realPct);
  const realPath = `M${pad.toFixed(1)},${yAt(0).toFixed(1)} L${todayX.toFixed(1)},${todayYReal.toFixed(1)}`;
  const grid = big ? [0,25,50,75,100].map(p=>`<line x1="${pad}" y1="${yAt(p).toFixed(1)}" x2="${w-pad}" y2="${yAt(p).toFixed(1)}" stroke="var(--border-soft)" stroke-width="1"/><text x="${pad-6}" y="${(yAt(p)+3).toFixed(1)}" text-anchor="end" font-size="9" fill="var(--text-faint)">${p}%</text>`).join("") : "";
  const monthLabels = big ? scurve.months.filter((_,i)=>i%Math.ceil(n/8||1)===0).map(m=>{
    const i = scurve.months.indexOf(m);
    return `<text x="${xAt(i).toFixed(1)}" y="${h-6}" text-anchor="middle" font-size="9" fill="var(--text-faint)">${m.toLocaleDateString('es-BO',{month:'short',year:'2-digit'})}</text>`;
  }).join("") : "";
  return `<svg class="scurve-svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" style="overflow:visible;">
    ${grid}
    <line x1="${pad}" y1="${(h-pad).toFixed(1)}" x2="${w-pad}" y2="${(h-pad).toFixed(1)}" stroke="var(--border)" stroke-width="1"/>
    <path d="${planPath}" fill="none" stroke="var(--text-faint)" stroke-width="${big?2:1.6}" stroke-dasharray="4 3"/>
    <path d="${realPath}" fill="none" stroke="var(--accent)" stroke-width="${big?2.4:2}"/>
    <circle cx="${todayX.toFixed(1)}" cy="${todayYReal.toFixed(1)}" r="${big?4:2.6}" fill="var(--accent)"/>
    ${monthLabels}
  </svg>`;
}

/* ---------------------------------------------------------------------
   Vínculo frente ↔ tareas/riesgos/problemas (F1..F6, ver supuestos)
--------------------------------------------------------------------- */
function frenteByCodigo(codigo){ return STATE.collections.frentes.find(f=>f.codigo===codigo); }
function tasksForFrente(codigo){ return STATE.collections.gantt.filter(t=>t.frenteCodigo===codigo); }
function riesgosForFrente(codigo){ return STATE.collections.riesgos.filter(r=>r.frenteCodigo===codigo); }
function problemasForFrente(codigo){ return STATE.collections.problemas.filter(p=>p.frenteCodigo===codigo); }

/* ---------------------------------------------------------------------
   6) VISTAS — EJECUTIVAS
--------------------------------------------------------------------- */

function viewResumen(){
  const c = STATE.config;
  const frentes = [...STATE.collections.frentes].sort((a,b)=>(a.orden||0)-(b.orden||0));
  const riesgosOrdenados = [...STATE.collections.riesgos].sort((a,b)=>riskLevel(b.probabilidad,b.impacto).score-riskLevel(a.probabilidad,a.impacto).score);
  const riesgosMaterializados = STATE.collections.riesgos.filter(r=>r.estado==="materializado").sort((a,b)=>riskLevel(b.probabilidad,b.impacto).score-riskLevel(a.probabilidad,a.impacto).score);
  const riesgosTop = riesgosMaterializados.length ? riesgosMaterializados : STATE.collections.riesgos.filter(r=>r.esTop || riskLevel(r.probabilidad,r.impacto).tier==="critico");
  const problemasAbiertos = STATE.collections.problemas.filter(p=>p.estado!=="resuelto");
  const problemasFlagged = STATE.collections.problemas.filter(p=>p.alertaRoja);
  const decisionesPend = STATE.collections.decisiones.filter(d=>d.estado==="pendiente").sort((a,b)=>(a.prioridad??99)-(b.prioridad??99));
  const hitosOrdenados = [...STATE.collections.hitos].sort((a,b)=>new Date(a.fecha)-new Date(b.fecha));
  const proximoHito = hitosOrdenados.find(h=>new Date(h.fecha)>=new Date(todayISO())) || hitosOrdenados[hitosOrdenados.length-1];
  const goLive = c.fechaEntregaFinal;
  const diasGoLive = goLive ? daysBetween(todayISO(), goLive) : null;
  const avanceGeneral = (c.avanceFisicoPct!=null) ? c.avanceFisicoPct : (STATE.collections.gantt.length ? Math.round(STATE.collections.gantt.reduce((s,t)=>s+(t.avance||0),0)/STATE.collections.gantt.length) : 0);
  const scurveGlobal = computeSCurve(STATE.collections.gantt);
  applyScheduleOverrides(scurveGlobal, c, avanceGeneral);
  const riskCounts4 = RISK_TIERS.map(t=>riesgosOrdenados.filter(r=>riskLevel(r.probabilidad,r.impacto).tier===t.key).length);
  const riskColors4 = RISK_TIERS.map(t=>`var(--risk-${t.key})`);
  const kickoff = c.fechaKickOff, golivePlan = goLive;
  let pctElapsed = null;
  if(kickoff && golivePlan){
    const t0=+new Date(kickoff), t1=+new Date(golivePlan), tn=+new Date();
    pctElapsed = t1>t0 ? Math.max(0,Math.min(100,((tn-t0)/(t1-t0))*100)) : null;
  }
  const ragColorVar = ragVar(c.semaforoGeneral);
  const topRiskIdx = riskCounts4.findIndex(n=>n>0);
  const topRiskTier = topRiskIdx===-1 ? RISK_TIERS[RISK_TIERS.length-1] : RISK_TIERS[topRiskIdx];
  const kpiStyle = (edgeVar, bgGradient) => `--kpi-edge:${edgeVar}; --kpi-bg:${bgGradient};`;

  return `
    <div class="section-head">
      <div class="eyebrow">Comité Ejecutivo · ${fmtDate(c.fechaActualizacion)}${staleBadgeHTML(c.fechaActualizacion)}</div>
      <h2>${c.nombreProyecto} — ${c.subtitulo}</h2>
      <p>PM: ${c.pmResponsable||"—"} · Patrocinador: ${c.patrocinador||"—"} · Líder de proyecto: ${c.liderProyecto||"—"}</p>
    </div>

    <div class="grid kpirow">
      <button class="card kpi" data-route="edt" style="${kpiStyle(ragColorVar, `linear-gradient(135deg, ${ragTintVar(c.semaforoGeneral)}, var(--surface-2))`)}">
        <div class="label">Estado general</div>
        <div class="miniviz">${svgRing(avanceGeneral, ragColorVar, 44, 6)}<div class="ringval"><div class="ringval-num">${avanceGeneral}<small style="font-size:12px;color:var(--text-muted-tint);">%</small></div>${chip(c.semaforoGeneral)}</div></div>
        <div class="foot">EDT y curva S por frente <span class="goarrow">→</span></div>
      </button>
      <button class="card kpi" data-route="cronograma" style="${kpiStyle("var(--primary)", "linear-gradient(135deg, var(--tint-primary-soft), var(--surface-2))")}">
        <div class="label">Avance del cronograma</div>
        <div class="miniviz">${svgSCurve(scurveGlobal,{w:150,h:46})}</div>
        <div class="value">${avanceGeneral}<small>%</small></div>
        <div class="foot">Desviación: ${c.desviacionCronograma||"—"} <span class="goarrow">→</span></div>
      </button>
      <button class="card kpi" data-route="decisiones" style="${kpiStyle("var(--accent)", "linear-gradient(135deg, var(--tint-accent-soft), var(--surface-2))")}">
        <div class="label">Decisiones pendientes</div>
        <div class="miniviz">${svgRing(STATE.collections.decisiones.length?Math.round((decisionesPend.length/STATE.collections.decisiones.length)*100):0, "var(--accent)", 44, 6)}<div class="ringval"><div class="ringval-num">${decisionesPend.length}</div></div></div>
        <div class="foot">Acción, responsable y estado <span class="goarrow">→</span></div>
      </button>
      <button class="card kpi" data-route="hitos" style="${kpiStyle("var(--accent)", "linear-gradient(135deg, var(--tint-primary-soft), var(--tint-accent-soft))")}">
        <div class="label">Días a entrega final</div>
        <div class="miniviz">${svgGauge(pctElapsed, 150, 10)}</div>
        <div class="value">${diasGoLive!==null?diasGoLive:"—"}</div>
        <div class="foot">vs. entrega final ${fmtDate(goLive)} <span class="goarrow">→</span></div>
      </button>
    </div>

    <div class="grid q3">
      <div class="card">
        <div class="qlabel"><span class="qnum">1</span>¿Dónde estamos?</div>
        <ul>
          ${c.mensajesClave.slice(0,3).map(m=>`<li>${m}</li>`).join("") || '<li class="empty">Sin mensajes clave cargados.</li>'}
          <li><b>Avance físico:</b> ${avanceGeneral}% · <b>Semáforo:</b> ${RAG_LABEL[c.semaforoGeneral]||c.semaforoGeneral}</li>
        </ul>
      </div>
      <div class="card">
        <div class="qlabel"><span class="qnum">2</span>¿Qué necesita decidir el Comité?</div>
        <ul>
          ${decisionesPend.slice(0,4).map(d=>`<li><b>${d.codigo}.</b> ${d.tema}</li>`).join("") || '<li class="empty">No hay decisiones pendientes registradas.</li>'}
        </ul>
        <div class="cardfoot-link" data-route="decisiones">Ver cuadro de decisiones →</div>
      </div>
    </div>

    <div class="card panel">
      <h3>Semáforo por frente de trabajo</h3>
      <div class="hint">Estado y avance físico de cada dimensión del proyecto. Cada fila lleva al detalle de actividades del frente.</div>
      <div class="frentelist">
        ${frentes.map(f=>`
          <button class="frenterow" data-route="frente:${f.codigo||f.id}">
            <div>
              <div class="fname">${f.nombre}</div>
              <div class="fcomment">${f.comentario||""}</div>
            </div>
            ${chip(f.semaforo)}
            <div>
              <div class="bar-track"><div class="bar-fill" style="width:${f.avancePct||0}%; background:${ragVar(f.semaforo)};"></div></div>
              <div style="font-size:11px;color:var(--text-faint);margin-top:4px;text-align:right;">${f.avancePct||0}%</div>
            </div>
            <span class="goarrow">→</span>
          </button>
        `).join("") || `<div class="hint">Sin frentes cargados aún.</div>`}
      </div>
    </div>

    <div class="card panel">
      <h3>Mensajes clave para el Comité</h3>
      <div class="hint">Resumen ejecutivo — no reemplaza el detalle de cada sección.</div>
      <ul class="msglist">${c.mensajesClave.map(m=>`<li>${m}</li>`).join("")}</ul>
    </div>
  `;
}

function viewEDT(){
  const c = STATE.config;
  const frentes = [...STATE.collections.frentes].sort((a,b)=>(a.orden||0)-(b.orden||0));
  const scurveGlobal = computeSCurve(STATE.collections.gantt);
  const avanceGeneral = (c.avanceFisicoPct!=null) ? c.avanceFisicoPct : (STATE.collections.gantt.length ? Math.round(STATE.collections.gantt.reduce((s,t)=>s+(t.avance||0),0)/STATE.collections.gantt.length) : 0);
  applyScheduleOverrides(scurveGlobal, c, avanceGeneral);
  const spiGlobal = computeSPI(scurveGlobal);

  return `
    <div class="section-head">
      <div class="eyebrow">EDT / WBS · EVM simplificado</div>
      <h2>Estructura del proyecto</h2>
      <p>Cada casilla es un frente de trabajo (nivel 1 de la EDT). Muestra % de avance, curva S propia y su métrica SPI. La curva "real" es un único punto de corte a hoy conectado linealmente al inicio — ver supuestos de EVM en Backoffice → Config.</p>
    </div>

    <div class="card panel scurve-card">
      <h3>Curva S del proyecto</h3>
      ${svgSCurve(scurveGlobal,{big:true,w:760,h:220})}
      <div class="scurve-legend">
        <span><i class="dashed"></i>Planificado (acumulado)</span>
        <span><i style="background:var(--accent);"></i>Real (corte a hoy)</span>
      </div>
      <div class="enmetrics" style="margin-top:14px; flex-wrap:wrap; gap:10px;">
        <span class="metricpill good"><span class="mlabel">Avance físico</span>${avanceGeneral}%</span>
        ${chip("verde", `Desviación: ${c.desviacionCronograma||"—"}`)}
      </div>
      <div class="hint" style="margin-top:8px;">Avance físico y desviación de cronograma confirmados por el PM — un SPI calculado automáticamente sobre este Gantt (fases de meses junto a subtareas de 1 día, de tamaño muy desigual) no es representativo, igual que el avance físico global (ver supuestos de EVM en Backoffice → Config).</div>
    </div>

    <div class="card panel">
      <h3>EDT por frente de trabajo</h3>
      <div class="hint">Clic en una casilla para ver el detalle de actividades, riesgos y problemas vinculados a ese frente.</div>
      <div class="edt-wrap">
        <div class="edt-root">${c.nombreProyecto}<div style="font-size:11px;font-weight:500;color:var(--text-faint);margin-top:2px;">${avanceGeneral}% avance global</div></div>
        <div class="edt-grid">
          ${frentes.map(f=>{
            const sc = computeSCurve(tasksForFrente(f.codigo));
            const spi = computeSPI(sc);
            return `
            <button class="edt-node" data-route="frente:${f.codigo}" style="border-top:3px solid ${ragVar(f.semaforo)};">
              <div class="enname">${f.codigo} · ${f.nombre}</div>
              <div class="enpct">${f.avancePct||0}%</div>
              ${sc ? svgSCurve(sc,{w:180,h:44}) : `<div class="hint" style="font-size:11px;">Sin tareas vinculadas.</div>`}
              <div class="enmetrics">
                ${metricPill("SPI", spi, spi===null?null:spi>=0.95)}
              </div>
            </button>`;
          }).join("") || `<div class="hint">Sin frentes cargados aún.</div>`}
        </div>
      </div>
    </div>
  `;
}

function viewFrenteDetalle(codigo){
  const f = frenteByCodigo(codigo);
  if(!f){
    return `<div class="card panel"><div class="backlink" data-route="resumen">← Volver al resumen</div><h3 style="margin-top:12px;">Frente no encontrado</h3><p class="hint">El código "${codigo}" no corresponde a ningún frente registrado.</p></div>`;
  }
  const tasks = tasksForFrente(codigo);
  const riesgos = riesgosForFrente(codigo);
  const problemas = problemasForFrente(codigo);
  const sc = computeSCurve(tasks);
  const spi = computeSPI(sc);

  return `
    <div class="backlink" data-route="edt">← Volver a la EDT</div>
    <div class="section-head" style="margin-top:10px;">
      <div class="eyebrow">Frente ${f.codigo}</div>
      <h2>${f.nombre}</h2>
      <p>${f.comentario||"Sin comentario registrado."}</p>
    </div>

    <div class="grid kpirow" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));">
      <div class="card kpi" style="cursor:default;"><div class="label">Semáforo</div><div class="value" style="font-size:16px;">${chip(f.semaforo)}</div></div>
      <div class="card kpi" style="cursor:default;"><div class="label">Avance físico</div><div class="value">${f.avancePct||0}<small>%</small></div></div>
      <div class="card kpi" style="cursor:default;"><div class="label">SPI</div><div class="value" style="font-size:22px;">${metricPill("", spi, spi===null?null:spi>=0.95)}</div></div>
    </div>

    <div class="card panel">
      <h3>Actividades vinculadas (Gantt)</h3>
      <div class="tablewrap"><table>
        <thead><tr><th>Tarea</th><th>Fase</th><th>Inicio plan</th><th>Fin plan</th><th>Avance</th><th>Estado</th><th>Responsable</th></tr></thead>
        <tbody>${tasks.map(t=>`<tr>
          <td>${t.nombre}</td><td>${t.fase||""}</td><td>${fmtDate(t.inicioPlan)}</td><td>${fmtDate(t.finPlan)}</td>
          <td>${t.avance||0}%</td><td>${chip(t.estado==='completado'?'verde':t.estado==='en_riesgo'?'rojo':t.estado==='en_curso'?'amarillo':'gris', t.estado?t.estado.replace('_',' '):'')}</td>
          <td>${t.responsable||""}</td>
        </tr>`).join("") || `<tr><td colspan="7" class="hint">Sin actividades vinculadas a este frente (frenteCodigo=${codigo}).</td></tr>`}</tbody>
      </table></div>
    </div>

    <div class="card panel">
      <h3>Riesgos vinculados</h3>
      <div class="tablewrap"><table>
        <thead><tr><th>Código</th><th>Riesgo</th><th>Nivel</th><th>Estrategia</th><th>Responsable</th></tr></thead>
        <tbody>${riesgos.map(r=>{ const lvl=riskLevel(r.probabilidad,r.impacto); return `<tr>
          <td><span class="code">${r.codigo}</span></td><td style="max-width:320px;">${r.descripcion}</td>
          <td>${riskBadge(lvl.tier)}</td><td>${r.estrategia||""}</td><td>${r.responsable||""}</td>
        </tr>`; }).join("") || `<tr><td colspan="5" class="hint">Sin riesgos vinculados a este frente.</td></tr>`}</tbody>
      </table></div>
    </div>

    ${problemas.length ? `
    <div class="card panel">
      <h3>Problemas y bloqueos vinculados</h3>
      <div class="tablewrap"><table>
        <thead><tr><th></th><th>Código</th><th>Descripción</th><th>Responsable</th><th>Estado</th></tr></thead>
        <tbody>${problemas.map(p=>`<tr>
          <td>${flagBadge(p.alertaRoja)}</td>
          <td><span class="code">${p.codigo}</span></td><td style="max-width:320px;">${p.descripcion}</td><td>${p.responsable||""}</td>
          <td>${chip(p.estado==='resuelto'?'verde':p.estado==='en_curso'?'amarillo':'rojo', p.estado?p.estado.replace('_',' '):'')}</td>
        </tr>`).join("")}</tbody>
      </table></div>
    </div>` : ""}
  `;
}

/* Roadmap oficial del proyecto — imagen fija provista por el PM (reemplaza
   el Gantt calculado dinámicamente en la vista Cronograma; ver nota en
   viewCronograma()). Actualizar este data URI cuando cambie la línea base. */
const ROADMAP_IMG_B64 = "iVBORw0KGgoAAAANSUhEUgAABkAAAAOECAIAAAB2L2r1AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAJOgAACToAYJjBRwAAP+lSURBVHhe7P0JVBRX/vePc3I8+ffx5PHJ4+PJk19mJpP5zpIZRxSNGqOJcUxCnMQkxnZfWsUNd8U1RhENwX2LgigiiyCoqKAoKigiKCoiIjvIJrKERRBBZGnqf+CT3FSqulugq7qr9f067+ORu1R1f/pW1a133XvLSqXWQBAEQRAEQRAEQRAEQZBiZSVOgiAIgiAIgiAIgiAIgiDlCAYWBEEQBEEQBEEQBEEQpGjBwIIgCIIgCIIgCIIgCIIULRhYEARBEARBEARBEARBkKIFAwuCIAiCIAiCIAiCIAhStGBgQRAEQRAEQRAEQRAEQYoWDCwIgiAIgiAIgiAIgiBI0YKBBUEQBEEQBEEQBEEQBClaMLAgCIIgCIIgCIIgCIIgRQsGFgRBEARBEARBEARBEKRowcCCIAiCIAiCIAiCIAiCFC0YWBAEQRAEQRAEQRAEQZCiBQMLgiAIgiAIgiAIgiAIUrRgYEEQBEEQBEEQBEEQBEGKFgwsCIIgCIIgCIIgCIIgSNGCgQVBEARBEARBEARBEAQpWjCwIAiCIAiCIAiCIAiCIEULBhYEQRAEQRAEQRAEQRCkaMHAgiAIgiAIgiAIgiAIghQtGFgQBEEQBEEQBEEQBEGQogUDC4IgCIIgCIIgCIIgCFK0YGBBEARBEARBEARBEARBihYMLAiCIAiCIAiCIAiCIEjRgoEFQRAEQRAEQRAEQRAEKVowsCAIgiAIgiAIgiAIgiBFCwYWBEEQBEEQBEEQBEEQpGi9RAbWSJcdhyOj7xeX1NQ90zY355SUnoy9NXmH22tjprEyXSfM2H/+0tXkNKaLCfcOR0Yfjoxe4X3kvSWrxZsV7MLn0tXMouK6hgaO4+oaGu4XlwTfuD1/v9fr46eLy6vUmiGrfzgWc+Nqctq523f3hYX/e95ycZmh3zufj0+8mpzmc+mqOJfUgV3z9bXztn1h4Sn5BY+e1HAcV9/YmFdadj4+cUPgiX/NXSYoPOLH7fR5mI7F3DgcGe169qJ60843Js8Wb1+gFd5HWN3QuDu9F60SlyENXLHuZOwtKhkYHbsxKOQP0+aJizH9efqC3WfCzt2+S1W8Iq78efoCcTFS2z+GTm0IPEF1/a7E8FtRx37Tt6bMEURVny7fS+m/dI3O5iqQ69mL4l1TlFZ4HzkffzevtEzb3MxxXGnV46S8B57hkRO37+V/F517addBoVJr/jV36emb8ay6U0CQuAxJ3772hYWv8D4yZPUPXcbaiWsJ9OfpCxz9j0enppdUVnGtlFRWxWVl7wm9QHFro/S1841BIRO37/3rrMXiKvoq8nUlKXXginWssL5W1BbZOroE37jN3/jhyGiviCurfAJ6LVwpLi/+YO06ctt+kpntepC2f/leytgtP4k39fUPWyPuJlGZ8dv26PzpBdLXmA2f2DtwWAk23savDEEQBEEQBEGQ3HopDKx/z1sem55Ft7JiEnPzmScyevNuYfbvibib9PfZS8S76L1olYFd0C308A1bxBUTc/P5xYoeVYpvI52PnmIFxFvo8K5JQ9c4Cz6DAG1z86agEH4Vw+Wrnz6d535IvCOmP09fQKYJw+9KjLgY6WbmfX5JjuNi07PExZiupWUIym8+cVpcrL0fQ6fySstY3Tc19iy9Y7+preNGfi3DLDvk35bmqm1uFuz39fHTd4aco7txfeSUlPJNt+fuRd9BwbT//CVBFbEr2sZ9lVRWrfYN1Gf0dB41xdH/eE3dM2E1HkeirnWdMENcVyzD7ZzjuNC4O2LLoy0VNwSeYIX1taK2yPCOYtOz3p3j0PbyBo7c9p5kZrseZFnl1dUCr6fzqClZRcWsADlcz/3pxY25LSf2DhxWHfvKEARBEARBEATJrRffwOq/dE15dbXw5uP3TNvtToVn7vUQ5onIKy3rNnEWfxdDv3euqqkVlhPR2KSduH2v4OPxb1+JradCBWXEZocku1apNfPcDzU2aYWlRWibm/kjX8SfWczig77i3ZEWH/QVFK5++lTfcAad++IPYOFrwPK1wqIctyf0grhkez+GTumzHsSfuS2/6dA1zr+rYxAK73Oba03dM/5O/2Q3P/5+jrCQLjbyLMvn7kXnQcH02phpbCQUw9H/uLhkG/fFcdzNzPvigXWdR00JunZTWFQXcVnZbfmhxb+jmPrGRrHp89yKq3wCdBZur4H13B1V1dTyh2I9t7zOI7cDJ5kuY+0elJWzrPn7vfgb5HtVaQWFnUdNactPL2jMbTyxd+Cw6thXhiAIgiAIgiBIbr3gBtYbk2ffL/6Zf8sRfCNurvuh0Zt3rfA+cu52AiXO3OtB5fk3USdjb9k6bpy4fe8cN8+Tsbd+2wTH8Uck/cluPv/+vPrp060nQ4et22TruHHEj9tdz16sb2zk5wrGqohvKWvqngnKiM0OSXY9fMMW/hCkuoYGjwuX1Rt32jpuHLZu08y9HvvPXyqteky5+gyakS47hm/YMnOvh1NA0MPyCpZe/fTpW1Pm8HfHpHNcg777QLavokeVzGvTN5lo37lwKlBe/YRtWZ+B1a6PoVP6rIeO/aavj5/udCTI+egpJv4t9NZTofwsmr/Gb64Rd5Nm7vUQ6Iv1m9keXxszLSo5jZXnOC4hO2/ZIX9bx422jhvHbvlp2SF/VoAftA4cFHwN37CFX4xIKygUl9T3jVb7BnpcuMw3RGh4kWA64YbAE/wC0SnpU3buo283z/2QYPCRvlbBF/93XHjAZ+Zej7nuhzYGhYTfTeLbvtrmZvWmnYYrCsSfBquvFbVFOnd0ODKa//FC4+7oLN/GI7fDJ5n5+71YOnOpSNfSMlnW5B1ulKjzp9fXmNt+Yu/AYdXhrwxBEARBEARBkKx6wQ2sradC2Z1GY5N29OZdggIfrnSKy8q2dXShP/k3UYJbXP6mUnm33/zpUUWPKq3nrxDsYuCKdfw5TbvPnOfnsltKfhmPC5f5ZcRmh/G77jZxFjOnaLqNztuwLmPt5u/3ik3P5E/a0nfL/efpC/g3hzrNoHfnOLACgVevs/8H34gTF+bvKzE3P+JuEv2/tOqxeBJZl7F2tIAXx3H8yOi0Ktr7MXRKXxyM+U3bsn0mA81VrNW+gaywtrl5mddvs6X46r1oVWD0df6QGQN70XdQ8HU4MpoKPCyviE5JZ+X7OnwvLmxgX13G2m0PPstyOY5b43eU5f511mK+rbA9+CzfMSH/7kjUNVagvrHR8GJqhuPff+kafm55dTV/AJqBimK1q3Ab607cvpelcxz3//1qSOkrb+DI7fBJRjAIa8SP2yl98HfrWSLf2DLw04vV3hM7X/qCwNThrwxBEARBEARBkKx6kQ2srhNm8OeYPPemyPBN1HtLVrOs0qrHlPjG5Nn8OxmdyxWr1BqX48HiuiR2N3Uy9hbbVH1jI3/ij06zw8hdr/E7ytJr6p6JJ2QZkIE7QP6onIUHfMR11/gdo9zGJu3bvJEOdQ0NOm8m+QYWf2GdkS47BCXHb9tDWdrmZv68IZ2/e3s/hk7pi0OHf9M2bp/JQHMVqNvEWfxjYWfIOXEZfTKwF50HBV+vj5/OnJE9oRcWHvBh5beeFE6rNLwvks+lKFagvLqa+Zj8dp6Ymy9wr0iCQ0Zn++TLcPz/PW853zJbdsivjRXbtRfD0lf3tTHT+N/007U/Gi6v78g18iTDH4R1JSmFEo/F3GCJbPhVW356pg6c2PkyEATjvzIEQRAEQRAEQfLpRTawvnbeyu4x6hsbdY4wEsjATdT7y9awrITsXEoc6bKDJRY9qhQPCyL9a+4y/mQ9navSHIm6xn/yfyzmBiuj0+wwctf8GVX6FiTSJwN3gKdvxbMs9cbfzasisf1G3E0SDHaYufeAuDzfwHpTY88sA358SBcT7lFWZFIqf4CVzvvb9n4MndIXhw7/pm3cPpOB5ioQf9Wh8upq8aLyBmRgLzoPCr74+x2yegN/4fy80jJxeQP7Iv199hK+bTT0e2dK56/tZcCZ8v11OJjOJiTQc+PvceEyK3ApMbntFdu1FwMyUDcuK5tlsSPRQHmdR66RJxnBIKx+Dt//ZeYi9vMJ5hU+96dn6sCJnS8DQTD+K0MQBEEQBEEQJJ9eZANr68nfpplEJqWKC4hl4CaK70TsCwunxC0nTrPE/ecjxBtkyiz87a1bk3e4snR2N3X6Vjz/5lzb3MyWKtdpdhiz6z/ZzWd3X/WNjW1Z0JovfXeA/5q7jD/g6C8zFwkq9l70Has4b1/L0te2ji4shbwkfftKzM1vuc2++cttdu2zer4L85eZi9g3mrfvkGEDqwMfQ6f0xaHDv2kbt89koLkKtC/sl9XBOI5zOR4sLmBABvai86Dgi62q/rC8gtwK/jpcQ1ZvaPu+mELj7rAy5L12nTCDv+rTn+zmi2uRpuzcx4qlPywSF+DrufEfsNyRFahraGB2zHMrtmsvBqSvbudRU9h0Wo7jBn/3S5z1ldd35BpzkiHxB2F5hkc6+h/nFftt+FUbf3pSB07sfOkLAsn4rwxBEARBEARBkEx6kQ2soOu/vZLMNzJaXEAs/k0UrVdt67hx+k/72arAdKfKnvnzV9UxPI6Jv/rP/P3eLJ1vdgjGdFxMuEdldJodxuyaP8Mu/n4Ov/DozbvFyycPWf0Dvwz/DnCkyw5bx43qjTvX+B3jz+vZf/6S+JNsDAqh3MYm7R9bVyDqPGoKm77X2KQVz2QUGFh8A2K260FWjE0JrG9sfFNjb9jA6sDH0Cl9d8Id/k3buH0mfnOtfvo0r7SMr/Pxiazk5XsprCR/9uW7cxzEP/f0n/bzV3Rq70HB9Mbk2bXP6qkA+xX4swj3nRN6Xm1xMfaEXvhtC62u2b/nLWcp9Y2N4ipMw9ZtYiVLKqvEBfh6bvz/n8aeFeA4ji2qxa/4oKxc8LsM37ClXXsxIH11p+z67TCpfVbPHOr2HrnGnGRI/EFY1U+fZv+68rpg+FW7GnMHTux86QsayfivDEEQBEEQBEGQTHqRDSz+Tbvz0VPiAmLxb6J0Uv306TCnTaz8+TuJLGuOm6d4g0z8m65lh35bP1tgdvx99hL+Ciy0L51mhzG7Hr/1l+WiBC8p6zphBn9eDKO+sZH/xjf+HaBOTsbe0jmqi41Z4I9y4o/iYa+xF++LDKyuE2YwT4Q/+OJ+cQkl0irshg2sDnwMndJ3J9zh37SN22cy3FyrampZyZT8Apb+wXJHls5fDJsP/3gxvBfxQcHEdxvZYCv+LMKSyirBFK22GFirfAJYmcOt/sWHq5xYysPyR+IqTL0X/zb4jh8fnXpu/FVqDf+XfXeOg7iiGP7h38a96BO/bj+H79+d4zBk9Q8bAk/UNTSwdP7bAwx/MPGRa8xJhok/CIshGH713GbG/7E6cGLny3DAJfnKEARBEARBEATJoRfZwOI/IV/jd0xcQCzDN1HBN27zXzCvUmvYe/E4jpvr3jIZTZ+Cb9xmJflr9AjMDoGncDPzvj6zw5hd8wdonLt9l5V8Y/Jsli5Ap0EjpvZZPXvdmEAfrvzNZaCJeyT+9L3Y9CxBLYGBxZ+Vpm1uplE//AFl47ftMWxgdexj6JS+O+EO/6Zt3D6T4eaawZsil1n023QnNo1RpdbsPhP2uzq/wg+a4b2IDwqm8/F3qQybP0jizyIUDEdqi4G1wvsIK+MZHqlSa4as/oGlFD2qFFdh6ufwPSv53LW3nxt/lVpT/fQpK/OXmQvFFcUIppu1ZS/6ZHhHHMdlFRXzX7ZooLzOI9eYkwyTYCUsncOvntvM+I25Ayd2vgwHXJKvDEEQBEEQBEGQHHqRDSz+WjlbT+l45ZlY/JuotILCYzE30goKWYq2uZk/bU1wD+N0JEi8QaabGfdZSX1rYFHKH6bN469f87XzNp1mhzG7/vqH31ZBFkwh3BB44nBkNIk/ukSnQcNxXGB07OXEZP5tfEJOnk5Hg3klbOIeiT99jz+MRbAvZmDx1wWn21eviCv0Z1VNLY0fMWBgdexj6JS+O+EO/6Zt3D5TW+weEr8N8KcQ9nP4nv3c19IydG6tvQcF6Y/T5rHFvwSfjT+LkIZQ6dyXvm+0PfgsK7M9+KzAlmps0oqrMPFbvvFrYHWdMIMV4Diu64QZbazYrr0YkAFDiuO4y/eS/zprsb7ybTlyjTnJ8CUYhCUeftXGn57UgRM7X4YDLtVXhiAIgiAIgiBIcr3IBhZ/7aE2rsyt8yZq8g5X/pLn/Zeu0bkLwyv+PiyvYCX5Q2DEZkfrik5HWeGbmff5Q04k2TV/FfPGJi278RZI352eOP2tKXP49kfQtZuCTXUeNYV9jMYmrWCBG/6MJ8G6M2ID6/Xx06tqaikx5cHDbhNnMaPNK+IKldFnYHX4Y+iUOA6C9Pb+pm3cPpPO5qpTbNgax3FbTpwWFzCwNZ3pBg4K0rx9h1it8uon/DjzjcLqp0/5c9Z07ksg9rpJjuMW7PeiaYksxfAi7nPcPFkx/thDnXpu/Ad/t54V4K+o9dyK7dqLAfHr0mJbmUXFl++l7D4TJl4gX+e+DB+5xpxk+Ooy1o7l1tQ9Ew+/auNPT+rAiZ0vcRD4kuorQxAEQRAEQRAkuV5kA2ue+2+30IKX1umTvpsoz/BIls5fNIo/liSvtEznjVnLItPzf1tkuq6hgb/uj06zo9vEWUWPKlmVYzE32P+l2jX/7mt+qwsglr47PZ3p785xYCNuOI4bsHwtf1P8CXqGSXnwUOdnYAaWSq05HBnNyruevcj+P2zdLysx6TOwOvwxdEpnHIz5Tdu4fSZ9zVUsvnHzoKycv6LZc7emL13fQUHizxM0DM36NLwvpj/Zzec3s14LV1J6adVjlqhzRBjpyNXflug2PL6mLfHnLyd/LOZG2yu2ay8G1N66OssbOHKNPMnwxQroW3rsuT89UwdO7HzpDAKThF8ZgiAIgiAIgiBp9SIbWP+au4zdY7RxuV99N1F/n72ksUlL6drm5n/PW07pfXlzlziOs3V0EW+zxXC5/JvhcjL2Fj9Lp9khmHTDX1idFTBy1/vCwll6SWWVzvfu6bvT05fOdzT8rsTwN8Uf1/Bcei/6TrwvvoH1tfM2YZ3fL7Skz8Dq8MfQKX1x6PBv2sbtM+lrrmL9ZeYivkmh81jQtzV96foOCtqdzrcB6IQ/6kffvpj4Q8n4JmPwjTiWHpWcJq6oUmus56/gB+G9JavFZfgyHP/+S9fwt8a34QxXbNdeDKu9dfWV13fkGnmS4YsVMN7A6sCJnS99QSBJ+JUhCIIgCIIgCJJWL7KBJViRV9vcvCHwhOCJ+tDvnWPTs6bs3Ed/GriJOn0zXmdWbHoWS88pKaVlxfniTxYT3xHpMzu6jLW7/+sr5/nwyxiz67/PXsK//U4rKOwjup/Xd6enL73/0jUsvb6xkc3k6jLWrrz6CaXnlJS+O8dBLLbgN8dxm3lz3HQaWK+NmcY2yKDlkEg6DSxjPoZO6YuDMb9pW7bPZKC5isU37+hYEIzD0rc1fekGDgp+w3PwPCyO8/ANW1iBuoYGNojGwL7+MG0ef9iaYCkl/gZbRlcFCEdX/X32kpQHD1kBfSYXXwbir964k7+omWBVcgMVxWpXYSPr6iuv78g18iTDFytgvIHVgRM7X/qCwCTVV4YgCIIgCIIgSFq94AbWwBXr+DYNx3FJeQ88wyOdj57afz4iMTefEtlL0A3cRI34cTvLqn76tNvEWZT+xfrN/MEm1U+f7j9/aeZej5l7PRw8D/PvhcTjkgyYHa3LDLnx6xL8AkbueqHHb5Nl6D7wYsK9NX7HZu71WOF9JDTuDhtfo8+gEd8BxmVls6wNgScokR86vs3E15Sdv70YMaekVLwvvoGlUmv2n7/EyhN9Hb5nuToNLGM+hk7pi4Mxv2lbts/Eb643M+87Hz0lEH9y6Jsae/67CGnM2r6w8Lnuh2a7HtwZco7/qrg2Glj6DgrWDOobG3V+8pYXIxb+9mGm/7RfvC/2jXwuRV1KTK59Vs+yWlZ/v/y71d87j5oimLR4M+P+skP+dDjsOxfO1k0jy6z3olXijyQQP/5bT4U6Hz21+0xYYHTs/eISlk5fvB+v7emsKBCb+SgoHBgdy9bUJ03cvlf8wXTW1RfnNpbXeeQaf5JhYmXaYmA9tzG398TOl4EgkKT6yhAEQRAEQRAESasX3MCi1X+eO5tp7r5fXpdu4F6986gpeT//duez+KAvy3I5FszSDXAlKZXd4TMZMDs6j5oSfz9XsBFBGWN2rVJrfjzepur8N6wZvgOc7XqQZRU9qqQxPkeiflt46MOVTuKPoVJr3pg8m7+G+uDv1gv2JTCwBKtZCZas0mlgGfMxdEpfHIz8TcXbEceZxG+uOtE2N/N/OOsFK3QOARPDN/jae1D8e95vywOdj9e7UPrmE6dZsYsJ98T7MoD3pSjxMl5/n72Ev7KbPuoaGsZu+Un8ecTix18fRY8qP137Y3sr8t+dZ7jw+TuJ4g+ms67OFtL28jqPXJKRJxkSK9YWA0sngsbcrhM7XwaCwCTJV4YgCIIgCIIgSFq9+AaWSq351mUHf3SJgIsJ99htjIF7dZVasyHwBMuNv5/Lz5rj5lleXc1yBdQ1NGw+cUZ8y23Y7FCpNUNW/8AfaFD99Km4TId3TRq1cWdaQaGw2u859Ovb/UgG7gC7TZxV/fQpy/3WZUfnUVPYZCv+MlVi8eejbT35yx2+PgOL/z5BjuPW+B3j54oNLCM/hk7pi4Pxv6nh7TN9/YOOtcAECG6w39TYe4ZHCkavCCiprOK/Va29B8WyQ/4sZZ4uB4HEn7bW2KSlz/ncb3QlKWXEj9vFWyP9ZeYi/iRQMfH3cw2bknzdzLgvrM+jvLp6e/DZt6bMaW9FjuN2hpxrY2Hx6vh8PbeFtL28+Mjl5xp5kmmLgfXcn17cmNt+YufLQBD4Mv4rQxAEQRAEQRAkrV4KA4uWH5q4fa9XxJWryWk5JaVJeQ8i7ia5HAsWvP7877OX7AsLPxwZ7RVxRXyj+9aUOa5nL9LUHvErzLpNnDXP/VBA1LX4+zl5pWV5pWWJufmhcXcWHvDRuUQ6aZ77Idqgvtvyod877ww5dzgy2jM88ov1m8UFOrxrps6jpnz9w7adIeeuJKXeLy6hLdzMuO9x4fJs14N/nbVYUH6260H6zD8eCxY7QeO37aFcr4gr/Zeu6Txqyu7TYZQiuCsWaOCKdWzmlHrTTkpk8Znj5ikoP3zDFq+IK4cjo/eFhQt8hNfGTNt6KvRwZLTPpSgaIGPkx9ApfXGQ5DdVqTVzf92O89FT4jhTq152yF882YpJ5xQqlVrz11mLFx/0PRl7izWY9IdFp2/GOx89Ncxpk+CVau09KGwdXejPPaEXDI9P2RQUQiX3hYXT4Bp938jR/7h64862NGaVWvPhSqctJ05H3E1ijflqctqe0AsGQq1TH650En+S1rls3h8sdzRgXuiryNR/6Zo2Fjb8mfW1QH0yXF5w5ApyjTzJOB0Joo07eB4W5xr46Zl0NuY2ntj5eu5hxWTkV4YgCIIgCIIgSFq9LAYWBEEQBEEQBEEQBEEQZKGCgQVBEARBEARBEARBEAQpWjCwIAiCIAiCIAiCIAiCIEULBhYEQRAEQRAEQRAEQRCkaMHAgiAIgiAIgiAIgiAIghQtGFgQBEEQBEEQBEEQBEGQogUDC4IgCIIgCIIgCIIgCFK0YGBBEARBEARBEARBEARBihYMLAiCIAiCIAiCIAiCIEjRgoEFQRAEQRAEQRAEQRAEKVowsCAIgiAIgiAIgiAIgiBFCwYWBEEQBEEQBEEQBEEQpGjBwIIgCIIgCIIgCIIgCIIULRhYEARBEARBEARBEARBkKIFAwuCIAiCIAiCIAiCIAhStGBgQRAEQRAEQRAEQRAEQYoWDCwIgiAIgiAIgiAIgiBI0YKBBUEQBEEQBEEQBEEQBClaVhwAAAAAAAAAAAAAAAoGBhYAAAAAAAAAAAAAUDQwsAAAAAAAAAAAAACAooGBBQAAAAAAAAAAAAAUDQwsAAAAAAAAAAAAAKBoYGABAAAAAAAAAAAAAEUDAwsAAAAAAAAAAAAAKBoYWAAAAAAAAAAAAABA0cDAAgAAAAAAAAAAAACKRoeB5Xz0FBMSjU+kdJVaQ2JZSOxwYlRyGsdxLF2l1lA6EjucSCHVGW0kdjgxKjnN1tFFnK6zMBLbkohjX45E56On0FClTURDlTwRFyk5EtFQJU9EQ5UjUV86EjuciGNf8kQc+zIl0n8EwMCSN5GfC6QCUZUchBRYBGiowCJAQ5UchFQOEFXJQUglByGVA0RVchBSOeCbhnx+M7AEXgyQBL6JCKRCX2sGHQaHv+QgpHKAY19y0FDlAA1VctBQ5QANVXLQUCUHIZUDHPuSg4YqB/oaKgwseYGBJQf6WjPoMDj8JQchlQMc+5KDhioHaKiSg4YqB2iokoOGKjkIqRzg2JccNFQ50NdQYWDJCwwsOdDXmkGHweEvOQipHODYlxw0VDlAQ5UcNFQ5QEOVHDRUyUFI5QDHvuSgocqBvpDCwJIXW0cXRFVycNqVHBz+koOQygGOfclBQ5UDNFTJQUOVAzRUyUFDlRyEVA5w7EsOGqop0bGIOwAAAAAAAAAAAAAAygEGFrA86E2lQEIQUmARoKECiwANVXIQUjlAVCUHIQUWARqq5CCkcqBvUBsMLHnRF3dgDIiq5CCkwCJAQwUWARqq5CCkcoCoSg5CKjkIqRwgqpKDkMqBvrmuWANLXrCIuxzoa82gw+DwlxyEVA5w7EsOGqocoKFKDhqqHKChSg4aquQgpHKAY19y0FDlQF9DhYElLzCw5EBfawYdBoe/5CCkcoBjX3LQUOUADVVy0FDlAA1VctBQJQchlQMc+5KDhioH+hoqDCx5gYElB/paM+gwOPwlByGVAxz7koOGKgdoqJKDhioHaKiSg4YqOQipHODYlxw0VDnQF9IXx8C6cfPm2XPnGhoahBlmxdbRxexRraqqKisrF6aK2LPX9YuvvoqNvcFx3LXr113d9hUUFAgLKQMTn3YLCwtLS0uFqS8Wxh/+BQUFt+LifpY6UGHnL7i5uz+qrBRmdIjVa9Z+NeLbzKwsYYYMGB/StlBdXX03MbGoqFiYYRzP6utHjRk7dvwEYYa5Mf7Yr66urvx9c9JqtSUlJfyUdvGwsNB9/4Goq9HCjA4RG3tj2JfDD3gcFGbIhlQNtaysvLCwUF9T9A8I8PD01Gq1woxfeW6BdjF+4qSRo0fX1dUJM0yF8Q21vWi12sLf09TUJCxkyUjVUPVRXV3Nj15tba2wBI+MjIzhX3+zwflHYYalYeKGaiCwRUXF1dXVwlQLRO6G2kaKiorF17XxEyeNGjO2jSdGP39/dk5uV0XJMVdIS0pK9LXJsrJyQUfC4jDxsc+noaGhsLDQmBv2ioqKAx4HL1wMF2aYFXM1VD61tbWFhYXCVBGXLl3+/L9f+AcEcBx3Pzvb1W3f7dvxwkLKRhGLuJeWlvZ9f8BHHw8RZrSHvu8P6G7dk/wXwGfAwEHdrXtmZGQIM37PgkWLulv3DA4J4Thuip1dd+ue3r6+wkIvHxucf+xu3bO7dc8jrce5tDyrr78VF5eWni7MsCjy8vJGjhpNUepu3XPp8hXCEm2mrKzsVlzcQ97J97Nh/+1u3TM8IuJ35TrKyNFjulv3vBUXJ8ywQOLv3Pnm25Es7H3fH+B72M/wLWtOTs6tuDh9HTI+1dXVtFlhhoWTk5NjbdO7u3XPsRMmsM7T1m3bu1v3vBx5RVi6bfge9utu3XPa9BnCjA4RHBLS3brn6jVrhRnK5tr166wpdrfu+eHHQ9atX19RUUG5rDnpeyjy3ALthbbWlqb+wrDG0ZH/E3S37hkQeFRYCOihqqqKzgxMDsuWCQvxuBUX19265xQ7O2EG0M9ih6UU22UrftdJKCsr++jjIZSVcPcuPwt0DPf9Byiee1xd+eltPzEKzsltr/jCsGPXLvrW/N4CmS8j1KMo6+ixY7+rA9rG5q1bu1v33Lx1qzCjzZwLO9/duuc3344UZrz0TJs+o7t1z5DTZ4QZv4c6rhs3b+E47qc9e7tb91y4eImwkLJRhIFVWFhI5wJhRnvY4+q62GGpVCM1XiTIwHquS8I3sGgEFt9HUBQme1NpQ0PDoMEfU+McP3GSMNtoqBM8cvQYYYbJMSako8aM7W7d037uPG9f39Vr1nw14lthiTbDP6USoWfPeR7yqqqq+l25jvLCGFixsTfodmva9Blbt22ft2Bhj142Lb3Vvb/rrQqgY/zS5cvCDBGKNbCMaajsiBN0PTdu3tLGsOikoKDA1W2fVM9OLNTAoo89+D9DV69Zu3zlKrodHTBwUE5ODhXw8/f3PORlYIDVcwu0C7PfbhnZUDsAHd2TNFNWr1lLir9zR1jIkpE1pKwXyqIXeNTQrekLY2DJGlUBdP3t069/d+ue7MzAcZyHp2d36569+/Yz5jysHEwZUn18Mfwras+fDRvGT2/XiZF/Tm5XxRcDOqNSs4zgNcuIy5dZM3Z12/e7OhaFGRsqdbr4Xf32UlFR4eq2T2mnCzOGlEEDUOhe3gD8uy0agaXYDoO+QW1KNLBSUlPjbt9mHdn4O3fuJSXR/9PS08mIyczKOnvuXG5eHtvI/ezshIS7bABCU1NTSmrqmdDQ2NgbT2pqWDEToy/upoRvYN2+HR8cEsLmeV2JigoOCXlWXy8wsBITE4NDQtjw46ampkuXL7vvP+Dt66uEJm6yqF69Gk1PYulaxR8doNVqL12+7Oq2z8//SHBICD9cRUVFx44HubrtCzpxsqysjFWprq4+FtSSHhB49FFlZUlJCT3h+cT28+CQkMTEe2zLUVejPTw9PQ95Xbt+nVWXlQ6HtKqqig5e1qioORGPKispFCGnT7PDsKysLDgkpKAVD09Pb1/f/AcPOI5LTU1dvnJVd+ueM2bPDg4JIf/02vXrwSEhrK7ODVZUVASHhOTl5RUUFHj7+np4etLQj6ir0a5u+86EhrKTCXWgr8fGngkNdXXbdznyCsu6dv36+QsXqqurPTw9Q8+eM7A7s9PU1PTViBHdrXtu27GDJQYeO0bjsJjZ19TUFB4R4b7/gJ+//6PKyqtXo8lqdNm0iY76pqamkNNnLv46Bru6ujo4JISMGGZgVVdX+x728/D05LfPM6Ght2/H5+XlsWse7cvN3d0/IEBW47vDDZWg286hn35G/9JkFrGBlXD3rrevr/v+A+EREfTo9UlNTXBIyJWoKP6mgkNC6EAODglhFymO46JjYg54HPT29U1NTWWJlyOvXLp8uampKfTsOVe3fXRol5SUeB7y8vL2ZucWZmBlZWW57z/gHxDAziFFRcV0XERcuuzm7s5+aJ27MzH0sdn9fHV1NT0G1EydRinnL1w4e+4cu0A/LCwMCDzq6rbv6q9TL8UF/AMCXN32nb9wgT39zsnJpZinpad7eHr6+fvX1tZqtVoKKdsUu936ubTUPyDggMfB27dvs6xzYedjY288LCx0c3dnJ1iduzMGIxtqB+BfwflcvRp96fLllgvWpZYLFr8N6zvF/VxaSi0tOibG1W0fG0mXnJLie9jPzd1dqii1C1lDauAxanV19clTp1zd9p08dYoddMzAYlcxdgg/qqyk69GNmzdd3faxSbXxd+54HvLyPOTFZmroK5mRkennf8TVbd+5sPNyT9qSNaoC6Pq7dPmK7tY9d+/Zw9KHfTm87/sDZsyezT8P5+TkePv6urrt8z3sV1RURIn5Dx5QD/ZcWJj7/gO1tbV0HmZi3bCKioqQ06epuyXVuM42YsqQ6iQ5JaW7dc/pM2cN/s/Q7tY92bW7vSdG/jnZvAaWWUJKZ9QFixZ3t+652GEpS5+3YGF3657UWWUGVklJCV3RvLy96W6Lekrnws6zisnJKXT9oj9NeZjrxCxRJfgGFnXg2VmRrvIZGZn8vn1JSYmfv7+3ry/rXtLJ88bNm2ybZo+neUPK4BtYFMysX1dNSUy8FxwSQhcavoFVUFAQHBLCH+ZyKy7Oy9v7gMdB/l2SudA311URa2AJug40aYjmcNJ91ICBg1jW0E8/c3bZSOWtbXqfCwujrM//+wWzaUpKSsZPnMSetH/w4UeXIyN/258JUcIi7nwDSzAEgx9qfveX//+ysrLR48azYHa37rn+hx+E+zAt+lqz5NAl6urVaIdly7pb92QL02i12ukzZ1HLZGE5FhTUcsk/f4HcLlL/DwZSV+BRZSXdNn9i+zmdNc6EhvKjSqM3a2trp9hN56fbz51ngtNHhw//hoaGXn3e627dc+V33wnGP2ZkZFL/adDgwfTFqRt6qfX51fSZs+jRFkUpLT193fr1/C/u5+8vGDNleINz5s2necSUtXrNWrapteuc6CPR1j77fBjLWr/hl8Y8cvSYvu8PoPMGjYnTt7s20uGQPpfMrKzu1j179XmP35tsaGig1kgOVG1tLf+wHTVm7Bdf/fJIlpSRkSE4u/LHFDADi8WqRy8b8vUoa9SYsR98+BG15Nra2gmTJ7cGqmW4Yp9+/aVaEEqMkcc+fcdVq78nB9DD01NsYK1d58QP1DffjnxUWVlRUdGjl02PXjZ0M6/VammQEV34+WOm6KTR/4OBvfq816OXje/hw5T+2bD/fvTxELJ1SBs3b+n/wUD6/wcffkRGFW3ts8+HsQlNQz/9jO7KKIvOPOyg0Le7tiNJQxUYWPRIiT4nDbWg/1OLDY+I4J8kT55q2Tu/wOXISDqWqY2xGRyubvvoVMOCo5k6je57Sb6H/Wjv9Kdta6+AFBAYyLK++XYknY3pV9O3O2MwsqF2AH0G1sjRYwb/Z+gs+zksFG7u7pTFTnH0xT+x/ZxaGp1RWRWaXeuycRPbQnfrnl8M/4r/eMYESNJQ9aHPwMrLy6NLNoVo8H+G5rU+N6UzyeD/DGUXnQEDB1Evi7JmzJpNo2JpKgc9rOrTrz9d9WjujM6Su/fsoT9Jnw0bJqv/YsqGStffiEuX6HtRxyb+zp2Wg3rVd/ze6YWLF/mNrVef98iFoZsudg5MS0+fMeu3w5+1/9u3b9PvxaqHnD4t/DSyIWtDbQvbduxs6ZEeD6IVMH7cuIllUUD4J0Y2Ell8YqQCdE7m/9/0mCWk1CCPHjtOl1f67mVlZdY2vceOn0AXIzKw7iUlUTeYKfTs2aamJuqSsYdbtNRGcnIKx3G7dv/EP8xt//uFrIe5Tkx57AvgG1h0uVmwaBFlUWAFWexWa9Dgj/ndftblUEI8zdVQBfANLH4rpVWAWRbfwOL/X6vV0g0v0/iJk8xlCBL6GqrlGVjUk3A/cIB88eFff8PPog6E/dx59JwnNvYG9RsGDf5Y38qRsvICGFi0sobDsmX5+Q+iY2Joa+Zd7E1fa5aWurq6/h8MHDBwUENDQ3hERHfrnl+NGEFZ1O+kBVy9vH1oLMyz+vpHlZUDBg7q0cvmXFhYQUEBTfMe9uVwjuNOnjrVMviltSdRUVGRmppKY1uowK24OBqFtHvPHpoXlpOTk3D37pBPPulu3fNMaKjww0mNMYf/rt0/0fHbp1//jZs3sy4OmRrk33ke8mIdKbrw0OkyNvYGeUarVn//sLDQ2cWFHnbdiosjO4xvYD13g2scHS9dvkw91959+/n5H6EI9+rzHt2RMgPr0uXLfv7+ZEnQdY6y+r4/wM//CAVc3+7aiDEhNQx938//+4UgfUyrYxV04iRrSJqp0+7fz46Oidm4eUtaevokzZTu1j3dDxy4FRfX1NTUFgNr2vQZsbE3HFs9nc//+4VWq2VZXwz/6lhQ0LXr12lfO3btop5cj142I9SjBJ9NKow89uk7rl6z9lxYGF1KHlVW8g0sunEa9uWXyckpmVlZY8dP6G7dc8u27axbQG4L3XSNHDVaMOkv7PyF7tY95y1Y2NTU9HNp6aDBH/d9fwANbKGT7ZdffxMeEcH6B3Pmz78ceYWme5D5QlujEQrXrl+ntTY2bt7Mz1q6fIV/QMDPpaUGdtd2JGmoYgOL47j3Wy8WV6Nb3Ez65NXV1XV1deT9BQQezc3Lc3N3J7uTX+AT28/7vj+ATomrVn/PgkO9sR69bGhkJdlYg/8zNPTsOZdNLfbKF8O/ol2zjte169e3bm9Z42zQ4I+pE0ZZn9h+fiwo6EpUlIHdGYORDbUD0FV70OCPPxv238+G/XfmbHtKZye9c2FhtNwbW2+Uf4o74HGQtTR2Rl3ssDQg8GhRUXF0TAx5qYmJ9+7fzyYf1sRLmEvSUPXBeqGubvtIdNtJXgkN7vPx9W090tfwJyM7u7jExt6gUystm8Wy7OfOPXrsWF5eHp0uptjZ1dXVVVdXf2L7OV13xCUTE+/Rj3j7dnxOTg4b6yH8uNJhyoZKTTEtPZ3OqzT8hx4YRMfE8Hun12NveB7yopEC5MLQoya6oNO13s//SFVVVW5e3q24uNCzZ3v0sunV57372dkNDQ1k0Hj7+hYWFh7y9qZTfXtPjB1G1ob6XLRa7X8+/czapvejykpms7KHoPwTI3VQP/p4CPWO+CdGeuTPzskvs4EVHBKyes0a5vR5tTYnGhvIrIH72dk7du2iKUFHW8fC06Vw/YYfmFtdUFDAZnTevh3f3brnkE8+ib9z5/79bHoGI+thrhNTHvsC2mVgUf/qSlTUl19/w5478g0shcTTXA1VgJEGVtCJE92te45Qj6IZb7TSruchL+FuTIi+hmqRBlZ0TAybu2Rt05uflZae/nNpKT2RZpYhPWw32WwsPi+AgUV2AFuwgHob7BGuWdDXmqUl7ELLzSH1Vp/V19NYCQojnTq3tt7W0urFu3b/RCOu+cs5P6uvp8etZWXldAMwaPDHvof92Egl6l7w18D6asS3rGPHzj5slJB8GHn4B504QY+pyeajbjr1Gm/Fxd2Kiws5fZqtI0bRGzvhlzfc0Z/kRIvXwGIG1nM3OHrceKpCt6Du+w/Qn3S3TCMLaGt0R00v1ulu3ZPGeFMW2RPszKNzd23EyJAagMwC5t0zxk5ouSugbhbNFhSs9iU4/NtiYJHv/6Smhh4wlpWVsyz2gItCF3L6NMWKzhj8maQSYuSxzwwsrVZLv/6OXbv4BtaKVd+x0X80Nof97gGBR8ktYo+4aUgm38Cinu4eV1cKBd2n3U1MZCdbegNmSmoq3VfQ7AxacJfOJ7Q1NmHhVHDLn/QBKGv8xEnsbsTA7tqOJA1Vp4FFI/Loes3uf6ivOXJ0i/fHhxVIuHuXhvjRl3I/0BIcOg/T+ZANqKQGT3Pi6LrPGjNtjY76pqYmOnuntE6xpCz2VNzA7ozByIbaAejo/vLrb6bY2U2xs2NDAunwpKm+dXV19PXZKXrQ4MH0xanbSr8gnVG/+XYkm9FJJgLdOei8cpkASRqqPlgvlMl9/wEKV/8PBlKIyPWmb00RYBed2NgbdPPPsj4bNoydA7ft2EGPr2g7NLTt0uXL4pL0NGjHzpaHAVzrohniZYykxZQNlRlYdKFfu86JHhN+9PGQpqYmweWJXvSWkZFJhyTd31LFmbNn/267HLdw8RI2LfFeUhINwWC5NI64vSfGDiNrQ30ut2/fpnUYyMyiIZbXf12iUeeJka5KghMjDCx2H0RriUzSTOE47ptvR/boZVNWViawBjiOq6yszMnJ4Z8lyI8e8smnWq3210fdO9l7Y9hhnpzcMuVT1sNcJ6Y89gW0y8Bip1nqKfGz6IKlkHiaq6EKMNLAmj13butt0S+T26gLOmfe/N/tw7ToC6lFGlhsoqa4Vlp6Oj3s4r+bgE5DNMPLxNg6upgrqgxjDCx2s8qmVNDxYOJHrwJMc9qlIEyYrKElXakfQJef2traQYM/trbpPX7ipA8+/KhXn/doVDCN0+EvwEzjsTMyMrRa7cbNW2jIQN/3B9Br9cS3ATSzhr0DNejESdO8G8L4w7+hocHP/wh9wTOhoRkZGYL7ARr5Lx76S330D1sHBRgwsNq+QTpHszEU/EbOH8/FfmJyfARZBnbXRowPqT4uXgzvbt3z/YGD+HNLtVot+QU0hZCmPQpeptsBA4vVpdPI/fvZ4iz+ZA1S3/cHKNzAoqWj6KPS3FUKC137WYjIaaLBbmVlZT162fTp17+uro6eBNITV76BxZ8hSLK26U3nXn47/PW+9L+0F36zF0xIpA9MZqUgy/Du2o4kDVVsYLF2QotZ0P+rq6tp6rS4P8QK0A2AQE6tJj6/a8t+LDpmBY2ZbY3+pAcDca0PBgRZBnZnDEY21A7Av4LzYa4B/cm+vs5T3Cz7OeI7CtapZRvPzcujJ96sgAmQpKHqg/VCC3+ltrY2JydHHCJyk/lnS1qbiTU/QRbHcbTqk0DRMTHikstXruRfvCoqKmhoMysgOaZsqKwplpSU9OhlM2DgIBqu4vyji+Dy9LCwUDN1Gj9cfAOL30Ng416/GP4VdVPpOSI/qpOmtIyP6/B7ZtuLrA31uZDXPHL0aOq40pNFZvpTMNnZj65KOk+MMLDYGbWpqYk6V3SxIHOQbw1UVVWxF+mQWK+eugo3bt6k4a7kD9Jhzu5J6eQj62GuE1Me+wLaZWCxY5l/+POzFBJPczVUAUYaWNRZYrdCNERj1Jixv9uHMlDEIu40tLJHLxv6k1azysjIYMOs2mVg0b0BGyTPfk6TXb2UBq3RQM9YaOoKDTNpamoiU8aAgcVxHI0hYivn0c2eeccTmoDq6mq2QhNfn9h+rtVqb8XF9ehls3DJknkLFq5bv549s6JxOszmYCOwnjz5Zex6UVHxj60riQz99DPW0+WbrdT42Ur5dPbZvKXj75o1MdTp9PP3p543/zBkCB6qXI680t2657etk87oNOrs0tKdJZiv9NwNtt3AoiEhbJgSjeAQGFgGdmd2qPdPvSKWGNX6kLDv+wNoYZphXw7XNwLr/IUL9CeNL7C26U1G2JWoKLGBRT4UG4FVVVUlNrDognf/fvZve1IqfAOL4zhaP4XOkHTjRLea/kcCqAA1LTamki4l5FPT/EGBr0QdKfYSAD7tMrDYCCz+KUVsYBnYnYkRG1g0ed+2ddop//6H+kMGRmDRb8Rizqe9BlZZWTl56zTQID+/ZZKg4E7MwO4si/YaWCUlJTQMUFBefEfBxvqxYa1k/o759Rz+AqBzDSxqVP0/GChehlIwAosCQkaz2JaiuzUvb+/f6reiryQNxqTX6bBVCF4A+E2RDl46MGl9K76BRcuAuB84UFlZyW+NYgOrqqpq8H+G9uhlw9a1oDGe/KDRCCy6p3ixYVaLQLQURrtOjIoysMwC/4xKNz4ULrqB4lsDNBlzjaNjSUkJnUmYgUVv2CR7i40JosOc2QoJCS2jgI15f7fFQauF0InuanRL35W974WGU4ldKgMGFuLJh29gUWd13fr1lLXYYelzDSyqzhauoWcMJhhF0QHMbGAVFBTE37lDc9T/03pL37oug4Zmdty/n71wScvA4HYZWLW1tXSWoVUbyWvgv5zrJaG6uvqAx0E6e/boZUMXHjrOx46fcO369Tnz51MADRtY1JNYvnJVbl5e1NWrfd8f0KOXzf1sc96smuBNpbRklf3ceSylurqa7uHpXULUo6IX39y+HU8d3JKSkl593uvV571zYWGFhYW0LAvdGsXfuUNDY2iqCw04ys9veWzbu2+/W3Fx9AYxeno2Y/bsnJyc+Dt3aA0sE6w41uGQXo+9MWHy5NCz59LS00PPnqURZPRd2Mo+z+rrn9XX34qLS2wdw08Xntaz6oZbcXEjR7csbElj+ijsI9Sj7iYm8pemontUwxtsu4H12efDLkdGenq1/Ii9+/YTL7ZF6NudEpjbevAOGvxx0ImTt+LifHx96aTHXu208ruWqXATJmuSk5PPhYUtWLSYTa5c7LA0IeEuLQhC46r27HUNPXuO7GyBgTV95qxbcXHftVakNeDEBhb17ZavXEWRTEtPpwGGctDhhkoIDCwa4U+iG6fjQUH0MD81NTUzK4sWwvfzP0LlaRYhGV7slQ58X4kKjJ84iRz/goICWpi5vQYWzUq+HnuDGiEZB2IDy8DuTAx9ti+//iY4JCQg8Cj1k/gz99n9z6PKSgqgt6/vvaSkHbt2nQpuudCwAtXV1X3fH2Bt0zviUstLG5/U1FyOjKQFqtprYE2YrImNvUHn4U9sP9f5Oi0DuzMGIxtqB6Cr9o5du2ie2q24OHozrD4DS6vV0ugM/yMBz+rr6+rqbsXFJae0DCUWG1g0FvgT289pDSyafsv8LNMga0h1Glg0Y6i7dc/9Hh51dXXP6uvj79yhqwCdSeiu9fbteAoIDdwT21K0st4Xw7+ijlNJSQm1eV0lW0bXfvTxEFoDi1bgYn6WHMgaVQH8pkjnLv5ijnwDi0pevRrd1NREKzDqM7BoUQvN1GnU5ouKiuvq6sjE8fP3LywspN7al19/Y/ybGdqIKUMqgCa7sYcr/Le78Je1mjBZc+PmzR9ae5v6TowwsPj3Qex47923H/Wd+AbWytaVB3x8fTmOo/tZZmD9XFrKRmbRBA52mA/55BP+YU6riJoSszTUgMDA4JCQYV9+2erp+7DuEN03eR7yomkcYpfKgIHF4plw964Z42mukDI8D3kFnThJ/Svqep09d44eU0XHxJAz+FwDi9a0HTl6dEZGZmpqKv1Sp+VfiNkA+ga1mdnAYreybH1rtkgeqe/7A4Z++lm7DCy6NNIpg8a/WNv0PnbcDPMHDcTdBBQVFbMwLlu+ghIzMjPZ65/6fzCQVh41bGDl5OSw5Y0omGYffmWCqJJtJ2g2lOjs4vKwsFDwzpHR48bTmmuHvL3ZG7LoMSD1Wf0DAmhQK+VS11+r1VL/mDncJSUlLIWcR9OchTsc0qysLH4oevSy2ePqSlnXrl1nL1kj0T0/HfWDBn/Mxrh99vkwWpShqKiIJYrfQmh4g200sN7r158GXpHYPZjYwNK3OyVQUVExk/fyNYr8xs1b2MS9h4WF/MOWRgrQVAsSnSrpWkXSTJ3W9/0BfAPrq29GsMe5ffr1pyui2MD6ubSUBnwxzZglXKNEKjrcUAmBgcXe4sdunBoaGgSBXbBoEbvzoVmElE7zBwW+UkNDg2DmCxvE1y4Di87MpC+//oacQbGBZWB3Job6SXx9Mfwrvo9JiXT/c7j1/QmsJD1q4hcIOnFCcIKldevaZWAN+/JLegBAl60LF8PFn4TQtztjMLKhdoDFDg6Cn8D9QMvJTZ+BRcM22Uv0SDRKSGxgabVauvwxzZw9W6ZpwvqQNaT6DKzbt2/z3zXMLhl0Jpk4WSN+W6jYluI4blHrs1gmWrxVZ0nBfMNJmimyrj4ua1QF8Jvio8pKCh176MI3sGjBIOqm0ors+gwsGrTORFmhZ8/x33M6+D9D2bqiJsCUIRVAz6gEHRUaPklrWrfrxMhPEeeaErOElH8fxFYToxc1CAwsGr1OzfWDDz8aNPhj/sIg7HWu/PXFTHyY68QsUWXrHgwYOIi915u/GIJ963R1sUtlwMBSSDzNFVIGrRzCn09dW1vLbgSsbXrPnG3/XANL8AZz6nOKxyCbEn1zXc28BlZZWZmzi8vqNWv9AwLYcqEcxx07HuSwdNnuPXseFhaGnD7NHJOAwKOubvvYGtju+w+w1cQFWfF37mzeunWxw9Kt27bzzxomxoyLuGu12pDTZ1zd9p0LC+PHNisry/OQ19Fjx8rKylJTU4NDQqgbmnD3bnBICL32hf9/mkB0JjTU1W2ff0AAW83djOhrzRJyJSoqOCRE8OrQnJxcGm+1wdmZ7ruqq6szs7Kog8XGGmRlZfn5H3Fzd794MZxtoamp6fyFC65u+9z3H2AzBGkAvO9hP1e3fbRSDN2Unr9wwc3d3c//CEuUG2MO/6KiYv+AAFe3fb6H/QRD834uLT167Bh966ir0XRKZReetPR0N3f3o8eOscOW3ufi4enp4elJwweuXb9Oa7EZ2GBFRUVwSAjznpKTU4JDQtgS45cuX2aNPDom5vyFC3V1dQGBR933t7yMj+1XsCNC5+7aiDEhbSM3bt708z/i6rbvVEiIeFBkdXX1qZAQV7d9QSdOsnew3rh5kw5k9l3CIyJc3fZdiYqiJkrjBLVa7ZnQ0Nu34ysqKjwPeXl5e+fk5FJ5yqKV7xkNDQ1nz51zc3d3ddsXeu6cfMNdjTz2q6urg0NC+FeE2traM6GhIafP8A/2q1ejPTw9vby9BXMwKSs4JIS/0nBJSUlwSAjNgqH4XI68csDjoKvbvmNBQewsSqcUaod1dXXBISE0d5XjuLy8vOCQEBq3WFRUTOfe+Dt36LdjbVKwI0Lf7tqOJA2VwkgjUinC/ItO61JT58+EhrLE1NRU38N+/GNQUOB+djadVTw8PeN+HYJKZ2DmxcTG3ggOCaGzBzVLNj32XNj52NgbVVVV3r6+noe8KLYsi78jQufujMHIhtoB7mdns/iTaBwZtVjWm6evz/qj/FNcdEwMheXn0lK60v1uB78eF56HvMzyShxJGqo+ntXXh5w+w9oPn0eVlceCglzd9rm5u1+JiqIz56PKyuCQkLy8vIyMTDd394DAoxUVFax8cEgInUj5xLa+Wc/VbZ+f/xG6POkrSe/g8/D0jLoaLfedgykbKl1k2cWIWia7+icmJgaHhNAUeHJX6Zz2pKbmXNh5ao0FBQXsVMnfJhM7OTwsLKSbgtCzMl6PdCJrQzUM/5TIoKDRygntOjHyU8S5psQsIaUGSR1RmpgWHBLCVlOhixHrd91LSnJzd/c97FdSUnL1ajS9t5QIOX1G50RgUx7mOjHlsc9ITU1133/Az/8Iv6/yrL7+6LFjHp6eiYn3ntTUsAOZ+vbsDMk//AVZSoinuRoqIzb2Rss583jLOZMllpWV+R72a+3D51D3kg3YZ8EUnFebmprCIyLc9x/w9vVNuHv3tx2YCX0N1cwG1guPGQ2sFxh9rdlk0HyBw60D1BPu3qUlGNiIDEvElIe/4MnJi4opQ/ryYPZj/8UDDVUO0FAlBw1VDtBQJQcNVXIsOqQ0OIjeVK4ocOxLjkU3VMWir6HCwJIXGFhyoK81m4zwiAj+m9c++PAjc81RlQpTHv4wsECHMfux/+KBhioHaKiSg4YqB2iokoOGKjmWG9Kqqiqany4eI292cOxLjuU2VCWjL6QwsOTF1tEFUZUcJZx2n9XX30tKuhUXl5aeLphpaImY8vCvra29FRdn0QPW2oIpQ/ryoIRj/wUDDVUO0FAlBw1VDtBQJQcNVXIsN6T0cgw2s1VR4NiXHMttqJaImRdxBwAAAAAAAAAAAADAMDCwgOVh3jeVvpAgpMAiQEMFFgEaquQgpHKAqEoOQgosAjRUyUFI5UDfoDYYWPKiL+7AGBBVyUFIgUWAhgosAjRUyUFI5QBRlRyEVHIQUjlAVCUHIZUDfXNdsQaWvGARdznQ15pBh8HhLzkIqRzg2JccNFQ5QEOVHDRUOUBDlRw0VMlBSOUAx77koKHKgb6GCgNLXmBgyYG+1gw6DA5/yUFI5QDHvuSgocoBGqrkoKHKARqq5KChSg5CKgc49iUHDVUO9DVUZRlY1dXVWq1WmNrKs2fPhEmtGKiiBMxuYFVUVNyKiysqKhZmcFx+/oN7SUnP6usF6QaqcBxXWlqakHC3urpamGFC9LVm0/Csvj4lNVXnywe1Wm1aevrPpaWCdANV6K18Kamp5n0rnxIOf61Wm5mVdS8pSWfrys3LE4fIcJWGhobMrKyMjMyGhgZhnvyYPaS1tbV3ExPv389uamoSZFGDrKqqEqQbqEIn23tJSUVFRcIME2LeY59oaGhIS09PSU2tra0V5nFcRkam+ORpuEpdXV1aevr9++Z5zbbZG2p1dXX8nTvio5udG5/U1AjSDVThOK6ysjIh4W5FRYUww4SYt6FqtdqMjMzk5GRx6DiOy8nJyc9/IEjUWaWurq7w95SUlPyumgkxe0OtrKzU1zWqrq5OSU0VX991VikpKRFEVVzRZJi3oTY0NOjrGlGDFLc3nVWe1NQIQlpWVv67aibE7A21pKQk7vZtnRGorKxMSU0V94h0VhGEtLCwUFzRNJg9pHV1dfeSkjKzssQRoAZZWVkpSNdZpbKyUhBScUWTYd5jn3r1CQl3dUagpKQkIeGuuL8krtLQ0CAIaWFh4e/qmBCzN9QnNTUJCXdzcnLExkhdXV1Kaqr4XklnlbKyckFIxRVNhr6QKsLAelZfv2Xb9iGffNLduqe1Te9Z9nPyH/zWuzrs72/73y+6W/cc8smnu/fsoRAbrlJUVLx0+YoPPvyou3XPvu8POH/hAssyMbaOLuaKalZW1tjxE7pb9ySNnziJGStPamqmTLOjdGub3lu3bX9uFY7jzoWFDf30M8rq0csmOTmZZZkYM552N27e3KdffwpC/w8GngoOYVlBJ06wrC+//ubhr+dQA1VKSkoWLFrMAr56zRqWZWLMePgT/kcCPvp4CGuTO3btYlm3b98eNPhjyho0+OP4O3eeW+VZff2PGzdZ2/RmPwfLMhlmDOmz+vrlK1f16vMeff3B/xkaHRPDcl3d9rGs6TNnkY1luMr97OxJmimsobq5u7MsE2PGY5/YvWdP/w8GUhz69OvvfySAZYWdv9D3/QGU9dnnw3Jycp9bpaKiYvnKVSyw8xYsZFkmw4wNtaKiwn7uvB69bOjrD/vyy+TkFMpqampa4+jIspavXEXPWgxU4Tgu4e7db74dyeIZcvr0bzszLWZsqL6H/dgJs1ef93bt/ollxcbeYFlDPvk0MTHRcJV169ezYDKdCzvPNmhKzNhQc3Jy+SfA0ePGset7bW3tnPnzKd3apvemzVuoj6qvyv3sbHFIJ2mmCHdpKszYUHfs2sVOmH3fH3D02DGWdSY0lGV9+fU3eb9a1fqqzJg1WxzVu782bxNjxoaakHB3hHoUi8D0mbPYbWdZWdn4iZMovXfffp6HvAxXCY+IEId05arvfrc/U2HGkDY0NKxxdOzdtx9FYNDgjy9dvsxyPTw9WdaEyRrqTRmo8ont54KQ9uhlY65nLWY89i9HRn42bBgLwvKVq5jNl5OT++XX31B67779LlwMN1zF85CXIKTdrXvu3rPnd/szFWZsqFVVVQsWLWZ3PZ8NG8bulbRarQvvhmjBosXUm9JXpa6ujiUy9X1/gHCX5kYRi7hfiYqig3zIJ59SpMaOn0BZJ0+d6m7d86OPh6xc9R11sPbsdTVcpbq6mgyvSZopGzdvmTN/Pv+6+PJAt6nTZ84aPW48hWjV6u8pi0yTKXZ2u/fsoaiGnj1nuMq1a9d79LLp+/6AbTt2Bp046ezikpmV9bv9vQRUV1dTd8p+7lzqRfXq815ZWRnHcbfi4rpb9xwwcNCOXbtm2c9hDdJAlYaGhlFjxna37jnLfo5/QMABj4OsS/ES8tmw/w755NM58+YP/s9QanvXrl+nXlfvvv169LJx2bhp9Zo1ZALSo1d9VTiOW7/hh+7WPUeOGu3t6+t72M/ZxUW4vxeatPT0lq8/evQs+znkSX3w4Uc0qOpUcAjZK7v37KHDfOnyFYarVFVVUa9r6fIVR48d2+PqyjdhXzZaTZPhs+fOHTBwEPU+6dlJampqj142ffr137ZjB51gvxj+leEqWq1WM3UanYr9/I94HvLa6+Ym3N8LzfkLF+hJyfSZs+gQHqEeRVm7dv/U3brnN9+OdHXbN+zLL7tb99yxs8WhNlAl/8GDAQMH9ehls37DDydPndq2Y+eVqKjf7e/l4IMPPxr66Wf2c+cyf//GzZv0YK93337WNr03bt6y8rvv6IJFHVl9VQ77+0+xs2Mi35B///aS4Obubm3Te9r0GcwCYF4zGdCTNFP27HWl6FGHU1+VoqIifkjp1DrFzk64yxedJzU1dGKcM28++fvsxJiYmNijl03/DwZu27Fjbqs5SI+gDFTZufsnFtIJkydTwNPS04V7fdFZs9axT7/+s+fOZT6+y8ZNlEVhmTN//q7dP9EjVXpGpa/KvaQkfkOltm3Gh6zmIiMjg64yc+bNp65R/w8G0mkzrPViNOSTT3bt/onc6gWLFhuusmr19yyk1P/v0cvGjGNbzMW06TM++PCjOfPm0916d+ueAYFH6cEVnRJXfvfd5q1be/SysbbpTeOF9VWJuHSZ31CpbbvvPyDc5YvO5cgrLTeeEybMsp9DV2rWBSWP74vhX+3Z60qH+cbNmw1U0Wq1M2bNZiH9asQI8luEuzQ3ijCwcnJyToeG0mOrpctX0CFNRzs9GaD7UjKtBv9nqOEqbu7u3a17rlu/Qbibl4y09HQ2cJ3GVQ1v7QSUlZVZ2/Tu+/4AcgF8fH27W/e0nzvPQBWO4+hG63Jk5G87MB/melOpVqtld0ShZ8/ROZQ6AStXtdwP+Pn70yNZevaSm5dnoAo94Jo+c5Z4qKfpMVdIGVejo8kuyX/wgKLk4enJcZyXt3d3655r1jpSMbrkh7WOqdRXpaCgoEcvm6GffiYefvySUF1dfft2PP3/gMdBCg4d2tTNogOZ4tanX/+6ujoDVejit8H5x9/tw0yYvaFejrxC/7l6NZqidC4srOXJ248ubGxaQ0MDjf+9l5RkoMqNmzfJ6dY5YfNl4GFhYUZGJv1/7Tonuo5TAMmVptzY2Bv0eNBAFY7jNjg7d7fuqZDHAGZsqOzEmJmVRe2NLkzUNWIHMnVkL11qcaP0VeFDv8KgwR+LZ3uZBjOGNCsrq6CggP5Pzunn//2C47hHlZW9+rzXu28/mncZEHiUuVH6qgigX+F4UJAww1SYMaqsP0l9+9YLU8upco2jY8uB7NVyIDc0NNCTP3Kj9FXhE3TiZHfrnl+NGCFINxlmDGliYiIN59FqtZ+33udPmz6DJrZ3t+75ie3ndJhv27GDuVH6qvB5Vl9Pj7rZM8KXh7q6utjYG/R/38N+1Oro+f206TNYd/Tn0lJ6Pv2ostJAFT679+xhN19mwYwN9cbNm3TOrK2tpQN87TonOsBbx7JNpmILFy9h3Sp9VfgUFRVZ2/Tu0csmJydHkGUazBjSn0tLqcNJ836o1dXW1mq12mFfDmfd0du3b9OooKamJn1VfrfdXx/SmPEWQN+gNkUYWHxc3fbRuEGahElnBHKmamtrKb6CpVv4VTiO+7bV8xKfLMyCvribGDrPUr8qstVzHT9xEmXF37nT3brn0E8/M1Cltra2Ry+bjz4eotVqzbu4AKGEqNJ5lvWr6MLPhqyPaR3bwsa+6qxCszNCz56jWfHiqfWmRAkhJYqKiilKNMxnsYMDe6bd8jldWmwCwfBgQZWjx47RU0RaF0N8On6p8G51qHv1eY+uZDQwmB3C1Cu9n/271Zf4VdipIOHuXZoVb16/VTkNlfoB3a173oqLY9Yqm3dJt6xBJ04aqLJtx056ilhVVVVYWChejvClgg7tIZ98Sutc8J/4sUu/wDrhV2En4Z9LS0tKSnQuVGRKlNBQ8/N/cfZpFQX7uXO7W/c8ExpKuWT/HfA4aKAKHxpZzJ+pbWKUEFKO4+bMaxkTRLdY165fb50eOJ6ykpNT6N7AQBU+0TEx1M7NeJFSQlSvt3qj7BbrqxHfdrfuyea/0EOXs+daZgnoq8LQarU0XsCMEy+UEFLmjS5fuYrjuGNBQd2tey52WEpZFy6G08gLA1X4UJ/qqxEjzHX1V0hIyRvt0cuGZlG81zrYhy3T9p/WJVYSEu4aqMKora2l3hd/rQYTo4SoarVaGk3p6raPjbxmy9p4eft0t+7psGyZgSp8yIWZZT9HkG4ylBBS5o32fX+AVqutqKggh4TM64aGBhpsVfr7xZr5VfjpRUVFvfq816OXjeA2wZTom+uqiDWwGOzaQzPX6GHgoMGDWQFqtey5lrgKx3E0YnPuvPm9+/br3befZuo088bd7FHNf/CAYsK/vZ8zbz7l0ooM7/Xrb6BKWlrL9KIBAwexuVrffDuSrfBievS1ZlOyaEnLk4GRo0bTnzTkiq2MO8WuZYmxY79/rCqoQmWG/zrZu1ef97x9ffnlTYkSDn/Cff8Bamw0rJo6r8wKJLda8ChAUGXrtu3drXva/vcLtqLTuvXrTd/xUkJItVrtyFGjWZeUHgl0t+7JCnw27L/8WwVxlZYyn7esO8Aaav8PBgqcWVOihGOfoGECtv/9gpoWnRvZyoALFi0SjwYSVJm/sKXMF199Rf0Ja5ve4g6ZCVBCQ62traUVLWn1pYSEu61Drv7LClDb46/oLKii1WrZGHgqPPg/Q2/fvs3KmxglNNQ9e13JTyF/ZOyEllHVbALgxs1b+LcKOqswqJ9gbdPbjO9wUEJDfVhYSFNU6OJ+9lzLqGo2AbCwsJCiZKAKnxmzW1Zu2rZjhyDdlCihodIT/m++HUknRpqtxiYA0rnUP+C3pQPFVRhRraNcP/jwI/N6gmZvqPeSkug0SGOmaFT16jVrKZeWvBj25XADVRharZbWJKIZW2ZBCSHVarXUHaUxUzWtE1q7W/dkEwBHjh7T3bonf966oAofGq355dffmL5rylDCsU9rAljb9KYxU2vWtvSRWEcoOKRlyQu7mTMNVGFUVVXRyKyoq9H8dFOihIb6rL6eZllucHZmE1oHDBzECtBaFvxRPoIqfDZv3drduueM2bMF6aZEX0NVloFFJ9kBAwfR2uE0OIjfi6W48w0pQRXW07X97xer16ylOzEzjiU2u4H1rL6eJgOyEygNr1iwaBH9SV0uNn5NZxW62lnb9F753Xde3t60dI5Z1hsm9LVmk3GidWm23n37ZWS2TGbRarXU6tjLL8ic4j8DFFRhV7uvRozw8PR0dnHp0cumZUEH0cuhTIMSDn96gk19/bDzvzz/F9x0kYG1fsMPBqq4bNxE92C79+xx33+ALmnhERGsimlQQkj3uLbcjg4a/DE9/SsoKNBpYMXx7vMFVdhZd5Jmipe3Ny2dM2jwx+YaLmT2Y5+4cDGcVmdIuPvL41Z6uCK46aI5rfqq0Fli2Jdfuu8/sHXbdhocl5qayqqYBiU01FWrvyfvicZY0eRKsYHFH1clqEKrDdKFycvbx37uPLq/ZeVNjNkbakLCXXqswuZY0eB0gYG1eetWA1UYtP4gG8FhFszeUBsaGmgtBTbxnxZpFRhYbE6rzioMWnawRy8bM3qCSmio58LC6AEeexuDznMpf06ruAqDTqoCW9bEmL2hVldXk+W0xvGXtRfImBYYWPw5reIqjIjLl+km6yX3BA94eFAc6DJU2jpn0LCBJajCYLM1BbasiTH7sf+wsJDcavZeIIdly7pb92TP8sUGlrgKw8PTk7oEZvQEldBQ163fQAvd0oxLehxo2MASVGEwT9C8y4nqa6gKMrDOhYX16GXTu28/ml6hcwQW9a7YKxvEVVhPl/ysR5WV9FRW/MJ402BeA0ur1S5sHfXz1YgRLAJnQkP5s9zJnWVXMp1VkpOTaf48/UnHw39Esw5Nhr7WbBquXb/eq8971ja9I1pXDyEGDR7cumJLBv1JT10if70N0FmFyjBjhUxDc41tMfvhT/YKDWPhz1KheSshp8/Qn7R2A5tCqLMK3ZixFPKzTD/zxewhpZurvu8PYO8aq6qqotMjs5/oJRjskYC4Csdx9O7RlFZjRavVUu+B/jQ95j32iYS7d8kz5TvUtMoAswJp0hBrtzqrUJmTp35pJPQiLcGsQxNg9oZKnung/wxlY6tTUlPZepfkAlC7ZVMIxVWampqoDF229C04YDLM21BzcnLpOOWvZUtOCnuH4AbnH/lTCHVWIUpKSmg0K1smzyyYt6FqtdrVa9bSoIlHv77EnRayZAsy0NRXNoVQZxUGjSFatHiJIN3EmLehxt+506df/x69bPgvDKVVnNmCDDT1lU0h1FmFoDFEPXrZsHdEmgXzNtRn9fU0sm+SZgq70NNza3phC5v6yqYQ6qzCoNXf+U636TFvSGkFW7rZZItbsasSW5CBpr6yOa3iKgxa/b3/BwPN6Ama/divqqoiz3Tld98xy4nev8TMKRqnxmYD6KxCNDQ0UE9VvHqjKTF7QyUX74MPP2JzpOiqxDew6GrOjBRxFQZlDftyuBk9QYqqMKkVpRhY0TEx1ja9rW16X+WN/aOpmz162VAftKSkhJYcplDqrMKmcty//8stGXle5urF2jq6mDGqtMjFl19/w599Tc9e2L0BPctic4Z1VmFzaOnaRp4XW9/d9JjxtJuYmNj3/QE9etmw205i5OiWsX7s4TY1Qhrgqq8K9V99D/vRn7TSEL37yfSY9/CnBQhpqtrGzVv46fTkn15A1tqXbRlYQT1XfVVo0XH2vufNW1pGwIof18iNeUNK43169+0nWGGB/3C7trbW2qZ3rz7v0VMXfVVoEBxbPZfaNn8etykx47FPZGRk0gLtvocP89PpyT97PyPNuCQfUF8VchDYaHlar5TWdzcl5m2o3j4td1YffPhRFu95YGXrkyd26adHWeyapbMKm3lES7w/q6+nUcPmWlvQjA31YWEhWQDbduzkp9OYNdbeaJk2am/6qhA7du3qbt1z1JixwgzTYt6G6rKp5UHIZ58PY4P9mdP6wYcfUadU4GfprELQwiJm9wTN21BTUlNpLEBAYCA/nZxWdi6lZwN0LtVXhVjW+kIns3uCZmyoTU1N9AR61JixfHOEWubI0b+sX8H3s/RVIRIT78ETvHo1mm42BUNTyTGhierP6uvpKTVds/RVIejNpOb1BM177NfW1tKyofZz5/FfYkNvGmFOKz1+pt67vioEvV/b7J6geRvqseMtS931fX8Af2XAuro6utbw52F88OFHBqoQ7F065vUEDaCIRdzT0tPJZnJ2cbkVF0eiYZnk/e9xddVqtbTkLb04w0CVeQsWsgEXp1tHG7F3Sb5U0OvbrG16H/T0DA4JIT2pqWlqaqK1A719fTMyMumMEHq25emWviocx5HtvdfNLT//Ab32cd369cJdvuhUVFTQjejM2fYsPomJ99jUtgmTNRkZmTStdez4lqdbBqqwdTEzs7IiLl3u1ee9/h8MfAnfp8tfd2n419+wKJExfelSy/D1wf8ZmnD37oWLF3v1ea/v+wOe1NQYqJLaelMxYOCg+Dt3Eu7epYVyBCtrvthkZWXRFWv5ylUsOHS3T4bgosVLMrOyfmg1UGiBTANVaE0x+7nz8vMfHPb356/i9LLxpKaGmtMkzRQWJboFpZcNjVCPSktP9z8SwK47BqrQw4PPPh+Wlp4eHRPT9/0Bvfq8Z977BBNDi1jTKxdYcGi2BV36nV02ZmRk0BwiWirIQJXFDktpCkxhYeH21t7CVLvpwl2+6DQ1NdGqoPwTI1nS9Nh/6KefJSYm0uj1AQMH1dXVGahCtw1kGTBD4SXEP6DliO7Ry8bVbR8LUVVVlVarpZWb3Q8cSEtPp2HUtFSQviq0QTqpMkPhJaSqqorujvgnRlqNkR5BjRw1Oi09nawWOpcaqEKeIM234E/IeNmgdtW7bz8fX1+KT8jpMw0NDU9qanr37dejl03QiRP3kpJovRvqL+mrQhukk+qCRYuFe3ppyMvLo9HTCxYtZq2OHpPQIyj7ufMyMjI2tQ78p5VVDFRha+P06GVjrqeASoA80w8+/OjoseMUHxoanJOTQ+NULkdeuXHz5gcffsRWVtFXhaBL2MbNm3+3m5eJ27fj6QTo6OTEWh21MXrwv8bRMSMjg+7ff9y4yXAV9v6Bvu8PMK8naABFGFjkuQpE49hjY2+QUUUa/J+heXl5hqsk3P1lHQf273XRAM6XAer0C0SX9gsXw2m9FdJih6XkZxuociUqil/lm29HiofEmwxzvamUBq8JRKuJVVVVkRVIGjT4Y5pjZaBKXV0dv0qvPu+Jh8SbDHOFlGDr1/BFK+A0NTVRF4pkbdOb3qJloAob3cZk+vmD5oUWDhCIxqk9LCykYWsk2/9+QY6JgSplZWX8Kh98+BF/zSwTY96GSsvWCMRe1UqTgkn9PxhId1YGqrD1cUjWNr39j5hzRQzTQ76/QDQoNeHuXbL+SaPHjaebfwNV7mdn0wBD0ie2n5vx/S3maqjsRQ180YmxoaGBHu+RevV5j2asG6jCBmsMGvyxucayMcwVUo7jqNMvEA24vnTpMr+Paj93Hg1UN1DlSU0NLSwiGJRtFswV1buJieL40ImxurqahqiQ2LnUQBWO435sHawxQj1KuCeTY66QsqE9AtGA64DAQLpZJa1d50RPoQxUyc9/QFXMNTNACdCiKwKtWduyUlhRUTF7ZwhdcWgSloEqbIyFGRcRZpixodJDEYHIKKFVw5nYQqIGqtBjLTMuIswwY0h1do3cD7S4Imnp6ewNbPTghEZjGajC3o9HVpd50TeoTREGVmpqqqvbPoGSU35ZnfFeUtK2HTuXLl9xwOMgWwnPcJW09HSXjZsWOzhs3bZdMMvAxOiLuwlITU1llioTG+CTmZXl53/Ew9Pz6tVoNhrTcJX8Bw+8fX3d3N3PX7hg3r6suaJaV1cXcvqMID40nIp6XUePHXN12xdy+gx7W5bhKg0NDefCwlzd9vkHBJAzay7MFVLG+QsXBFFiqwY2NTVdiYo64HHQPyCAf0dqoApd0tzc3b28vfnLOb0kPKqsFESGDaciQ+pMaCi1OmZDG65SW1t78tQpV7d9R48dE0+HMSXmbagNDQ1nQkMFUWIP/Gtra4NOnHR123fy1Ck2kMpwlaampvCICFe3fX7+R8x7qTILBQUF4lbHQvewsDDoxEk3d/dLly+zZ4CGq5SVlfn5H2k9CZ8WLEdqYszYUM+FnRfEhy2z0NTUdDky8oDHwYDAo/xXOBmocvt2fOs1y/xnUTOGNC09Xdzq2MkzJyfHPyDggMfBK1FRrDdloAqdbM+Ehpq3H0WYK6oNDQ3irhGbUFlbWxseEeHm7i44lxqocvVqNP+aZUbMFVIa3SNudWxZq+TkFN/Dfp6HvPgP9Q1UeVhYGBwScv7CL6/HMSNmDGlVVZU4PuxdK48qK6kPH3ruHFt3xXAV6rgqYai1GaNKRytfbJE7juOux97wPOTle9iPP6/NQJWsrCz+NcuMmDGkdLQKlP/gF0evpKTE85CXm7t7eEQE6xoZqNLU1EQnWzMOVWHom+uqlDWwXlTMu4j7i4q+1gw6DA5/yUFI5QDHvuSgocoBGqrkoKHKARqq5KChSg5CKgc49iUHDVUO9DVUGFjyAgNLDvS1ZtBhcPhLDkIqBzj2JQcNVQ7QUCUHDVUO0FAlBw1VchBSOcCxLzloqHKgr6HCwJIXGFhyoK81gw6Dw19yEFI5wLEvOWiocoCGKjloqHKAhio5aKiSg5DKAY59yUFDlQN9IYWBJS+2ji6IquTgtCs5OPwlByGVAxz7koOGKgdoqJKDhioHaKiSg4YqOQipHODYlxw0VFOiiEXcAQAAAAAAAAAAAADQBwwsYHmY8U2lLyoIKbAI0FCBRYCGKjkIqRwgqpKDkAKLAA1VchBSOdA3qA0GlrzoizswBkRVchBSYBGgoQKLAA1VchBSOUBUJQchlRyEVA4QVclBSOVA31xXrIElL1jEXQ70tWbQYXD4Sw5CKgc49iUHDVUO0FAlBw1VDtBQJQcNVXIQUjnAsS85aKhyoK+hwsCSFxhYcqCvNYMOg8NfchBSOcCxLzloqHKAhio5aKhygIYqOWiokoOQygGOfclBQ5UDfQ0VBpa8wMCSA32tGXQYHP6Sg5DKAY59yUFDlQM0VMlBQ5UDNFTJQUOVHIRUDnDsSw4aqhzoC6kOA4v+I/gZkNixRFtHF/Z/cS4SO5bITrtRyWksnS2eh8QOJNJ/xKEmkNiBRH5uW8ojsS2JOPYlT6T/UBZLN/ATILEtiWiokifSfyiLpRv4CZDYlkQ0VMkT6T/iUBNI7EAiP7ct5ZHYlkQc+5In0n8oi6Ub+AmQ2PZEMToWcddZE4kdS/S5dNXlWLC+XCR2IHFP6IU9oRcovS0nFCQ+N3FP6Pn3l62ldJaoL/5IbHvi6M27Ju9w46cbLo/E5ybO3Xco4m5SW1o1EtueOHrzrmVe/iyRRIXFPwES25g4evOu07fixdHW+RMg8bmJFE/KYumGfwIkPjcxMTefrv5t+QmQ2MbEmxn3J+9wZYkG4o/EticayEJiBxLRm5I8ERcp+RLF6DCwgITsCb2w7JC/MBUYwXPbNGgvD8rKNwSeFKYCo+FfzIAkIKRyUFr1uPZZvTAVGAeiKi2IpxzUNzYWPaoUpgLjiEpOs3V0EaYCoCTQm5IchNSUwMCSFxhYkgMDC1gKrmcvJuTkCVOBEaB/AAAAQMnAwJIWGtEmTAXGgd6U5KDPb0pgYMkLDCzJgYEFwEsLulwAAACUDAwsaUE85QC9KWDRwMCSl6qa2kdPaoSpwAgePampqqkVpgIjKKmsuphwT5gKgPLANCI5mLzD9WbGfWEqMA5EVVoQTznA2BY5qGtoKKmsEqaCjgIDSw7QmwIWDQwsAF520DmQiYsJ99CLBcrH1tGFLUoKpAJRlRbEUw5w9QfKB60UWATo85sSGFiy88PRkyq1BpJEzc3NwvgCo0HnQCZwxwUsAjRUOUBUpQXxlANc/YHywYg2YBHgImVKYGDJSHNz809nzv+/yfarPH2Li4ogI6VSa7Ra7Y9HT3lfihLGGhgBurAygYuZ5GAakRygocoBoiotiKcc4OovB5iYCZQPelOSg4uUKYGBJRfNzc1arXZDQJBq5GQYWJJIpdY0NDQ4HPT96UwYhmJJSPrDoq0nQ4WpwGhwMZMchFQOSiqr6hoahKnAOBBVaUE85QBjW+QAtiBQPuhNSQ5CakpgYMkCuVeNjY1OfkdV306CgSWJVGpNbW3tkgPeP52GgQUsgK0nQ9MfFglTgRGgfwAAAEDJwMCSFoxokwP0piQHfX5TAgNLFpqbmxsbG+vq6tZ6H1GNmAgDSxKp1JpHjx4t2ue5K+SsVquFhwXAywa6XAAAAJQMDCxpQTzlAL0pYNHAwJIFrVbb0NBQU1OT/eCB/U/uMLAkkUqtKS4uzissLH1U2dTUBANLKkoqqy4m3BOmAqA8MI1IDrAWhhwgqtKCeMoBxrbIASZmSgsMLDlAbwpYNDCwpKe5ubmpqenZs2ePHz8uKipycPeEgSWJVGpNXl5eeXl5bW1tY2MjDCypQOdAJvBKXWAR4EmsHCCq0oJ4ygGu/kD5oJUCiwB9flMCA0t6yMCqq6urrKx88ODBItcDMLAkkUqtyczM/Pnnn2tqahoaGrRarTD0oEOgcyATuOMCFgEaqhwgqtKCeMoBrv5A+WBEG7AIcJEyJTCwpIcZWI8ePfrB63C30VOMN7AysnMysnPE6R3Ww4cP45JTHhQUiLNk0qVbt++mpYvT2y6VWpOenr5qv9eBsxdgYEkIurAygYuZ5GAakRygocoBoiotiKcc4OovBxF3k+buOyRMBUBJoDclObhImRIYWNJDBtbTp08rKiqWu+5XDR/TRgMrKj5h76nQvadCAyIiL964VVhYyLL+19hpnUdNycrJFdd6rh4+fPj1+k2fr3HOy39AKZ5nL/yf8dNVas2g5WsPnbswZJXTnlNnxBU7IH1b23r0pEqtmbXbXVyl7VKpNampqbN37NkeFAwDS0LSHxZtPRkqTAVGg4uZ5CCkcoC1MOQAUZUWxFMOMLZFDk7fih+9eZcwFQAlgd6U5CCkpgQGlvQwA6u8vLxdBpb1vOUqtYbpL9MXnIqKYd6NSq3p2CCsjOyczqOmqNSapPQMSvnTtHkqtWb6Tlcn38B5ez3o/+KKHZDOrSVnZr4xafbQ79Y/fPhQXKXtUqk1KSkpLQbWcRhYwALAK3UlB/0DAAAASgYGlrRgRJscoDclOejzmxIYWNLTYQPrb7MWq9SaJe6H9p4K/WT1BpVa89aUOTl5+UYaWMVFRRdv3Lp44xb9PzM7R6XWdJs4i/5Mzco6dTUmNStLXKsD0rm1uOSUvadCO/zhmWBgAfCSgy4XAAAAJQMDS1oQTzlAbwpYNDCwpIdvYCUkJU/dvLNdBtapqy2jrtiwqfOxNwUG1sUbcdN3ug5Z5fSf79YvcT+UnJlJ1QMiIidt2X098d7mwBPDHH9UO2+7HBdPWdN3uk7bsfdBQcG1hMRvf9iqUmv+19hpk7bs9g+/HHjpyqQtu33OR7CPcSA07Nsftg5Z5bTE/VB2bl5OXv6mgKAv1rkMWeX0zYYthy9e4n9mQWHx1vwvXp6wedeQVU6jf9zuHXaRpU/bsXeD39GYhMQp2/d8snrDWm//547PIgMrOSOz8OefYWBJyIOy8sikVGEqAMoD04jkYMSP21MLHgpTgXEgqtKCeMoBxrbIQe2z+tKqx8JU0FFgYMkBelPAooGBJT18AysnJ2fBT+4dMLCyc/NeGz1VpdZE37krMLD+19hp/3fCjEHL1/5jdkv5fktWU/VVnr4qtebfc5exSYhvTJqdnZvHrx4cFcOfpbjCw4dqzd1zgDYy37VlDuBro6f+2W6+Sq3ZERS81ttfpdb8a47D4JXr6CP5X7ysr7Bga+t8jpBZRl9NpdawUKjUmj/bze82cRb7MN97+YtjwhcZWEVFRdXV1TCwJASdA5kIjbvz6EmNMBUAhfH+srWJufnCVGAciKq0IJ5ygKs/UD5opcAiQJ/flMDAkh4jDawDoecjb9+ZtHW3Sq35nxkLaVwS38DyCD1Py7Hn5T94c7K9Sq3JbE0n8+hNjf2pqJjkzMy/TF+gUmsCIiIF1eOSU1q8rcmzaad8y+nWveT/NXba/xo7jVyzk1eiI2/fuRQXf+nXkVxOvoEthffqLczf2t20dCoQeftOcVFRUORVlVrzv8fZ0VL09JEmbf0pKyeXPLL3Hb4Xx4QvGFgygc6BTOCOC1gEaKhygKhKC+IpB7j6A+WDEW3AIsBFypTAwJIevoG1wvXAnyfNbJeBxfSnafNCoq8x74a/BtaZ6Ot7T4Wu8vR9Y9JslVoTl5wisKKKi4q+Xr9Jpda4Bp9tu4HlEXpepdYMXrlO8MHS7t/ffzrM5cjxr9dvbnGdtuzWV5i/Nf+LlwUF/jZzkUqtuXzrtuAjXbp1W6XW/GP2EsF+BSIDa94utyOXomBgSQi6sDKBi5nkYBqRHKChygGiKi2Ipxzg6i8HmJgJlA96U5KDi5QpgYElPXwDa/bWXd1G/zZvzrDIwJq0Zbez/7HDFy/RMCvm3ZDdk5OXP2SVE63vPnjluv89zs6wgbX3VGjbDSzX4LMqtebr9Zv4n8o7LPx/j7N7bfRUm4Ur/z13KTOwdBb+/dZCVWrNcKeNLNd6fstrFkOvxeo0sP42a7EgIAKRgTXeeavH2YswsCQkISfP9exFYSowGlzMJAchlYOiR5X1jY3CVGAciKq0IJ5ygLEtcgBbECgf9KYkByE1JTCwpMdIA4vWwBJ7N2T3HDx7QaXWfLluY2FhIasilYFFs/z+ab+ENl5YWJidm0eu0/nWlxjuPdXiSZGBpbMwf2u03tY/7X8ZV5Wdm/d/xk9XqTWpmS3vKISBBV54NgSefFBWLkwFRoD+AQAAACUDA0taMKJNDtCbkhz0+U0JDCzpkdXAOnTuokqt6Tl/+cUbt9b5HKFV1aUysLJz8/4wda5Krfn2h60bDgd+uNzR5cjxXgtWqNSaDX6BZ6/F9l28ihlYOgsLtvY/Mxaq1Jpxm3buPRX62fc/qNQatfM2wTeCgQUAaCPocgEAAFAyMLCkBfGUA/SmgEUDA0t6+AZWQlKy3ZZdbTSw/jF7iT4Dq/OoKSq1JisnNy//wYcrHMn9+cPUuYOWrWUG1neHDqvUmnl7PajKNxta1qsiA4tVLy4qik9JpbXeqZigVlDkVbKl6CWGwVExh85doImKrRMGf1sDS2dhwdZCoq/RulesenJmpuAbFRcVRd6Ob7uBlZyRWVxaBgNLQh6UlUcmpQpTAVAemEYkB1gLQw4QVWlBPOUAY1vkABMzpQUGlhygNwUsGhhY0tPhtxAmZ2TGJafQjDyB7qalJ6SmsT8v3rh17vqNnLz8jOwcViUnLz8uOSU7N4/KUNaDggJx9fiU1HvpGfR/QS1KuXjjVkj0NZaYmpV16mrMzXvJNIAr7X62vsLirT18+DAqPuHU1ZgW40n/N4pLbnWmeAXEwlsIZQKdA5nAK3WBRYAnsXKAqEoL4ikHuPoD5YNWCiwC9PlNCQws6emwgQUZFgwsmUDnQCZwxwUsAjRUOUBUpQXxlANc/YHywYg2YBHgImVKYGBJD9/Amrv9p+4zFsDAkkRkYE3ZtOP09RswsCQEXViZwMVMcjCNSA7QUOUAUZUWxFMOcPWXA0zMBMoHvSnJwUXKlMDAkh6+gTV+w6a/TJ4NA0sSkYE1fPX6Y1eiYWBJSEJOnuvZi8JUYDS4mEkOQioHWAtDDhBVaUE85QBjW+QAtiBQPuhNSQ5CakpgYEkPDCyZBAMLWBZ4pa7koH8AAABAycDAkhaMaJMD9KYkB31+UwIDS3pgYMkkGFgAvOSgywUAAEDJwMCSFsRTDtCbAhYNDCzp4RtY8feSpm/bDQNLEpGBdS89o6SsHAaWhDwoK49MShWmAqA8MI1IDrAWhhwgqtKCeMoBxrbIQU3dM0zMlBAYWHKA3hSwaGBgSQ/eQiiT8BZCmUDnQCbwSl1gEeBJrBwgqtKCeMoBrv5A+aCVAosAfX5TAgNLesQGlkqtgSQRDCw5QOdAJnDHBSwCNFQ5QFSlBfGUA1z9gfLBiDZgEeAiZUos28AKCQkRJikAZmBVVFTM3fHTVi/fiIiIkydP+vn5eXl5HdSFhwgDWS88/Mh4enr6+PgEBgaGhobGxMSkpqZO2bTjzPWbMLAkBF1YmcDFTHIwjUgO0FDlAFGVFsRTDnD1l4OTsXGrfAKEqQAoCfSmJAcXKVNiwQZWXV1dt27dKisrhRnmhgysurq6R48eTfhh04YDnpcvXw4JCQkMDPT19fX29vYyjkMihCWMQ7h1EQYK87PEBYR5z8Pb29vHx8ff3z8oKCgsLOz69evp6enDv99w7EoMDCwJib+f63r2ojAVGA0uZpKDkMrBw/JHWAtDchBVaUE85QBjW+TgcGT0zL0ewlQAlAR6U5KDkJoSCzawjh8/bmVldfDgQWGGuWEGVmVl5QTnLT8e9I6Ojg4LCzt58uSxY8cCQHsIDAwMCgo6ffp0REREXFxcZmbm8DU/HI+CgQUsAKeAILxSV1rQPwAAAKBkYGBJC0a0yQF6U5KDPr8psWADa+TIkVZWVkOHDhVmmBsysJ49e/b48eNJLttGO22cs2Ov3abtU5y3TNqwceJ6F6jtmrR+4+QfNk112Tpz6675P+3Lzc392vHHoKvXGxsbm5ubhaEHALzQoMsFAABAycDAkhbEUw7QmwIWjaUaWJWVlSqVysrK6pVXXiksLBRmmxutVtvQ0FBTU5OWnTNv74Ehq5xWefpCRkql1hQWFmbk5T96/LipqQkGllRkF/98LS1TmAqA8sA0IjkYusb5YfkjYSowDkRVWhBPOcDYFjmoqXtWXv1EmAo6CgwsOUBvClg0lmpgHTp0yOpXtm3bJsw2N83NzY2NjU+fPn306NGqQ4dXefoWFxVBRkql1pSWllZXVz979gwGloSgcyATJ2PjauqeCVMBUBjvzlmaV1omTAXGgahKC+IpB7j6A+WDVgosAvT5TYmlGliffvopM7D69u0rzDY3Wq22sbGxrq7u8ePHq738YWBJIpVaU1FRUVNT09DQAANLQtA5kAnccQGLAA1VDhBVaUE85QBXf6B8MKINWAS4SJkSizSwiouLX3nlFWZgWVlZpaWlCQuZFRqBVVdXN3On26Cla2BgSSKVWlNeXj5u086YlLSmpiZh0EFHQRdWJnAxkxxMI5IDNFQ5QFSlBfGUA1z95QATM4HyQW9KcnCRMiUWaWDt2rWL715ZWVk5OjoKC5kVWgOrtrZ2xDqXPvOXw8CSRCq1pqSk5D8rHSPuJGIEloRcS8v0irgiTAVGg4uZ5CCkcvCw/FFjE17qKjGIqrQgnnKAsS1yAFsQKB/0piQHITUlFmlg9e/fX2Bg/e1vfxMWMitarba+vr66uvrrtc695y6FgSWJVGrNgwcPhixfGx6fgLcQAuWzyicA9wbSgv4BAAAAJQMDS1owok0O0JuSHPT5TYnlGVgZGRkC94q4efOmsKiZaG5ubmpqevbsWVVV1Vffr+81ZwkMLEmkUmuys7M/Xvr9xdt3GhoaYGAB8LKBLhcAAAAlAwNLWhBPOUBvClg0lmdgbdiwQehdtbJw4UJhUTNBBlZdXd2jR4/uJKfM2rEXBpYkUqk1GRkZSRmZ5Y8eNTQ0aLWYTSAN2cU/X0vLFKYCoDwwjUgOsBaGHCCq0oJ4ygHGtshB9dOnGIghITCw5AC9KWDRWJ6B9Y9//EPoXbXy5ptvKsTRYAZWRUVFbm7ugj3uMLAkkUqtSUtLKyoqevLkCQwsCUHnQCbwSl1gEeBJrBwgqtKCeMoBrv5A+aCVAosAfX5TYmEGVlxcnNC44nHhwgVhBXNABtbTp0/Ly8tzcnIW/CSlgXUm5vqGw4GTt/70vZffraRkcYEXWCq1JjU1taioqLq6GgaWhKBzIBO44wIWARqqHCCq0oJ4ygGu/kD5YEQbsAhwkTIlFmZgLVu2TOha8bCzsxNWMAd8A0vjvKXf/GWSGFg5efn/XfujSq1h+t/j7OJTUsUl26Ib95I+X+P83aHD4qznypi6xkil1qSkpKjXuUTeuQsDS0LQhZUJXMwkB9OI5AANVQ4QVWlBPOUAV3858Ll01eVYsDAVACWB3pTk4CJlSizJwNJqtW+99ZbQteLRpUuXuro6YTWTwzewhq9y7DlrkSQG1pTte1Rqzf+dMGP78VMXb9w6EBpmPW/Z1TsJ4pJt0amrMSq1ZsgqJ3HWc2VMXWNEBtbgJavO37wNA0tColPSvSKuCFOB0eBiJjkIqRw8KCvHWhiSg6hKC+IpBxjbIgd7Qi8sO+QvTAVASaA3JTkIqSmxJAPr0qVLQstKxPHjx4XVTI4cBlZyZuZro6eq1Jp9IWfFuQ8KClZ5+vZd/N0fps593+H7TQFBhYWFxUVFzv7HhqxyupaQOGHzrj/bze+3ZHXI1WvFRUUBEZF9Fq1SqTVvTJo9ZJXTBr+jrPDZazes5y3726xFxUVFt5KSJ2ze9a85S7tNnGmzcOW2Y6f01S0uKrp4I26408Y/283/p/2Sb5233riXROkJqWnjNu3807R5f5o2b9ymnQ8fPhR//jYKBhawLFZ4H8G9gbSgfwAAAEDJwMCSFoxokwP0piQHfX5TYkkG1qxZs4R+lYiRI0cKq5kcOQysoMirNGfwQUGBOPfLdRtVas3fZi4a5vjj/50wQ6XW0B4nbdmtUmv+MHXu/xk//c3J9iq15q0pcx4UFPicj/jTtHm0wb/NWrzsgDcr/NaUOSq1pvOoKS1jvrbteWPS7NE/bh+3aSdtNiT6ms66YddvvjZ6audRUz5f69xz/nLaTmpWVnFR0dDv1qvUmhm73Bbt8/yfGQuzcnLFn7+NgoEFwEsOulwAAACUDAwsaUE85QC9KWDRWIyBVV9f//rrrwv9KhEqlaqyslJY2bTwDaxbdxNnbt9jvIG1/fgplVrz77nLxFkhV6+p1Jo/283Pzs1jVtf/nTDj4cOH5EkNWrY2Kyc3OzfvD1PnqtSaiJtxOqcBUuG/TF9w414SbepmUjL9p7ioaIHbQZVas87niM665FI5+x8rLioqLCwcvHIdK/zWlDmvjZ7a4bW6+CIDKyE1rbS8AgaWhKQVFMZlZQtTAVAemEYkB/0cvq9++lSYCowDUZUWxFMOMLZFDqqfPn30pEaYCjoKDCw5QG8KWDQWY2CdOnVKaFbp4eDBg8LKpkWOtxDuOhFCLpU4a2NAkEqtGbdpJ0v53+PsVGrN7eQU8qRcjhyn9A9XOKrUmlNXY3SaUFSYTQkknYqKWeXpO2nLbpo2SF9EXPdNTcvwrhuJv0wbXOdzRKXWTNqyu7ioaOzGHSq15v+Mnz5560/XE++JP3/bRQYW3kIoOegcyERgdGx9Y6MwFQCF8abGvqqmVpgKjANRlRbEUw5w9QfKB60UWATo85sSizGwxowZI3Sq9PDpp58KK5sWOQys4KgWz6jzqCnioUxrvf1Vas20HXtZCk33i09JFRhYQ1Y5PdfAYoWLi4qWuB9SqTX/M2PhmI07DBtY/2vsNJVaczctnf7c4BeoUms0W38qLirKy3/w3aHDf7abT+PCbiYlCz5/2wUDSybQOZAJ3HEBiwANVQ4QVWlBPOUAV3+gfDCiDVgEuEiZEsswsB4/fty5c2ehU6WHV155pbCwULgJE8I3sEau2TBk6ffGG1hZObm0OtW3zlvZMlhBkVeTMzMPnr2gUmv6LFxJC7dHxSeo1JpuE2cVFhYaMLDOxFxXqTXW85ezXQgKFxYW/t8JM14bPZVWrVpx0IcZWOK61vNa1r3yDrtIf377w1bBYK6HDx8Od9qkUmu2Hjsp/nZtFBlYn690jEvLgIElIejCygQuZpKDaURygIYqB4iqtCCecoCrvxxgYiZQPuhNSQ4uUqbEMgwsX19foU1lkB07dgg3YUL4BtbgRcsHLlppvIHFZhG2LNY+a9Fwp420VvqZmOvZuXl/mb5ApdZ8tsbZYb/X/8xYqFJrvjt0WOxJ8Q2s+JRUGtL19frNGwNaCohHYNGwqWUHvDcFBL0xaTYzsMR1XY4cV6k1b2rsF7gdHO2ynRZxT7t/v7ioqOf85U6+gT+dPG09b5lKrTl2OUr81dooMrB62y++npQCA0tCIu4mBUbHClOB0eBiJjkIqRw8KCvXNjcLU4FxIKrSgnjKAca2yAFsQaB80JuSHITUlFiGgTVs2DChR2WQvn37CjdhQmQysIqLinzPR9BYJ5qON32na17+g+Kioohbt993+J7S35xsv9bb/+HDh8VFRTN2uanUmu3HT1H1z9c4q9Sa0Gux9OfcvQeoygK3g+LCtDsa9vXGpNnLDnir1Jrvvfx01n348KHDfq9uE2eRsTV45bqo+AQq+cnqDVTyf4+zW+HhI/5SbRcMLGBZLDzgU/usXpgKjAD9AwAAAEoGBpa0YESbHKA3JTno85sSCzCwiouLO3XqJPSonkdGRoZwQ6ZCPgOL9KCgIC45hU0kZMrJy7+XniEub0DPrVJYWBiXnCJO11f3blo6eWp8pd3PjktOIU/NGMHAAuAlB10uAAAASgYGlrQgnnKA3hSwaCzAwNq7d6/QnWoDTk5Owg2ZCr6Bdetu4qwde6U1sF5akYGVkJpW/ugRDCwJSSsojMvKFqYCoDwwjUgOsBaGHCCq0oJ4ygHGtshBVU0tJmZKCAwsOUBvClg0FmBgDRw4UOhOtYF//OMfwg2ZCjneQgjhLYTygc6BTOCVusAiwJNYOUBUpQXxlANc/YHyQSsFFgH6/KZE6QZWdna20JpqMzdv3hRuziTAwJJJMLBkAp0DmcAdF7AI0FDlAFGVFsRTDnD1B8oHI9qARYCLlClRuoHl4uIi9KXajIODg3BzJoFvYNku+/7L7zfAwJJEZGB9vtIxLi0DBpaEoAsrE7iYSQ6mEckBGqocIKrSgnjKAa7+crAn9MKe0AvCVACUBHpTkoOLlClRuoHVvXt3oS/VZt58802zeBx8A6v3zAWfr1oHA0sSYRF3mbiYcC8wOlaYCowGFzPJQUjlIK+0DGthSA6iKi2IpxxgbIscOB895Xz0lDAVACWB3pTkIKSmRNEGVmJiotCUaifh4eHCjcoPDCyZBAMLWBbz93vjlbrSgv4BAAAAJQMDS1owok0O0JuSHPT5TYmiDawVK1YIHal2YmdnJ9yo/MDAkkkwsAB4yUGXCwAAgJKBgSUtiKccoDcFLBrlGlharfbtt98WOlLt5PXXX6+rqxNuWmb4BtaNhLv2O11Vag0kiVJSUuJTUssfPYKBJSGJufmJufnCVACUB6YRycG7c5YKk4DRIKrSgnjKAca2yEFVTS2sAQmBgSUH6E0Bi0a5BlZUVJTQjuoQx48fF25aZpiBVVFRkZOTEx8fHxERcfLkST8/Py8vr4MdwuPFQvj19OPp6enj4xMYGBgaGhoTE5Oamoq3EEoOOgcycTgyWpgEgPJQqTXCJGA0iKq0IJ5ygKs/UD5opcAiQJ/flCjXwLK3txd6UR1i1KhRwk3LDBlYdXV1jx49ysvLS0hIuHz5ckhISGBgoK+vr7e3t5fRHDp0SJj0IuLt7e3j4+Pv7x8UFBQWFnb9+vX09PTi4uK1hwPXHwnaEHDih8CTPxyFjJLz0VP0r7AdA6PBHRewCNBQ5QBRlRbEUw5gDQDlgxFtwCLARcqUKNTAqq+v79atm9CL6hAqlaqyslK4AzlhBlZlZeXnK9YGh0dER0eHhYWdPHny2LFjAaA9BAYGBgUFnT59OiIiIi4uLjMz88PFq8RTCyFjRD6gsB0Do8HFTHIwjUgO0FDlAFGVFsRTDmBgyQEmZgLlg96U5OAiZUoUamCdOXNGaEQZwaFDh4Q7kBMysJ49e/b48eM+c5aEXIq8fft2VFTUhQsXzp49ewa0h9DQ0LCwsIiIiOvXrycmJmZnZ/91ir3YgoGM0anrt4JvxDVjMrzU4GImOQipHOSVlgmTgNEgqtKCeMoBxrbIAWxBoHzQm5IchNSUKNTAmjBhgtCFMgJbW1vhDmRGq9U2NDTU1NS8N2/p+ZjraWlpd+7cuXHjxrVr12JiYqJB24hp5fr167du3UpMTMzMzHzw4MHfpswRWzCQMaqrq2tsbNRqtfCwpGXmXg9hEjAO9A8AAAAoGRhY0oIRbXKA3pTkoM9vSpRoYNXW1nbu3FnoQhnBK6+8UlxcLNyNnDQ3Nzc2NtbV1fVdsCLy9p2CgoLs7OyMjIy0tLTU1NQU0DZSW0lPT8/MzMzJyXnw4EFRURFGYEmux48fMw9L2JQBUBLocgEAAFAyMLCkBfGUA/SmgEWjRAPryJEjQgvKaHbt2iXcjZw0NzdrtdrGxsbcouKKyspHjx6VlpaWlJQUFxcXgXZSXFxcUlLy888/l5aW/vzzz7eTU8QWDGSMrsQnxCan1tfXNzU1YRAWUDKYRiQHWAtDDhBVaUE85QBjW+Tg0ZMaTMyUEBhYcoDeFLBolGhgffHFF0L/yWj69+8v3I3MMA+rvr7+6dOntbW1T1qpBu2EBe3Ro0clJSV5eXliCwYyRstcD6w5dPjp06eNjY0wsCQEr9QFFgGexMoBoiotiKccwBoAygetFFgE6PObEsUZWGVlZa+++qrQf5KCjIwM4c5khjyspqamxsbGBtBR6lt5+vTp48ePS0pKsrKyxBYMZIwW73ZbfdCntra2oaEBBpaE4I4LWARoqHKAqEoL4ikHsAaA8sGINmAR4CJlShRnYLm7uwudJ4nYsGGDcGfyM/R754Ky8uZWtKCjNDY2Pnv2rLq6uri42HoaFnH/RWO3/DRtt/trY6aJs9qlhTv2fOfh/eTJk4aGBiyDJSG4mEkOphHJARqqHCCq0oJ4ygEMLDlwORbsc+mqMBUAJYHelOTgImVKFGdgffjhh0LnSSL+8Y9/CHcmP+/OWYppxkbS3Nzc1NRUX1//5MmToqKibt+ME1swz5Wto8vFhHue4ZHirHbpjcmzfS5FCbYzz/3Q4cjowd+tF5eXVfRI6k2Nsava7wk47ht2EQaW5OBiJjkIqeRom5txkZIcRFVaEE+ZwNgWOVh2yB8riwGFg96U5CCkpkRZBlZ+fv4rr7widJ6kIy4uTrhLmYGBJQlarbahoaG6urrVwBortmAM6I3Jsz0vRtJ28krLxAXapXfnONCm+Imnb8XT+1PF5WWVVAZWampqUVFRdXU1DCwJ0TY345W6koP+AQAAACUDA0taMKJNDtCbkhb0+U2MsgysTZs2CT0nSXFw+MV9MBkwsCTBGANrjd+x+sbGc7fv6jOwXh8//Y3Js8XpKrXmTY29IKtdBla3ibO6TZwl3uyfpy/oPGqKOP2tKXP45f9kN/8vMxeKi70+fnrXCTP0GVh/nr5AXMWwUlJSYGABiwBdLgAAAEoGBpa0IJ5ygN4UsGiUZWD17NlT6DlJyltvvWXi+/OH5Y8am0y6xxcSvoF1Keaa2IIxoN6LVv1r7jJbx41iA6vXwpXRqena1mXLMwuLP137I6X7X4mpa2iYufdAXUNDadVjfpXnGlgDV6xrbNJuCDzhdyWmsUnb2KQ9fTOe2VIrvI/wh+trm5vfX7rm9M34mrpnU3btq29svF9cQotbpTx4SGXqGho2BJ6g6t0mzgq6dpM2u/98RE3dM2ZgvTZm2obAE7Tx2mf1+86Fvz5+uiAU+nT03IWr8XdgYAGFg2lEclD99Gk/h++FqcA4EFVpQTxlAmNb5ODRk5rqp0+FqaCjwMCSHPSmgKWjIAMrJSVFaDjJQHh4uHDHQPHwDayUlBSxBfNciQ2sLmPtHpSV1zU0rPA+4uB5uPrp0/Lq6j9Mm8cMqcYm7YOy8risbP52nmtg0Y4am7SPntQci7lBjtLOkHMqteaL9Zs5jrucmDzX/VBS3gOO4y4m3PvLzEVXk9PIqMopKY1KTlOpNRF3k2LTs5yOBG0IPEHdoIEr1qnUmq2nQjmOK6+uPhl7i9wrZmCt8gngOO58fOLMvR4XE+5xHLfG76g4Djo19YfNLocDYGBJS31jY2B0rDAVAIVRVVP7psZemAqMA1GVFsRTJmANAOWDVgqUD/r8JkZBBtbq1auFbpMMzJgxQ7hjoHjkMLCm/7Sf4ziPC5fpT9ezFzmOm7zDlRlSl+8li1/w10YDq6qm9t05Diq1Ztpud47jHpSVq9SaDYEnOI5Tb9ypUmvm7/fmOG7Bfm+VWkMG1sWEe2x3/ImE/ldiOI6btttdpdY8elJDr7ZUqTUDljnWNzYyA+theQXHcX+ym69Sa/46azHHcQnZuYIPr08wsOQAd1zAIkBDlQNEVVoQT5mANQCUD0a0AeWDi5SJUZCB9c477wjdJhl4/fXX6+vrhfuWjaFrnB+WPxKmgnbCN7B6TNG9XpVhiQ2sjUEhdMbJKy3LKy2joVIOnocNrGnFN7D4i1iJDazE3HzK+tfclvfUNjZpVWrNxO17OY6LTEodvXlXdGo6x3G2ji7MwBq9eRfb4Jsa+zV+x87dvhuXlU0jrWbu9fh/rWfG+sZGVoytgfXGpNlsSHBeadmDsnKO40oqq8SfX6dgYMkBLmaSg2lEcoCGKgeIqrQgnjIBA0sOMDETKBz0piQHFykToxQD69q1a0KrSTZOnGgZCGMasIi7JBiziDtJbGBtPnGa47jTN+Nn7vVg+svMRYYNrC5j7WhRs3/PW84Sr6VlsKFVAgPr3/OW03lNpda8t2S1trm5rqGBfChH/+NURmxgxWVlcxwXfCPO+eipxNx8+jB/mDaPKjLvjBlYzNvif5fhG7aIP79ObfX1PxYRCQNLWnAxkxyEVA60zc1keQMJQVSlBfGUCYxtkQPYgkDhoDclOQipiVGKgTVv3jyhzyQbY8aMEe5eNmBgSYIcBtbMvQc4jruUmCwubMDAanlnX34BzT0kI2no987a5mZtc/NfZy1mO6p9Vj90TctEvzV+RzmOu5l5X6XWeEVcoQmA785x6DLWjm1QYGD9efoC/vipk7G32Ichx2qkyw6VWjPix+20/DxNIaTZhX2WrBZ/4OcKbyGUg9pn9QsP+AhTgRGgfwAAAEDhwMCSFoxokxz0piQHfX4TowgDq7Gx8Y033hD6TLKhUqkeP34s/BDyAANLEowxsKbs3JdXWlZSWUVT+fJKyy7da1lF6/Xx0+mJbnRK+uHI6JOxt6pqasmEMmxgjd+2hz7Vg7LyhOw8GpC1J/QC5ZKBRftKyntAuTP3HFCpNQta170iqp8+vZaWQYOkBAZWl7F29ETU59LVYzE3qDx9mN2nz9NZMv5+jra5mf8WwtW+gfQ09XBk9OHI6MTc/N1nwsQfXqdgYAGLAF0uAAAACgcGlrQgnpKD3hSwdBRhYIWFhQlNJpnx9v7NSpCVB2XlZGEAY+AbWOHRMWILxoDUG3deTU7jy//KL1v4++wlx2Ju5JSU1jU0pD8s8rl09fXx02l5rMyi4i/WbxZvjfTF+s3nbt99WP6otOrxzYz7s10Psml9ZGCl5BdsPnGmvPpJSn7BKp8Aylrjd4zjuGMxN5yPnjoSdY2sqK4TZuwJvZD+sGjwd+vZ9m0dXRJz8x89qYlMSp222z2vtGzEj9vJ29oXFv6grDwp78H8/d5OR4JS8gu6TpihUms6j5qy8IBPYm5+VU1t0aPKyKRUA59foKPnLlyNvwMDCygcTCOSA6yFIQeIqrQgnjKBsS1yUF79BBMzJQQGluSgNwUsHUUYWBcuXHAyLaZcBgsYj/FvITSZBGtg8VX99Gl9Y+Pr41o8stfHT6f+zR+mzROXNLGwiLsc4JW6wCLAk1g5QFSlBfGUCVgDQPmglQLlgz6/iVGEgQWAYV4MAyuqdapgTklpaNydvJ9bJpYGRl8XFzO9YGDJAe64gEWAhioHiKq0IJ4yAWsAKB+MaAPKBxcpEwMDS176OXyP067x8A2sv4ydKrZglKN/zV12Pj5x84nT4qy3psxZ7Rt4ODL6fHyiZ3jk+G17XhszTVzM9IKBJQe4mEkOphHJARqqHCCq0oJ4ygQMLDlY5RNwMjZOmAqAYkBvSnJwkTIxMLDk5U2NPb05DhgD38D6/9l+I7ZgIGO0xcfvWEQkDCxpwcVMchBSOWhs0mItDMlBVKUF8ZQJjG2Rg5l7PQ5HRgtTAVAM6E1JDkJqYmBgyQsMLEmAgSWr8BZCOaipe4ZX6koL+gcAAAAUDgwsacGINslBb0py0Oc3MTCw5AUGliTAwJJVMLCARYAuFwAAAIUDA0taEE/JQW8KWDowsOTlQVm5trlZmAraCd/ACo+OEVswkDHyO3M29u49GFhA4WAakRw8LH80dI2zMBUYB6IqLYinTGBsixyUVz+pqXsmTAUdBQaW5KA3BSwdGFjAArCgtxBaotTfO+09EQIDS1pq6p7hxgAon7zSsnfnLBWmAuNAVKUF8ZQJWANA+aCVAuWDPr+JgYEFLABFGVjvLVntfPTU185bxVlt0VtT5vzJbr443YyCgSUHuOMCFgEaqhwgqtKCeMoErAGgfDCiDSgfXKRMDAwseenn8D3e8GI8fAPrL2Onii0Yk6nLWLu0gsJHT2r+PW+5OPe5en389Jq6Z9rm5n/NXSbONZdgYMkBLmaSg2lEcoCGKgeIqrQgnjIBA0sOMDETKBz0piQHFykTAwNLXrCIuySYfhH3jUEheaVl37rsEKSv8D5S19AwzGmTuEpb1G3irJyS0oflFW9q7MW55pLzQe/TV2NgYEkLLmaSg5DKQWOT9mH5I2EqMA5EVVoQT5nA2BY5gC0IFA56U5KDkJoYGFjyAgNLEkxvYFHnY+ZeD0F651FTdE4AfG3MtL/MXChOpzmD4sS21NWZKIfwFkI5KK9+ssonQJgKjAD9AwAAAAoHBpa0YESb5KA3JTno85sYGFjyAgNLEkxsYF1KTP5t183NH650Ih/qWMyNuoYGOk/NdT9Ehf9kN/9k7K3GphbfJ6uouP/SNSq1pqqm9tztuw6eh+nXj7+f+/fZS6j8oyc1tc/qu02cpa/uG5Nn+0ZG00PR+sbGk7G3/jx9gfhDSigYWMAiQJcLAACAwoGBJS2Ip+SgNwUsHRhY8pJXWqZtbhamgnbCDKyHhYXh0TFiC0ZarfIJuF/8M8dx19IyDkdG03JX524ncBy3+8z5OW6elDv4u/UqteZCwj2O4xJy8vaFheeUlC4+6KtSa2jKQ2OT9mLCvZLKKo7jAqOv08bpG9EUQp11Q+PucByXmJu/+cTptIJCjuPC7yaJP6SE8jtzNvbuPRhYQOFgGpEcYC0MOUBUpQXxlAmMbZEDTMyUFhhYkoPeFLB0YGABC8D0byEUTCH897zlHMelFRTSn9N2u7eYWafD3luymuO40qrHr4+fTmu0/2HaPOZSTd7hqlJrvli/meO4zKJiqktZb2rsddbtvfg7juOqamrZEK36xkaO4zq2ZnwbhUXc5QCv1AUWAZ7EygGiKi2Ip0zAGgDKB60UKB/0+U0MDCxgAZjdwFJv3MlxXO2z+rzSsrzSstKqxxzHHYu5MXbLTxzHXUy4J6hOH5uGWb07x4H634IsnXXHb93DcdzlxGSWkpJfwHHcF+s3iz+kVIKBJQe44wIWARqqHCCq0oJ4ygSsAaB8MKINKB9cpEwMDCx5QWuWBGZgZWbn9JgyW2zBSC6BgTV68y6O45LyHszc68HUz+H7KTv3tfhN94SeGn1swwaWzrpkYEUmpbKU1NZZhLQOl0yCgSUHuJhJDqYRyQEaqhwgqtKCeMoEDCw5GL151+lb8cJUABQDelOSg4uUiYGB1VaePHkyd+7cmzdvCjMMwgwLYAzMwEq/n93tm7FiC0ZyeYZHchy3IfAE/dnP4fvWM34FTfdj+mC5Iw0cpXXW353jQE4TfWzDBpbOujSFsPZZPb270HrBCm1zc11DA21KJm3w8Dp9NQYGlrTgYiY5CKkc1Dc2Yi0MycEKI9KCeMpEadVjjG2RHBhYQOGgNyU5CKmJ6biBVV9f7+jo2KNHj3feeefDDz/08fERljAhx48f79SpU25urjCjQ+jc2ooVK4YMGdLYuiBR24GBJQmmN7AcPA/TrV1ibj55UufjE2kZrMOR0YHRsQ/KytUbd6rUmpuZ92nVqmtpGXUNDcsO+bfRwNJX92Lryu55pWXnbt8tr67mOG5jUIj4E0oovIVQDkqrHuOVutKC/gEAAACFAwNLWhBPyUFvSnLKq5+gz29KOmhgPXnypH///m+88caWLVuCgoJcXFzeeOONa9euCcuZitzc3E2bNtXV1QkzOoR4az///POHH374888t755rFzCwJMH0Bla3ibOCb8RV1dTmlJT+a+4ylVrzxuTZu8+cT39YVPusPqek9GTsrXfnOKjUmremzDkcGZ1XWlZe/eT0zfi/zlrc4kxl3E/Iyes6YYZKrfnDtHkp+QWhcXdoy/wsnXXfmDx7X1h4akFhefWTuKzsee6HxB9PWsHAAhYBulwAAAAUDgwXaUE8JQe9KWDpdNDAcnJyeu211/hjlCoqKh4/blnZmqirq8vNzRWMVyorK6OhW7m5uew++eeff66oqOAXq6ysrK+vZ39WVFSwwpWVlbTNsrKyysrK3+r8unGGVqvNzc198uQJP7GsrCw3N5e/cUJcWLA1nV/HwIdh5JX+bjugYzAD62Fh4aWYa2ILBjJGOw4fibmTAAMLKBxMdpODxNz895etFaYC40BUpQXxlAlYA0D5oJVKDiZlA0ungwZW165dHRxaJkaJqaysHDduXKdOnaysrF599dXFixeTYXT69Ol33nnHx8enS5cuVlZW//znP7Ozs+3s7F555RUrK6tJkyaxLdjY2Dg5ObE/u3bt+tNPLe9r4ziuT58+27ZtGzZsmFUr9vb2lH769GkrKyvmoLm6unbu3NnKyqpTp06rV69umfmVltanT59OnTp16dKlc+fO+/fvZ9sXF+ZvTd/XMfBhgOSY/i2EL5VsHVb5nrsAA0taSiqrPC5cFqYCoDBgDcgBoiotiKdMwBoAygetFCgf9PlNTEcMrLKyMisrK29vb2FGK+PGjbOxscnOzuY4LiwsrHPnzrt2tbzBLTg4uFOnTjY2NhkZGVlZWW+88UaXLl3s7OwqKiqOHj1qZWUVGdmybLbYwHr99ddpC5TVqVOnjRs31tbWenh4sFrBwcFWVlY0DCo2NtbKyorW5EpKSiKjLSoqyt/fn7wnFxeXV199lcZb6SzM35q+r2PgwwDJgYElq2BgyQHuuIBFgIYqB4iqtCCeMgFrAAAAjAcXKRPTEQMrISHBysrq/PnzwoxWb+uVV14JCQlhKXZ2dn369GGuEDlBHMdNnTrVxsaG3S1369Zt79699H/DBpZG89uqUl26dHFzcxNYTvb29v3792dlxGRkZFhZWaWkpOgrzLZm4OsY+DCM6qdP6e11wEhMvwbWSyUYWHKAi5nkIKRygKjKAaIqLYinTMDAkgNEFSgcnFElByE1MR0xsH7++WcrKys/Pz9hBsddu3bNysoqKyuLpWzbtq1bt24Cj4njuMWLFw8ZMoQVe+edd/gulQEDa/HixSyL1eJvfNiwYXxfiXHixInhw4f36dPnj3/8o5WVVUJCgr7CbGsGvo6BD8Ooqql9U4N5hRIAA0tWYQ0sOcDFTHIQUgAAAAoHBhZQOOhNSQ5CamI6YmCRqTRr1ixhKsfFx8dbWVmlpaWxFBcXl3/+85/tMrD69OmzYsUKltVeA2v48OHjxo1jZYg9e/Z07drVz88vOzs7OjqaGVg6C7OtGfg6Bj4MAwaWVMDAklV4C6EcYD685KB/AAAAQOHAwJIWxFNy0JuSHPT5TUwHDaxVq1a9+uqr8fG/nVBSUlLoRX6vvfbajh07WPqAAQNoiFPbDSxbW9uvv/6a/h8dHd2pU6d2GVgrVqx4++232VLr+fn5NNJq1KhRlEK2FBlYOguzrRn4OgY+DAMGllTAwJJVMLCARYAuFwAAAIUDw0VaEE/JQW8KWDodNLDKysr69u2rUqkmTZrk5OQ0YsQIlUoVFRXFcZyTk9Orr766atWqAwcOfP311127dhW4QrQFAwaWu7s7vRBwzZo1b775Zrdu3dplYOXn57/22mtDhw51d3e3t7d/++23yajq0qXLwYMHDxw48Le//Y0ZWDoL87em7+sY+DBAcrCIu6zCFEIAXlrQkZUDRFVaEE+ZgDUAlA9aKQBAQAcNLI7jGhsbf/rpJ41GM3To0MWLF5MfRHh5eY0ZM8bW1tbBwYHZPQkJCVOnTq2rq6M/AwICNm/ezKqsWLEiPDyc/fnTTz998cUX9vb2SUlJTk5OLMvJySkgIEBcS7DxtLS0WbNmDRkyRKNpGV3CcVxtba2jo+Onn346a9astLQ0Ozu7goICfYUFW9P5dQx8GCA5fAMrNTU1JiYmNDQ0MDDQx8fH09PzoKR4/MoBKZBkO+wjCT9rR/H09PTx8QkMDAwNDY2JibF1WDX6x21rfQOdjhzfEHDih8CTPxyFOi7no6cwnBhYCrAG5ABRlRbEUyZgDQDlg1YKlA/6/Cam4wYWACaDDKwnT54UFxenp6dfv349LCwsKCjI39/fx8fH29vbS1IOKQ/hRzQCb29vHx8ff3//oKCgsLCw69ev2zqsEg/LgoxRc3Pz3Zw83HEB5QNrQA4QVWlBPGUC1gAAABgPLlImBgaWjGANLKkgA6umpiY+Je0v4+3i4uIiIiJOnz4dFBQUGBgYANpJYGBgUFDQ6dOnw8PDb968+flSGFgSq7GxMSE75/2la4RNGRgB+gdygKjKAaIqLYinTMDAkgNbR5eo5N/e/gSA0sAZVXIQUhMDA0tGYGBJRXNzc2NjY21t7d30zP+ZOOPevXvXr1+PiIgICwsLDQ09A9pJaGhoWFhYeHh4TExMQkLCriPHxBYMZIzq6uris7L7L13T3NwsbM2go6B/AAAAQOHAwAIKB70pyUFITQwMLBmBgSUVzc3NTU1NdXV1Sfdz/qqxv3///r179+Li4q5fvx7TSjRoMxSx69ev37x5MyEhISUlJTMzU2zBQMbo8ePHecUl7ufCsSi+hKB/AAAAQOHAwJIWxFNy0JuSHKyBZWJgYMkIDCypaG5uplmEaXkP/jZtXnFxcV5eXmZmZnp6emorKaDNUMRSU1PT09MzMzOzsrJgYEmu0tLS6urq+vr6pqYmDMKSCnS5AAAAKBwYLtKCeEoOelPA0oGBBSwDGoRVX19fW1tbVVVVXl7+888/FxcXF4GOUlhY+PDhw7y8vK2Hj4gtmA7otTHTBq5YN2T1D90mzhLnGtaWE6c5jluw35v+jE3Pqql7Zr1ghUqt6bVw5eHI6Hnuh8S1SGv8jnpFXPnLzEXiLMNa7RuYV1o2/af94iwjVVBQ8OjRo6dPnzY2NsLAAkomKjnN1tFFmAqMA1GVFsRTJmANAOWDVgoAEAADC1gGNAirqampoaGhrq6utra2pqbmyZMn1aBDPH78uLKysqysrKCg4MN5DmILpgNaeMCHfqzTN+PFuQbUf+maxiatz6UolpJXWsZx3PvL1qrUmlU+ARzHxaZniSuSauqecRw3fMMWcZZh7Qm9wHHcskP+4iwjlZ2dHZ+adjAsvKGhAQYWUDKwBuQAUZUWxFMmYA0A5YNWCpRPXmmZb2S0MBXIBgwsYDE0t0I2VmNjYwPoKPX19WQCVlZWFhYWfjhvidiC6YCiU9JbXhnZ3Fzf2Pimxl5cQJ/Um3au9g3sMtaOpfANrD/ZzZ+512PginXiiqThG7ZM2+3++vjp4izDks/AysjIOHXl6iernBoaGrAMFlAysAbkAFGVFsRTJmANAACA8eAiZWJkMbCio6Pnz5+/ePHiJ0+eCPPaT0ZGxvz58+vr64UZiievtOzdOUuFqcAI7ubkvd/6ZjdmZoEOQA7gs2fPHj9+XFhYOGiuBAbWX2ct1jY3J+bmU294jpsny5q/32vhAZ9uE2c5eB72irgyx82z86gplPXWlDnz3A/5XIo6HBm9yifgD9PmUTrfwLJesML56Cn1pp2UZevo4nr24uHI6NW+gV0nzFCpNXPdD20IPMEsM3EBvt6aMmeN3zHP8MjJO9wEBlbnUVOm7XbfFxa+J/TC6M27xd+x7UpLSzsZGQUDS1rQP5ADRFUOEFVpQTxlAgaWHCCqQOHgjCo5CKmJkd7Ays/Pf/XVVydMmLBs2bL8/PwePXrMmDFDWOhXjh8/3qlTp9zcXGEGj+DgYCsrq8rKSmGG4oGBJTlYd1AS2IJi1dXVRUVFm70Piy2Y9mq1byDHcY7+x2ki4eV7ySwrr7SsvPpJYm4++wAbg0IoKynvAb3ugKYBJuU9oHFYfANr5l6PlmmJt1qmJU7cvpfjuOqnTxOy8+obG9UbW1wtfmGdBZi6TpiR8bCIfYzqp0+ZgdV51JTIpFSO4zKLisurW5z3radCxV+zjUpNTT1xOWroqnUwsCQE/QMAAAAKBwYWUDjoTUkOQmpipDewjhw50rlz58bGRvrTy8srMjJSWOhXcnNzN23aVFdXJ8zgAQMLMGBgSQW91ZEMrJSUFLEF017F32+xoa0XrPjz9AXa5mZtc/Ofpy+gLDKYEnLyPlzptPrwUY7jiioqKWvZIb8By1uMp64TZtwvLuE4rp/D9wYMrKDrN9lyV3+evuCtKXMEhXUWYJrrfogsqveWrJ6+Z39dQwMzsMj5OhJ1jT7Mg7Ly+sbGP/46Iqy9SklJuXkv6cDZ8zCwJAT9AwAAAAoHBpa0IJ6Sg96U5GANLBNjlIFVV1eXm5vLvCpi165db7/9Nvvz8ePH/Nl/Wq02NzeXP7WwrKzl5pP/Z25uLr+KYQPr8ePHBQUF/JTKykr6SGVlZfpqmQYYWJIDA0sqpDWwrBesoF+H/qSuhoPnLwO7yGCiRaxeHz+dPgCr+9aUObaOGyfvcKWxUbaOGw0YWJtbX1b4oKx82SE/9q5DfmGdBZjo6sLmDO4LC2d/ekVc4TjO48LlmXs9Zu71SMjJ4zhumNMm8Zdti1JSUoqKiqqrq2FgSQi6XAAAABQODBdpQTwlB70pYOl00MCqrKwcN25cp06drKysXn311cWLF5PlNHLkSKtf+fTTTzmO69Onj4ODA9VydXXt3LmzlZVVp06dVq9e3XJTevq0lZXV48ePOY5LS0vr06dPp06dunTp0rlz5/3791MtfQZWZWXliBEjOnfu/EYrFy60LGdDe9y2bduwYcPoY9jb2wsqAgD4BtYmo6cQOh891TKu6lHl1eS0q8lpD8rKOY67mXmfcvkGk0qtoQ9A/3c5FlzfajdX1dTSeCjDBla3ibOORF3Ttr7Xr6Sy6r0lqwWFdRZguphwj+O4idv30p/8NbAoq7TqcV5pGel+cQkNB+uAYGABSwEdWTlAVKUF8ZQJWANA+aCVAgAEdNDAGjdunI2NTXZ2NsdxYWFhnTt33rVrF2Xt2rXrnXfeYSVtbGwWL17McVxsbKyVlZWPT8v6OElJSeRq8c2pqKgof39/MsJcXFxeffVVGqilz8CaMGGCra1tbW0tle/atSsN5rKxsenUqdPGjRtra2s9PDysrKwMzGEE4OWEb2AZv4g7DZ56UFbO3B/ay7tzHAwYWDRuK6eklCYbXm3toBg2sEh/mbko+MZtjuP8rsSIty8uwBQYHctx3Bq/Y/Sn/5UYZmDR4KzZrgfF364DwhRCYCnAGpADRFVaEE+ZgDUAlA9aKVA+mEJoYjpiYJWVlb3yyishISEsxc7Ork+fPvR/fQaWvb19//79WTqhz5zKyMiwsrJKSUnRV6asrMzKyioqKor+1Gq1nTp1On26ZfaQjY2NRvPLTTLHcV26dHFzc/utJgBAUgNrwPKWSZ0PyyvYuwVVak1cVou77eh/XGww0QdQqTUDV6wj2+vP0xd8sX5zeXX1cw0sB8/Dto4ub2rsac14r4grgsI6CzDNdj1Iw6ym7XbfHnyWBmqRgTVtt3vLmedh0adrf3x3jsPQ751X+QSIv2wblZKSgkXcgUUAa0AOEFVpQTxlAtYAAAAYDy5SJqYjBta1a9esrKyysrJYyrZt27p160b/12dgDRs2jO8rEQJz6sSJE8OHD+/Tp88f//hHKyurhIQEcRkiLi7Oysrqj3/84zu/8sorrwQGttyysj0S77zzDhsdZmKwBpbkYA0sqZDQwNp6KpTjuD2hF/iJyw7508LtBgysLmPtrqVl/PJ5mpvJ8zJsYIXG3WFfobTqsXgKoc4CTK+Pn872WN/YeJi3JFbnUVMED08elJWLv2wbBQNLDtA/kANEVQ4QVWlBPGUCBpYcvL9sLf+1ywAoDZxRJQchNTEdMbDi4+OtrKzS0n675rm4uPzzn/+k/+szsIYPHz5u3DiWTvDNqT179nTt2tXPzy87Ozs6OtqwgZWUlGRlZZWUlMRPJGBgvcDAwJIKCdfA+ve85baOG//w+xf2vTF5tq3jxsHfbVCpNe8vXWPruLHLWDvKGrL6h6FrnOn/r42Z9q3Ljuk/7e+96Ls/2c23ddz4xuTZgipvauxtHTdaL1hBDtQ3P26fuddj/NY9bI12fmGdBfh6ffz04Ru2TNm17905Dt0mzrJ13PiXmYtYbj+H7yfvcJ2510O9cafO6m0UDCw5QP8AAACAwoGBBRQOelOSg5CamI4YWE+ePHnttdd27NjBUgYMGMBGV+kzsFasWPH222+z1wvm57ec3Pnm1LBhw0aNGkW55JEZMLDoM+icGwgD6wUGBpZUSPsWQkggrIElB+gfAAAAUDgwsKQF8ZQc9KYkB2tgmZiOGFgcxzk5Ob366qurVq06cODA119/3bVrVzKkDBhY+fn5r7322tChQ93d3e3t7d9++22BObVixYouXbocPHjwwIEDf/vb3wwbWBzHOTs7d+7c2dnZOTg4eO/evV988QUt+g4D6wUGBpZUwMCSVXgLoRygywUAAEDhwHCRFsRTctCbApZOBw2sltWRvbzGjBlja2vr4ODA3CuO48LDw1esaHm5GOHk5BQQEED/T0tLmzVr1pAhQzSalhu8liVyEhKmTp1aV1fHcVxtba2jo+Onn346a9astLQ0Ozu7goICQRkBx48fHzdu3JAhQ0aMGHHo0CG6UeTvkXyx8PDw31UD4KWHb2Bt8PASWzCQMYKBBSyF07fiR282zzOeFxhEVVoQT5mANQCUD1opAEBAxw0sAIDlwjewek2bI7ZgIGOUkpJyNT7B5+IlGFhA4cAakANEVVoQT5mANQCUD1opUD4ZD4uOxdwQpgLZgIEFwMsIDCxZlZKS4nX2/LcbNsPAAgoH1oAcIKrSgnjKBKwBAAAwHlykTAwMLBnBgk2Sg2nbUgEDS1bBwJID9A/kAFGVA0RVWhBPmYCBJQeIKlA4OKNKDkJqYmBgyQgMLMmBgSUVWANLVsHAkgP0DwAAACgcGFhA4aA3JTkIqYmBgSUjMLAkx1IMrIqKCmGSwsBbCGUV1sCSA/QPAAAAKBwYWNKCeEoOelOSgzWwTAwMLBmBgSU5lmJgjRs3TpikMMxiYP1h2ryRLjs+Xftjt4mzKOW1MdPenePA15sae8r6++wl785xYCWZXh8/nUq+Pn46pfRz+P6D5Y6CYu8tWc0SvSKucBzXe/F3gjLyCW8hlAN0uQAAACgcGC7SgnhKDnpTwNKBgQWAxGRkZFhZWd28eVOYoSRMPIXwz9MXnLudwPZe+6x+2m53lVqzyifgdx+L43wuRanUmsUHfenPqprav85azN9UXFY2Ze0LC6cU+vPdOQ78YvxEjwuXOY7rtXCl+IPJJBhYwFJAR1YOEFVpQTxlAtYAUD5opQAAATCwAJAYR0dHKyurhQsXCjOUhCkXce8y1i6npJTjuLzSsp0h57YHn80pKT0cGa1Sa5yPnuI47mbmfeejp0jDN2xh6bXP6jmOczoSxDY1dI0zx3FP6p5xHEdbaIuBtTPkHMdxAiNMVmEKIbAUYA3IAaIqLYinTMAaAMoHrRQoH0whNDESG1gZGRnz58+vr2+57TSS2traLVu2TJ069cyZM8I8eThx4sTq1auFqQC0k3/84x9WVlZvvvmmkp0LUxpYjv7HOY4rrXr85+kLKKXLWLs+S1Yzo2pP6AVBFUoPjI6lqwJLp8mAR6Kut8vAoq29MXk27Xq260HP8EiviCsTt+8Vf1pJhEXcgaUAa0AOEFVpQTxlAtYAAAAYDy5SJqaDBta+ffuG/IpGo4mPj6f04OBgKyuryspKYYW20aNHjxkzZtD/7e3t33rrLScnJ1dX1+PHj3fq1Ck3N1dYoUPo3FpxcfHrr79+4cIFfqKRWMqCTRaE8kN68+ZNq1+RtjlJiykNrOjUdI7jNgaFiLMMG1jOR08l5ORxHDdwxTqVWtN1wozqp0+LHlXOdj3YLgPrz9MXDF3jTOnel6I4jsspKU1/WMRxnPgjSSIYWHKA/oEcIKpygKhKC+IpEzCw5ODdOUvzSsuEqQAoBpxRJQchNTEdNLCmTp36z3/+09vb++DBg0OHDlWpVNHR0cYbWF5eXpGRkfT/f/zjHy4uv1gVubm5mzZtqqur+13pjqJza05OTjt37uSnGI/y3RaLQ/khdXBwYAbW1KlThdmKwZRrYBVVtJwQJu9wFWeRUcWoa2joOmEG38Ba7RvIcZzr2YsqtWbabneO43aGnJu516NdBhZfdQ0NzxoaXhszTaXWWC9YIf5IkggGlhygfwAAAEDhwMACCge9KclBSE1Mxw2sIUOG0P8bGxvffvvtMWPG6DSwysrKcnNz+ZMKKysrGxsbKUtgdT1+/JiVfP311w8dOsSyysp+dzHQarW5ublPnjzhJ4r3RYgLC7ZGI7AEiQY+ZxtRvtticSg8pFqt9s0332QGVpcuXaRyXSXHlG8hpCWrxm/dI84ioyqtoPBwZPThyGifS1FdxtrxDay/z16ibW4urXr82phpUclpHMcNWL7WGAMr5cFDakijN+/uPGqK+CNJIqyBJQfoHwAAAFA4MLCkBfGUHPSmJAdrYJkYCQwsjuNsWxEYWGlpaX369OnUqVOXLl06d+68f/9+KtynT59t27YNGzaMbvLt7e3Zdvr06ePg4JCYmMgsACsrq+jo6NOnT1tZWT1+/JiKubq6du7c2crKqlOnTrRqlb596Sws2FpISMhbb71F+/rnP/8ZG9uy7I7hz9lGFO62WCIKD2l4eDi/6VpZWR09elRYSBmY0sBKynvQsra9/3Fx1nOnEKrUmtj0LI7jFh/01TY3pxUUqtQaYwys3otWxd//ZfpwbHrW6+OnCwpIIryFUA7Q5QIAAKBwYLhIC+IpOehNAUtHAgOrsrKya9eu5A3xDayoqCh/f38aD+Xi4vLqq6/SGCgbG5tOnTpt3LixtrbWw8PDysqKTRu0sbFZvHgx/f/111/39vam//M3Gxsba2Vl5ePjw3FcUlKSg4ODgX3pLMzfWkpKyiuvvLJnz576+vrKysqRI0f+8Y9/fO7nBEAnM2bMEBhYI0eOFBZSBnwD63s3D7EFI6F8I1vmF2cVFfPdIlrQvS0G1sIDLcdvXUMDc8GMMbBIQ1ZvyCoq5jhuyq594lzjBQMLWAqHI6PpgAISgqhKC+IpE7AGgPJBKwUACOi4gfXOO+84OTktW7bsb62QHySeQkhkZGRYWVmlpKSQMaTR/HJ7yXFcly5d3Nzc6P9tMbDs7e379+/Pqovh70tnYf7WFi5c2KdPH5aVn59vZWV1+vRpw58TADF1dXWvv/66wMB69dVXxYeDEuAbWP8zbqrYgpFQ785xqG+djZvy4OEqn4AV3kcuJSYH37jNjKqIu0kz93qQBn+3XmBg/clufmNTiwekbW4mQ0qngbUn9ILz0VPOR0+pN+3UZ2B1GWu39WRoP4fv39TYR9xN4jhu9Obd4g9svFJSUsJv3DoaeRUGFlA4sAbkAFGVFsRTJmANAOWDVgqUT2Ju/umbv7zRDpiAjhtYb7755tSpU+fPn79371620I/AwDpx4sTw4cP79Onzxz/+0crKKiEhQeBScRz3zjvv7Nr1yzjGthhYw4YN4/tKDJ370lmYvzVbW9tJkybxc1977bW9e/ca/pwAiDlx4oTAvSIOHmx5ZZ7SMKWBpVJrhm/Y8qCs/Le9Nzev8D6iUmvW+B373cf61ZbiG1gqtYbMpmtpmfSnwMCiwVkMssbo/2IDq/rpU1byWlqGfFMIdx8/NXX7HhhYQOHAGpADRFVaEE+ZgDUAAADGg4uUiem4gcVfA4vB94b27NnTtWtXPz+/7Ozs6OhoqQys4cOHjxs3jlUn9O1LZ2H+1r7++mtBgVdffTUwsOXFZwY+ZxtR+IJNloiSp22PGjVK6F21MnToUGFRBWBiA0ul1nSdMGPI6h9m7vWYvMP1r7MWU2K3ibNsHTfy9a+5y1RqzV9nLbZ13PiXmYuoGP3599lL6M83Nfa2jhv/PW85/fnektX8LdC7BYeucf507Y/iZdr/ZDd/4va9M/d6DHPaJP6QUgkGlhygfyAHiKocIKrSgnjKBAwsOUBUgcLBGVVyEFITI6OBNWzYsFGjRlF6fHy8VAbWihUr3n77bfaqwfz8fAP70lmYvzUnJ6c33niDjSALCwt75ZVXsrJaFo028DnbCAwsyVGsgfX48WOVSiX0rlp55ZVXCgsLhRXMjSnXwHoJBQNLDtA/AAAAoHBgYAGFg96U5CCkJkZGA2vFihVdunQ5ePDggQMH/va3v0llYOXn57/22mtDhw51d3e3t7d/++23DexLZ2H+1srKyrp16zZw4MC9e/e6uLh07dp12bJl4g8DA0shKNbA8vb2FhpXPHbs2CGsYG5M+RbCl1BYA0sO0D8AAACgcGBgSQviKTnoTUkO1sAyMR00sDw9PTdv3ixM5biEhISpU6fSgKba2lpHR8dPP/101qxZaWlpdnZ2BQUFNOgpICCAVVmxYkV4eDj9n581f/78a9euiTfLcVxaWtqsWbOGDBmi0bTcKBrYl87Cgq3l5+cvXLjQ1tZ2zJgxhw8fpkTDn7ONwMCSHMUaWLa2tkLXikffvn2FFcwNDCxZhbcQygG6XAAAABQODBdpQTwlB70pYOl00MACADCKi4tfeeUVoWv1ezIyMoTVzAqmEMoqZmBdSri3IfDED4EnfzgKQYqT89FTvpfRkZUe3B5IC+IpE7AGgPJBKwUACICBBYCx/PTTT0K/SoSjo6Owmlkx/SLuL5VoCmHg5ah1/sfEuRCkHPlevvr/Z+9PoKK48r/xn+PJyd/j8fjPL788efxlMpl8v5NJZr7GjKOTxMnPyTg+PkwWn3yT0WhiIu5rXAARFZUgIu4r4A6CCoKiuLAvArLvsu/7vq9N0+v9HbiTmk4VdFhutQX9fp3PmSPVVdXVtytdt99T9/Y6pyv8DwgYGwQubKE9RYJoAKQPZylIH4YQGhgCLICxmjt3Lj+vEnj77bf5mz1XvADL97G/v7+/t7e3h4eHq6vrtTG7OuDKlSuXLl26cOGCs7Pz+fPnz507d/bs2XMDzg+gSyi63EmHs7Mz/Qdd+fz583QhxT0k3Am35oULFy5dunR5wKVLly5evMgdCV2HrnDlyhV6wPyXMWyurq4eHh7e3t7+/v6xsbG5ubln79xfeeK87S0fYWSAQkmn3MOj1p2/rNVq+Z8RMAYIXNhCe4oE0QAAwNjhImVgCLBEJNkJm8YvCX5AFBcX88OqISQlJfE3fn5ogNXd3V1fX/+f366+HxAYFBTk6+vr6enp4eHh7u5+fczcBri6utIki0ZIFE2UeAt1l4+Inp3QTMr1J9yRcOtcvXrV1dWVHir/BQybu7u7h4eHp6enr69vUFBQfHx8Xl7e2Tv3zY6f3e9xWxgZoFDSKdeQiLXnLmk0GmRYDEnwUjWuoT1FggBLDGhVkDh8ojKHJjUwBFgiQoDFnAQ/IBwcHPhJ1RB0f9TyuaMBVk9PT2Nj449Xrj95GhMeHv7o0SNfX19vb+/bjHgN8PT0vDXgpg7hEt3lHG5b3SUUt4S/C52deHp60mMQHglvBf6hj5C3t7evr++jR4/Cw8OTk5MLCgrO+tz7/sipvddvCSMDFEo61dnZKZfLVSoVfm0AAGDsEGCBxEnwy9R4hyY1MARYIkKAxZwEPyD+67/+i59UDWH69OnS+Yqo1WpVKpVMJmtpaamoqMjKyoqPjw8PDw8KCvL393/MzqOfezhg0IXC5cPH7WF0O+Ef9Mj5+/sHBQWFh4fHxcU9e/aspKQkNCHJPSB411V3YWSAQkmnmpqaurq6FAqFWq3GTVgAAGOEAIsttCdzEvwyNd5hDiwDQ4AlIgRYzEntMzctLY0fU+kVEhLC38VzotVq1Wq1XC7v6Oior68vKSnJyspKSUmJj4+PHRADw0ZbLD4+PiUlJTMzs7CwsLKysqampqqqyvKSqzAyQKGkU9XV1W1tbb29vSqVCgEWAMAYIXBhC+3JnNS+TAGMFAIsgNGztrbmZ1R6rVmzhr+L50Sr1dJRhDKZ7Oht34LS0oqKiqKiooKCgrwBuTBstMUKCgqKiorKy8tramrq6+vr6urKy8t3uFwRRgYolHTq5C3vFUfPyGQypVKJAIsVfD1gC+0pkulmmzp6ZPylAFKCAAsAeMZrgHX8+HEPDw/+UgAD0mg0r7/+Oj+j0mvatGlyuZy/o+eE3oSlUCjeXr89u6S0paWlsbGRJi8wCvX19Y2NjU1NTa2trS0tLU9S0q7cf7TN6ZIwMkChpFPHPDxXHDnV3d2tVCqlM8Z5vEPgwhbaUyQIsED6EGCB9GEIoYGNMsC6ePHi/J9rbW3lrySakJCQV155pbq6mv+AwLvvvrtu3Tr+UgAWIiMj+QHVMNy9e5e/o+eE3oSlVqvf3mBeWFUjk8l6enq6u7u7YFS6u7t7ftLZ2XnhweOlPx7edh4BFkrSdeT6ze8dTyLAYguBC1toT5EgwAIAGDtcpAxslAHWqlWrfv/737vrUKlU/JV+8uKLL3p5efGXDoOjo+Pbb7/NX0rIl19+GRERwV86mOvXr0dGRvKXGgrmwGJOUh8QGzZs4KdTw7BkyRL+jp4f7YB3NlmU1jeoVColjJlCoejr6+vp6bn4wB8BFkr6deT6je8dT3Z1dSHAYkhSl6oJAO0pEgRYYkCrgsThE5U5NKmBjT7Amj9/Pn/pAJlMVl5eLpP9+7PbxMTE3d2d+7O9vV2lUikUivLycoVCQReqVKry8vLGxkZuNUKInZ3dm2++qbuEqqys7O7u5i8dWN7c/LO7TDs7O7mnoGO+ysvLeds2NzfrHglDCLCYk84HhEKhePnll/np1DBMnjy5vb2dv7vnysk/uK27h4ZZGhgDOiqTzix28WHAuA6wXlu5+VerfxAuR420pixZ+c5my6lLVwsfkkLl5ubW1dUhwAIAYAIBFkicdL5MTRhoUgNjHGAdOXJk6tSpb7755tSpUyMiIhISEnS/up8+fZoQMnv2bHprlYmJyfnz5wkhtra2U6dOpXHA3LlzaQj1ySefcBtOmzaN7v/evXsvv/zya6+99uKLLy5fvpyLyYKCgqZPn/7666+/8MILdJOYmBj6XJaWlnQdFxeXKVOmmJiYvPDCCzY2NoSQ/Pz82bNnv/DCC9OmTZsyZcrly5f//UpYQIDFnHQ+IB4+fPjvM3uE3Nzc+LuDiYKOyuzt7X2akXnl/kP9AdaUJSvn7bYztT3C1fuW+yYvNvvtBnPvmIRDPn7CTZiX450H9xOSeVnVwgOHNVptXH6hcP3hl91tX41Wu95pBNPY/2WXLW2Hj6x/fHXFRuEKY6zM8kqFSvXbDebCh0ZRv1r9g+57xxWvMQNTMwghS46eEe7hF+uV7zbcjo5zDYsUPsSqEGABADCEAIsttCdz0vkyNWFgDiwDG32ApTuEMDs7mxBSW1s7adKksLAwQkh1dXVpaSldmXcH1qxZsyZPnuzg4FBcXFxbW0uHChYXFxNC6uvr33jjDZouCe/Ays3NffHFF0NCQuhzvfnmm7a2tvQb4yuvvHL8+HFCSGFh4ZQpU6Kjo7nnMjc3J4TQKI3O+56dnU1TrejoaE9PT3rvlaOj44svvjjojV2jhgCLOel85n7zzTf8XGrYFi5cyN8dTBT0Jqze3t6WlpaysjL9Ada83Xa8zcsamiYvNvvi0AlCSFVzi3AT5tXV20sImW9ziFsybdma7IqqquaWX6/ZKlx/+OXk3/9ZbeXmKXxo0PrLrv7Pc45cqXQNjXx5+TrhmqMuOhHsO5sthQ+Nouy8fHUPmGPn5cut8+1JJ0LI4bsPhJsPp2Zus+6/xmm1r3y3Qfgok0KABQDAEAIXttCezEnnyxTA6Iw+wHrppZe4Gdxv3rxJ46dJkyYJ72MSBliLFi362Ro6li9fvnTpUvpvXoC1devWBQsWcH/a29vPnj2bhmUmJia5ubl0+dtvv+3s7Ez/zQVYmzZt+uCDD7hthQoLC3V3AqBHd3c3vZtvdCZNmlRfX8/f6fNzws9frlTyl8KojCjAMrU9Qghp6epe73yV1uKB+3ReXr5u9blLC/Y5CDdhXp8dPLbitMuUJSu5Jb9Zu83Bx2/mNmvhyiOqkQZYXGtsvex+6kFAj7yPnpzCNUddbAOsebvtHHz8HHz8kopKCCFJRSX0z7m7bLl1Vpy+sP2Kh27zjrS+O+X8hcNJ4XJWtdfl8pazLgiw2HLyD7Fy8+QvhdFCe4oE0QBIH85SAOAZfYA16BDCM2fOTJ48+b333qP3OlHCAIuGSpza2lorK6v58+f/53/+59SpU7/88ku6nBdgLVq0iI5PpF5++eXf//73dP6sN954w9raWqFQPH78eNKkSXFxcXQT7rk++eQTMzMzblece/fuLVq0aPbs2a+//rqJiUlGRv9YDwD9bt26xQ+lRogOp5UIdA4Y4gKssORU98eBwwmwKpqaect/tfoHBx+/zRdcuSXzdts5+YfcT0g+du/Rf6zfwS3/yPrHc4+DbkbG2Hvfo2Pu7Lx8XQJC6Y1L05atcfIPcdS5/Ue4/tbL1x18/LgbfP64ffexe49845JcAkL/6Xia23D/LR9bz7uvrtho5+V7JzbRyu3WoJM6/XrN1qO+D+/EJm6+4MoLsKYtW2Pl5ukbl+QaFrni9AXhtrzW2ONxu/+G2YqqyYvN/rRjz/XwqPct99nc8H6QmPrbDeYf7Nx/PTyKO8JF9sc9IqI/sv5R/3PRAOsj6x+P3Xv0IDHVys2TexW/XrN1/607d2ITfeOS7L3vccMAf7N2m+OdB4+S0q6GPDG1dRQeNhfVOfmH8JYvOXrmcnD4/YTkPR63dW8l+/ak08WgsJuRMVsuuU1dunrasjUuAaHfnnT6w5adpx4EeMckcMc8bdkae+97ezxuD7UtbZzjAy/HKzpu+xWPl75dS9f80449Tv4h/inpTv4heuJIBFhiQODCFtpTJLj6g/ThLAXpSyoqCc3I4i8F0TAOsAghjY2Ntra2L7744tGjR+kS/QFWd3f3m2+++c0336SkpJSXly9ZsmSoAGvJAO5Pjkwme+utt+bOnWtiYvL6669fvHiRe4h7rkWLFn3zzTc/24wQJyenl19++datW6WlpTExMQiwYJg+++wzfiI1QvrvBzQwdA4Y4gKs496+a4+eHl2A9aHVATqinv657Ph5hUrV0SNLKChWqTUtXV2/22gxebHZ6nOXVOp/Jw723vcmLzajbyW9yWi62SZCSEePjO5n0PV1b0r6yvG0rK9/SHXvwP/2/38SDwPpthVNzW3dPYU1ddzmx+495h32dLNNNS2t3Ap0VzTAmrZsTUJB/zjxzPLKquYWQsipBwH6W2PzBVdCSEZp+eTFZvRe97zq/iHnhBBT2yP02+zNyBi6sm5Ypue56IvVPdvdI6LpQ3TnFU3NLV39A8kLa+qmLVszbdmaorp6lVqTUFBcUt+QUlzKO2bdZ+cFWHSAYU1La0ZpRf8Q+KqaacvWTF5sduZhIPfshJCvHE/Ttym7okr3wL475Sx8B4Xb/mr1Dyq1RqFSVTQ103vWvGPiJy82+8MWK1mfokfe9zQnv6G9QxiucYUASwwIXNhCe4oEV38AgLHDRcrA2AdY1IYNG0xNTem/p06devLkSe4hXoBFZ6eis2gRQr744gsuwDp58uS0adO4LrWdnd3rr78u/LnAyMjIKVOm8H7BkOKey9ra+o033uC2rayspLdlcYlYWloa8wALY4yZk8IHRGNjI/dbAWNRWFjI3/Vzgi4sQ6MIsHR9cegEL8CatmxNVXOLQqX6wxaryYvNLF37x2u7BIROW7amqaOTELL2/GWaPX01cDvSUAHWUOtzAdbUpatp3EOjE1NbR41Wq9Fq6fPS1eLyCz/cud/qev9/g3Wt7byXY+3uRYOY/1i/Y9nx8zRPoaHS1svXCSHXw6PoAMmallaFSvWbtduErUEDrPct92VXVHGpEPdB6uDj98WhE9PNNukJsPQ8F30VUdl5v9toQSco1Gi1tK02ulyj/5i2bE1JfQMhZI6FzQcDb0Rkdh59FtoUwhIGWDN+2KVQqQpr6uj9ULeiYgkhK89cnPHDLpVa0yPvm7vrwNSlq3+45PbH7bvp29R/a2dU7Mxt1jci+3+B5FFSGu8dHHTbl75du/2Kx3SzTfRmMY1WK1cqpyxZufVy//9pRJO7qUtX08Rz0EKAJQYpXKomErSnSHD1FwNaFSQOn6jMoUkNbPQB1ptvvmmno7W19f79+0uWLLlz5467u/v06dO50Orjjz9+9913L126ROdf5wVYjY2NU6dO/ec//3n//v3vv/9edwhhRESEiYmJjY2Ng4MDIaS5uXn69Onz58+/devWnTt3rK2t6VN0d3e/++67JiYmL7/88ptvvrlgwYKgoCC6B+65Kisrp06dumDBgkuXLm3atOmNN96gqda0adOuXbt25cqVt956CwGW9EnhA+LChQv8LGpU7Oz4E3g/L5gDi6FRBFg98r6bkTG0/rh9Ny/AotN4t3R10fmVrodHEULCn2XT5TUtbbx9DhVgDbU+F2D9acde3gpx+f0Z69fHznKrzfhhF7dbjVbL29Wd2ERCyA+X3OifLgGhXKjkHZNACLmfkExfRUl9///foDtz/KBxXm5VDY1m6AdpaEYWt7KeAEvPc+m+CvqjhISQ/z78rxmmfrfR4svDp9Y7X6U3mpnaHnl99Q/0PrL7CcmL7I/zXi9XwgBr7fn+uSAzyiroMdAby4/4Plx5pv8G4UfJ/eEUV7Q9u3p76VRZnx08Rgh5mpPPewcH3ZbWn3bs/frYufXOV+nRTjfbZGrrSCfCvxwc8eeBn7YcqjCJOwAAQwiwQOKk8GVqgkGTGtgoA6x79+6t+rnm5ubOzk4bG5sFCxYsWrTo0qVLXFc4Pz9/6dKlCxcujIyMpDdS3b7dP7kJJzo6eunSpYsWLXJ2dvbz83Ny6v/ZJurkyZMLFixYt24d/bO+vt7KyuqTTz6ZP3++lZVVfn4+ISQlJWXatGlBQUHl5eUpKSnr1q2bPHlye3s777ny8/M3bNgwf/58M7P+Ljsde2hra7tw4cINGzbk5+evWbOmurqae+qxQ4DFnBQ+ID766CN+FjUqb7/9Nn/XMP4xmQNLN8CiSQQdI8aVS0Ao3ZYbZsjVUAHWUOtzAdbCA4d5KwSnZxJCVp/rfwm6Iw25O4Z4u4rJLeACL16oFJ3T/1nd1NHJvYSiunqa1nGlG+fZefl+5Xiam/ucfpBycZX+AEvPc/EmcX86sCadw/5ycDi946yiqZnmuaa2RyYvNvvvw6dKByIwQsiNJ/8+AN0SBlg2N7xpJqX7rq13vrr/1h1CyNWQJ7qb88YJ0nYQBliDbvvKdxvCn/XfvyxXKiuamjVaLf36RG/Wa+vuoVGjxbUbwsOmhQALAIAhBFhsoT2Zk8KXqQkGc2AZ2CgDLEmxsrL66KOPuD8jIyNNTExqa/81W8pzhACLuef+mVteXj5p0iR+FjVaSUlJ/CeAcW4Uv0KoP8D6wxYrOpUS75fsZvywixDS1t1DZ1aiY9/6M5rG/oyG/hDeBzv36w5AG3z9nzIdukJHj4xboai2/7cyP957cJgBFr0Da/+tO7p/0lCJjqH74eK/bs4atIZqjUEDrPVO/Uv8U9Lpn4+S0obzXPRVLDxwePJisylLVtIxlR/vtf9woKGK6+pp9EODLRpg0TW/PHyKjogc9BcMhQEWvVvqfkIyb016Z1ZMbgG3ZOrS1cMMsAbddr3TFUKIb1wSfddoL5++ismLzV76di0dc9rS1c07Eq4QYAEAMITAhS20J3PP/csUwBhNhAArJCTkhRde+P777+3s7Pbs2fPqq69yd2wBsOXo6MhPocbA0tKS/wTPA4YQMjSKAKujR0YHmjn4+G0ZGH+nG2BNXbo6f2B+8TMPA+dY2Hxk/eP2Kx6mto5Tl66mg+O8nyasd756PTzq3OOgyYvNIjJz6LRNNje8G9o7uPhjqPW5ZGrKkpX0ia6HR3128BgdAJhfXUuDs+EEWBtdrtHRjtuveLiG9t9vy4VKK8/2BzplDU3/ffjUjB92/dPxNJ1CXtgawwywFuzrH1cuVyptbno/SEwZ5nPRV9HW3WNzw9s7Jp4QUtXcMm3Zmo/3Hux/6sbmdzZbLj56hvaVTW2PfGT9o4OP3x+3755jYUMbk8uGdEsYYP12g3mPvE+hUv1w0W3mNmtTW0e7276/3WD+u40WCpWK/ke30eVaZHbeyrMXhxlgDbqt+bUbhJDgtMz/WL99+1UP7g6sb086bb18/Q9bdtIBiWUNTcLDpoU5sMSArwdsoT1FgmgApA9nKQDwTIQAq3+qlNxcR0dHOzu748ePx8T0z4ALIAY62xorr732mhS+MaJzwNCIhhDO282fB43eKcP7FcKP9x6k06tzVp65OHmx2cIDh1u6uugSjVa79fJ1upBOhEQIeZKZU1RbzyUjg66vm0zNtzmk+0Ql9Y0fWf9Itx1OgPXy8nVR2Xn0oR5538WgMC5UmrzYzDXsX5EWVVRbz9t8RAHW5MVmgan/mrKwR95H77r6xeeqaGpuaO+I/Okg5UrlsuPnabpHBx7S0ZopxaU0wPrLLlsaCVHH7j0SHtugARaN87p6e7ltFSrVzG3WkxebWVy7QXMo+kON83bbDTPAGnTb36zdVtfWP16eBnO5VTX0v2j6G47cU6847SI8bFoIsMSAwIUttKdIcPUH6cNZCtKHIYQGNkECLAADyM7O5kdQYxYW1v8l//lC54ChEU3iPmXJynm77Uxtj3D14c79NEjqvxwWlnBrvvTtWlNbx/XOV7875az7i3Kvrtj4T8fTK89e1P2BvHc2W6447UKzpzkWNvN22+lZ/8Od+xceODx16Wr658vL1y3Y57De+eq83Xb0F/QGXW2+zaGP99rrvhZa05atWXjg8LLj519f/cPLy9eZ2h759Zqt3KMzt1kvO35+vfPVhQcOcwMVuRp4jUfeH2zG8YFZyY/wfgRw6tLVnx08tuz4+ddWbn7luw3Dea4Pd+7/yy5bOiTwu1POuuMBpy5dvcj++IrTLr/baPGr1T+Y2h55efk6OoRz5dmLK89e5M3YpVu/3WBuanvkP9bv4C3/1eofvjh0Yr3z1a+PnXtt5Wbd9ZcdP//tCadfrf6BngYL9jtwbxNthz/t2Ct8SLgtnQbr62Pnvj52brrZphk/7Fqw34Euf99y33rnq9+ecOL92iOvEGCJAYELW2hPkeDqDwAwdrhIGRgCLBFhDizmnu8HxJ49e/j505hJYbgrurAMjSjAGrSWHT9PZ0O/E5sofBSFYlsIsMTwfC9VEw/aUyS4+oth8mIz/iIAKcEnKnNoUgNDgCUiBFjMPccPCI1G8+abb/LzpzF76aWX5HI5/8kMC3NgMTT2AMs7JoEQUtfWPui9SCgU28Ik7gAADCHAAol7jl+mJio0qYEhwBIRAizmnuMHRFxcHD98YuTevXv8J4Nxa0RzYA1aLy9fN+hP3aFQYhQCLAAAhhBgsYX2ZO45fpmaqDAHloEhwBIRAizmnuNn7pYtW/jJEyNLlizhPxmMWyP6FUIU6rkXAiwAAIYQuLCF9mTuOX6ZAmACARbAL1OpVK+88go/eWJk8uTJnZ2d/Kc0IAcfP/4iGC0EWKjxVVtPnttzxQ0BFlsOPn74XGUI7SkSRAMgfThLAYAHARbALwsICODHTky5ubnxn9KA0DlgiAuw/OMSbgeHIsBCSbwQYIkBgQtbaE+R4OoP0oezFKQvOic/OiefvxREgwAL4JctX76cnzkxZWpqyn9KA0LngCEuwNrndtP8/AUEWCiJFwIsMSBwYQvtKRJc/QEAxg4XKQNDgCUijDFm7rl8QMhksqlTp/IzJ6YmTZpUX1/Pf2JDQReWIQRYqPFVCLDE8FwuVRMY2lMkuPqLAa0KEodPVObQpAaGAEtECLCYey4fELdv3+YHTiI4e/Ys/4kNxfBNOoEhwEKNr8Ik7gAADCHAAol7Ll+mJjY0qYEhwBIRAizmnssHxKJFi/hpkwg++OAD/hPDOIQ5sFDjqxBgAQAwhACLLbQnc8/ly9TEhjmwDAwBlogQYDFn+M/c1tbWF198kZ82iaO4uJj/9DDe8H6F0NXv0Zojp76zc1y67+Divbb/3H1AT321e/+gJVzTOOvdFeveXbFOuBw1stpzYInNj98cOGR26NiGE+fy8vIQYAEAsILAhS20J3OG/zIFwBYCLAB9Ll++zM+ZRGNvb89/eoPAZYwhGmDJ5fLW1tby8vL09PSIiAg/Pz8vLy93d3c3NzdXva4J8NcAGJvr16/fvHnzzp07AQEBcXFx206d33Plend3NwIshvD1gC20p0gQDYD04SwFAB4EWAD6fPzxx/ycSTS///3v+U9vEOgcMMQFWAHxST6h4c+ePYuKinr8+PGdO3c8PT1v3rx5A+D5uXnz5q1bt27fvn3//v2QkJDExMTtp532XnVHgMUWAhe20J4iwdUfpA9nKUgfhhAaGAIsgCFVV1dPmjSJnzOJKSUlhX8Q4kPngCEaYPX19R1w97S6cDUvLy8hISEsLOzx48d+fn737t3zBXiu7t+///Dhw6CgoOjo6PT0dPNzF2yuechkMqVSqdVq+Sc0jAoCF7bQniLB1R8AYOxwkTIwBFgiwtnMnIGb9Pjx4/yESWRWVlb8gxAfurBsaTQahUJh63Hb+rJbaWlpZmZmQkJCVFRUREREGIzBqv12q/bb8ZfCCIWHhz958iQmJiY1NTU/P9/K5cp+t5u9vb0qlQoBFisGvlRNeGhPkeDqz1xHj2y62Sb+UgApwScqc2hSA0OAJSKczcyhScWAJmVLo9GoVCq7Wz42bjfr6upKS0vz8vKePXuWnp6elpaWCqO1+cjJzUdO8pfCSKQNyMjIyM7OLiwsrKysbGpq6urqUigUarUaARYAwFggwALpw5cp5tCkBoYAS0Q4m5lDk4L00VGEERlZISnp7e3tjY2NNTU1lZWV5eXlZTAGlk6XLJ0u8ZfCCJWXl1dUVFRVVdXV1bW0tHR2dsrlcpVKhQmwAADGCAEWW2hPMeDLFHOYA8vAEGCJCB8QzKFJQfq0Wq1Go1Gr1QqFore3t6urq6Ojo3VAC4zB3msee6958JfCyLW2tra1tXV2dvb09MjlcqVSqVarNRoN7sACABgLBC5soT3FgC9TMN4hwAIwanKl8oSfP38pjA2XYR287Tt5sRkKhTKqsnK75eQfwv9cgNGycvNEezKHaACkD2cpAAghwAIwaugciCQ47VlCfqH97XvCL7coFGpi185rN88/DsYdbawgwBIDrv4gfThLYVwIzchKKirhLwXRIMACMGroHIhBq9XudL159mGAnddd4ZdbFAo1scvyqsf5R0EYlckKAiwx4OoPAMAELlIGhgBLRBhjzBw+IJhDF5Y5On7Q8uqN0/cf2d70EX65RaFQE7t2XHQ7+8AfP+zICi79YsDVXwxoVZA+fKIyhyY1MARYIkKAxRw+IJjDHFjMabValUplccX9+J37Nu6ewi+3KBRqYldbW5tMJlMqlbgJC8CoIMAC6cOXKebQpAaGAEtECLCYwwcESJ9Go1EqlY/ik0ISU6yveQi/3KJQqIld9fX1HR0dcrkcN2EBGBUEWGyhPcWAL1PMYQ4sA0OAJSIEWMzhMxckTqvVqtXqvr6+zs7Ouro6y0uuwi+3KBRqYldFRUVLS4tMJlOpVAiwAIwHAhe20J5iwJcpGO8QYAEYNQwhZIsGWHK5vL29vaqqaofLFeGXWxQKNbFrjePJI54+PT09dBQh/2MCRghft8SAaACkD2cpAAghwAIwaugcsMUFWPejYx88idrudFn45RaFQk3sWnX4+JFb3t3d3QiwmECAJQZc/UH6cJbCuIAhhAaGAAvAqKFzwBYNsHp7e7c5X/nxmvu285eEX25RKNTErlWHjjnevN3V1YUAiwkEWGLA1R8AgAlcpAwMAZaIcDYzt9756s3IGP5SGAN0Ydn6d4DldNn26nUEWCiUERYCLLbQmxIDrv5iqGhqfmfzTv5SACnBJypzaFIDQ4AlIpzNzCHAYg5zYLFlDAHWZwePOfj4/WHLzsmLzV76dq2p7ZHpZpuEq+mvoTZ8beXmi0FhR3wfCjcZfuke4XDqg537HXz8PvnxqPAhlLD+uH33hzv3C5f/YunZcKRv2eg2MVjl5ubW1dUhwAIwNgiwQPrw/ZQ5NKmBIcASEc5m5hBggcRxAZZvVMz98CfMAyy7275Pc/JpPUhMtXLzfHn5OuFqohb9b3C989X+4/HyJYQ8SEwVrqa/htrweniURqv9+thZ4SbDL90jHE5ZuXkSQpz8Q4QPjbRmW9hcD4/KKK0oqW/wehr3Z8t9wnUkWO9stgxOy6TnlX9K+hHfh3/YYiVcbfJis2nL1sj6FISQ90f40vRvONK3TP8m05atOeL78GlOvs0Nb+GjtObttvOMii2pbyiqq7+fkDxzq7VwnVEXAiwA44QAiy20pxjw/ZQ5zIFlYAiwRIQPCOYQYIHEcQFWS0tLWVkZ8wArs7ySENLU0VnR1EyfMa2kfNqyNcI1xSvd4GDl2YsVTc3W7l7C1fTXoBvOsbBRqFR7PG4L1x9R6Yk2Bi1WAdbKsxcVKhUhRKFSdfTICCF51bXC1fTXr9dslSuVFY3NwofEq6+PnaWHzZ1XXb29Hwx2t9S0ZWvi8ouyK6qEd8/pL/0bjvQt07PJfJtDhTV19FXcjIwRbkhvAKTvFKeurf2V7zYI1xxdIcACME4IXNhCe4oB309hvEOABWDUOnpkuIwxZJgAi96g9MHO/Sp1/3fjT+z+PfZtypKVcyxsfrN2m+5Wv91gTv/xx+27f71mK/33qys2vm+5Txh+DboHuv4ft+8WBge/22gxZclKbrXfrN328V7732204G0+ebHZr1b/8KHV/pe+XTvohpMXm73y3YY5Fja/Wv2D7sLpZptosvDKdxv+uH03bxPdGuoI9bwoWsIA66Vv175vue9PO/a+umKj7pq/Wv3DR9Y/Dnp30q/XbO3q7SWEXA15Ql/jx3sPOvkH0wPTTW1+tfoH3ayEt893NlvS/zCFT/HOZss/bt89delq3YXDf3P1HDwNsDLLK+m2CQXFhJD7Ccm6T/Hqio1/2WVL//Hays28Peg5Nj0b6nnLhjqR9GxC62lOfmFNXWhGlp4Aa+rS1R4RT+fuOjBt2Zpj9x7R/3g/O3hMuOboavE+O+d7DxFgsYL/70oMiAZA+nCWAoAQAiyAIcXExNja2vKXjtzjx4+3bNmyf//+Qf8cVEhIiIeHB3/pzzE5PHQO2OICLM+wJwHRMaIGWJMXm5XUNxBCvj3hRP/cfNG1R95HjyS3quZPO/ZMXmxm6XqTELLH43Z+dS196Kjvwx8uudE1O3pkCw8c5vY/6B6mLFl57lEQXVhUV0/TDRocmF+7QQg58zCQjsni7nwhhCQVlXCpzTubLePyC+nyjh6Zqa2j7oY0/fFPSee2TSspm7ntX0O62rp7MkrLHXz8aFpX19Y+x8KG1yx6jnCoF6VbvADrcnCEXKmk6/fI+zZfcKXLHe88oMdACHEJCOXtxMHHjxBS1dwizAQVKpVGq6VZ2O82WhBCyhqaBt3nfJtD9N9USnEpXW3F6Qv0li56n9T+Wz50+fDfXP0HrxtgcQ2SUFDEPcXhOw/oAcyxsGnp6uZezi8e21Ab6nnLhjqR9GyiWzRHo2/HUAGWbn28157uc5H9ceGjoysEWGwhwBIDrv4gfThLYVx4lJRG++dgGAiwYOL75ptv7O3/9RVFo9EsX75806b+X96Ry+XTpk07ffo0f4OfnD179s033+QvFWhtbd2+ffsHH3zw5ptvzp8/39bWtr29nXs0ISHBxMRk+/btW7duFf45FHNz8/nz5/OX/twwD08/dA7Y4gIss+NnT3r6iBRgbbnoNsfCxuaGNx3qRW9Z+njvQUJIfnXtF4dO7PG4Tb/5c2EEISSjrOJ+QnL/fwVaLSHENy6J7i2psH81PXv4p2P/fyNypdIlIJS7QtPgQDf6sXLzTCkutXLzXO98lYYL9t736J6jc/IJIdE5+Q4+fnQdXmYUnPaMEBKZnWfl5klXTisppzdb0fhD1qfwjIqlMY1/SjqvWfQc4VAvSrd4B1PT0nY5OGK989X9t+5otFpZn+Klb9f+ZVd/WJxRVvHZwWNrz1+2ufmvmIYr75gEevsVb/nkxWb0eGgKQ2+wqmjqHyEo3Odv1m6j75FCpboZGUOHWH689yA9DAcfPwcfPxquLT5yZvhvrvCJeEfIC7A8Ip4SQm5FxXJPodFqq5pb0krKfrfRgr4j9OX84rENtaGet2yoE0nPJsIafoBFp2Pr6u1lOJ0cAiy2EGCJAVd/AAAmcJEyMARYIsIYY+ZG9wExa9asVatW0X9bW1u/9NJL+fn935AJIadPn87Ozv7Z2jqGkxAVFxe/8cYb77777tmzZx89emRvbz916tTZs2crFP3TFRNC7Ozs3n33XW593p9DQYA1ThkmwOJkV1TN221HH7oVFUsI+e6Us+6av1m7jeYIcfmFdFxbblVN/3no5Tt5sdmMrbtoIqB/DzSa2X/rDh1bl1JcOmiApVvfnXLuj1Hik+gdMXTeLu7WpJeXr9Pd8E879hJC2rp76BG+vHwdHYv3gdUBLsD6yvH05MVmH1n/yKU/uqXnCId6UbqbD/UqJi82yxuIzP5kvnfhgcP9/73X1dPxa8JKKuyfv9PBx0/4EH2zhAHWoPsUDiH0jUsihHDzkdPA5VFyGnfkv/jmDvpEukUDrLbunpuRMXTwnUqtoacWfYqiunpu9J9uDvWLxzbUhnreMt3SPZGGuQmtYQZYf9iyk55sWy+7Cx8ddSHAYmt0l37QD1d/MaBVQfrwicocmtTAEGCJCAEWc6P7gOACLB8fnxdeeCEkZMg3RaVSlZeXy+Vy+udwEqJvvvnm97//ve4tV3FxcSYmJpcuXaJ/rlu3TjeK4v3Jo1AoGhsbhwqwysvLVToTDw/n8H4R5sBiyzAB1sXAMJeAUI1W29XbO3dgdiEuQOGZY2HDS2eeDtzfZGp7hE4vRVfTvweaFHAzBOnOPaS786lLV9vc8H6SlVvR1NzU0ckFGYuPnKG3X+m+EN0NaXoSk1vAPUqPhIZWuqmHMNyhpecIh3pRQx0MjcluRcVmlldWNDXTqb4/tDowdelqbhRkZHaeMAl6lJxGCLkcHM5brifAGnSfwtdI3/RPfvzXTGdfHDpBR1kKj3yoN3fQJ9It+hZQCpUqqaiEm1hNmO7pviPDPzbehnresqFOJD2bCGs4AdZrKzfTsYreMQnCR8dSmMQdwDghwALpG92XKdADTWpgCLBEhACLudF9QNAAKzs7e+rUqefOndN96OWXX75xo38uHo1GY2Nj88ILL5iYmEydOvXy5cu8hGjTpk3Tp0+vr6/X3byxsXHSpElcVsWZN2/ewoULCSHvvvuuyU82bNjA+1N3E5VKZWVl9eKLL5qYmMydO3fJkiW6AdaZM2emTJnyyiuvvPDCC9bW1vQbEZMAC9gy5BxYV0Oe6OY+NKE49SBgvfNVWt+ecJqyZOUwMw49e6AZ0BeHTtDVhgqw6Mfdk6ycjS7XXAJCeQEWN50TLd0NvxoYGqa7An2ZC/Y5DDPA0nOEQ72ooQ7mtxvMe+R9PfI+W8+7652vVjW30ACL/o7eeqcrGWUVdK4r3k7o9Ez51bXCaeZpCkZHeuoGWIPuU/ga00rKCCFfHj5F/6Rh05PMHGFIpOfNFT6R7hHSfeZV1wonTdefQw3/2Hgb6nnLhjqR9GwirF8MsF75bgM9+EdJaby558deCLAAjBMCLLbQnmIY3Zcp0ANzYBkYAiwRIcBibnSfubNmzfryyy/feustOvWVrpdeesnd3Z0Qcvv27cmTJz9+/JhOjr5v3z7dhMjW1nb69OncwENOTEyMiYlJSkoKb/mWLVveeustQkhzc/OSJUvmzp1bXl7e2dnJ+1N3k9u3b7/44ot3797t7u52cHAwMTHhAqyAgICpU6dmZGT0DxkbiOFu3+6fygcBlgQZ8lcI39lsSSc8+mDnfm7eIt0hbHS27OFnHEPtwXNgFN7NJ/1ZwJ8t97V0dQ0aYOVWVnPj/rZevs7lDjO3WdP7euaY99/39GfLfZ8dPKa74Ywfdmm0WpVaQ38gb+6uAxqttkfeR599OAGWniMc6kXplu7BfHvCiTvyl75dW9HYTAOs11Zupj8dOHXp6rbuHkLI//PzH9SbbWFD346rIU/o0c7bbUenS69r679Dc/HRMy99u9Z94HhogDXoPv/nwJui0Wq5kXf01XlEPKUTmT9I7P/Acbz7YPhv7qBPpHvwvDmwhmocWrrvyPCPbdANB33LhjqR9GwiLGGANd1s09WQJ3Q6rSlLVkZl5xFCQjOyuJ/FZFgIsACMEwIXttCeYhjdlykA6UCABRPfrFmzZs+e/eKLLx49epT3EBdgmZqampn9a6QPhyZELi4ug6ZX/QNPvL1NTEzKy8t5y21sbF555RX671WrVuneS8X7k/PZZ599+eWX3J9mZmbcaosWLdKN3pYvX/7NN9+wCrAwhJAtQwZY3Nzn18OjBmaS2kPv9EkqKrmfkJxbWV1S3yDMEYbKOPTsYcE+BxrNNHV0qtSalq7uQQOs29FxdFqu+wnJdD80d5i82IzmGgqVqqKpWaPV2nvf4x3VjSf9famu3t6U4lJZX//8cVzkNJwAS88RDvWidEv3YP64fbdKrZErlb5xSYU1dXS3H1od+O6Uc1t3j3dMAm3zQbMexzsPeOdDUV395MVm7k/6Qyv6AnvkfbI+BQ2whtonTc26envpuMs/bt9NJ0fPr66lvzvZ0tVF7+ca5ps71BNxNeoAa/jHxttQz1s21ImkZxPdepCY+rP34KdjMLU9MnB43bq/PKhL+OMAoy7MgcUWvm6JAdEASB/OUgAQQoAFEx8dQnjmzJkXXnghJuZnnWAuwHrzzTeF8dbZs2enT5/+6quvcnPA80RGRpqYmKSl9c99o2vDhg2zZ8+m/x5mgPVf//VfNjY23J+6c2C9/fbbL7300ps/mTZt2qJFi1gFWOgcsCX2EMJzj4OisvPoLVd0cu6o7Dyv6Hj652wLmzuxiXTypsDUZyvPXpy82GyR/fGnOfnc93zHuw+ifpoF6aVv1wanZep+bx90D5MXmy07fj78WXZaSbmdl+9nB489zck3tXXk7fy1lZs9Ip4W1dWHZmR9dvBYcFqmredduvm0ZWuO+j5MKS4tqKlzDYv8zdptvKOaunT1Ho/bT7Jyi+rq/VPSueelU3cHp2XSX4h7beXm0IysQWcsGuoI9bworngHs+z4+aSikuyKqnOPgje6XIvKzvvtBvPfrN12PTyqoKYus7zyasiT324wFx7D5MVmnx085hUdl1lemVle6RoWOWvHHnrP183ImJzK6vsJyXMsbK6HR9HMcah9LjxwODonv6yh6fDArUy6LyGluPRiUBg3Cf0w39yhnoirD3buj8rOO/c4SPiKeE/Be0eGf2zCDYd6y/ScSENtoltW1z1vRsbo1nrnK9yPGAamZtAG4a3D/eYjk0KAxRYCLDHg6g/Sh7MUxgUMITQwBFgw8XGTuH/22Wevv/56c3P/3Q0UF2C99dZb+/fv/9lmPyVEYWFhkyZN8vDw4D1KCKmsrDQxMblw4YLuQo1G89Zbby1fvpz+OcwAa9asWZaW/XeXULoB1rvvvrtly5ZyHTJZ/40MCLAkSOxJ3FEo1OjqUVKaQqWa/fP5+0UqBFhsIcASA67+AABM4CJlYAiwRISzmbmvj52lP/U1IlyA1dzc/Nprr3322WfcNwouwPryyy8/+ugjbhM6WTuXENnZ2U2ZMiUzM/PfO/3JJ5988vbbb9OfDqScnJxMTEwSEvp/8V2YWA0VYC1dunT27Nn0wORy+QcffMCttnTp0rlz5/I3QIAlSQiwUCgJ1u82Wmi0WkvXm8KHxCgEWGyhNyUGXP3FkFle+aHVAf5SACnBJypzaFIDQ4AlIpzNzI0xwCKERERETJo0iRstyAVYCQkJL7zwwpIlS9zc3L7//vtPPvlENyHSaDQLFix4++23eTOv93dWMjNfe+21N99809zc/Pjx41988cWkSZPs7Oy4FYYZYNEDW7p06bVr1/785z///ve/51bLzc2dPHny8uXLfX19b926tWHDBi8vL1YBFubAYgsBFgqFwiTuAMYJARZIH76fMocmNTAEWCLC2czc6AIse3t7V1dX7s/Lly9zc6Jv2bKFmxUrOjr6+++/nz9//vbt2+m87CEhIVZWVvTR+vr6NWvWhIQMkvW0trZaW1vPnz//s88+s7S05E2z5erqeuzYsaH+1BUQELBkyZKFCxfevXs3LCzsyJH+KYep4uLirVu3Lly40NTUdP/+/bW1tbzDA4kQew4sFAol/UKABWCcEGCxhfYUA76fMoc5sAwMAZaI8AHB3OgCLACDEftXCFEolPQLARaAcULgwhbaUwz4fgrjHQIsAKPW0N5xNeQJfymMFgIsFAplarnnRmAIAixW8P9diQHRAEgfzlIAEEKABWDU0Dlgiwuw3AJDwuMTEGChUEZYCLDYQoAlBlz9QfpwlsK4cCc2sbCmjr8URIMAC8CooXPAFhdgffmj45X7DxFgoVBGWAiw2EKAJQZc/QEAmMBFysAQYIkIY4yZwwcEc+jCsoUAC4VCIcBiC5d+MeDqLwa0KkgfPlGZQ5MaGAIsESHAYg4fEMxhDiy2EGChUChM4g5gnBBggfThyxRzaFIDQ4AlIgRYzOEDAiTu53NgJSLAQqGMsBBgARgnBFhsoT3FgC9TzGEOLANDgCUiBFjM4TMXJI4LsFpbW8vKytLS0sLDw+/fv3/r1q3r169fgzH48+Jvtu07wF8KMAxXdfAfY8HV1dXDw8Pb29vf3z82NjYvLw8BFoARQuDCFtpTDPgyBeMdAiwAo4YhhGzRAEsul7e1tVVUVGRkZDx58uThw4fe3t43btxwd3e/DiAl73+9fMeBH/lLYSTc3d09PDw8PT19fX2DgoLi4+P/sXPvjaCw7u5uBFhM4OuWGBANgPThLAUAIQRYAEYNnQO2uADrelBYZHJKdnZ2TExMUFDQ/fv379y5cxtAYj781szKwZG/FEbI29vb19f30aNH4eHhKSkpn1jZ3AwO7+npQYDFBAIsMeDqD9KHsxTGBQwhNDAEWADPX3Z2tomJSXV1Nf8B8aFzwBYNsPr6+r6yP+YeEFxYWJiamhodHR0SEhIQEPAYQGLmrVp/4NRZ/lIYIX9//6CgoPDw8Pj4+KysrM9223qFPZHJZCqVSqvV8j8mYIQQYIkBV38AACZwkTIwBFgiwtnMnKmtY3ROPn/pmJWXlysUCv5SQjo7O3mhUnV1tVwu112iX+sA/lJCGhsbm5ubuT8zMjJMTEzKy8t/thIh3d3d9fX1vIVsoQvLnEajUSqV/zx0/FZoRGVlZX5+fnp6emJiYlxcXGxsbAyM1t83bT96xZW/FMYGrTp2sQPi4+NTUlKysrJKSkoW7bP3fhItl8vVajUCrLFDb0oMuPqLITon39TWkb8UQErwicocmtTAEGCJCGczc2wDLBMTk9u3b7/99tsmJiYvvvjiwYMHuYcmTZp08eLFadOmmZiYZGZmajSa48eP0z9NTEwWLVrU2NhICHF3d3/xxRe5KKq9vX3y5MleXl70pqp333136tSpkydPnj17dmFhIV0nISHhP//zP+l+Fi5cKJPJTp8+Tf+kkpKSCCGFhYXz5s2jS15++eWbN29yx8YW5sBiTqvVqlSqxYdPej952tTUVF1dXVpaWlhYmJ+fn5eXlwuj9Q/LPS7ed/lLAZ63vAEFBQVFRUUVFRX19fVtbW0ymYyOH0SABWA8EGCB9OH7KXNoUgNDgCUinM3MMQ+wXn311YcPHyoUilOnTnHhEX1o2rRp9+7dy87O7u7udnV1nTJlyuPHjzUaTXFx8dtvv71kyRJ6i9aUKVOcnZ3pVu7u7lOmTOns7FQoFP/5n/9paWmp0WgUCsWSJUvmzp1L76h644031q1b19nZ2djYaGlp2djYKJfLAwICTExMYmJiysvL6SZvvfXWl19+2dzcLJfLjx07NmnSpMzMzJ8dPUiVVqvVaDS3o2OzSsu7urra2tqampoaGhrq6+vrYAz+zz5794AQ/lIAaaivr29sbGxpaeno6JDJZAqFArdfARgbBFhsoT3FgO+nzGEOLANDgCUifEAwxzzAcnNz4/587bXXbGxsuIccHf99yZw1a9aWLVu4P728vExMTNrb2wkh33//PQ2nCCGffPLJN998Qwh5/Pjx5MmTuWGJ0dHRJiYmzc3N9+/fnzRpku7gQYo3hPDBgweTJk3SHTz49ttvm5ub/3sDkDaaYalUKoVC0dvbK5PJugd0wRh8dfCYT+RT/lIAaeju7u7p6ZHJZHK5XKlUqtVq3H4FYGwQuLCF9hQDvp/CeIcAC4yXiYnJgwcPuD8//vjjNWvWDPrQ5MmTL126xP2ZlpbG3a4VFhZmYmJSXFzc3Nz8wgsvBAQEEEJOnz79wgsvvPmT1157ja5z/Pjx6dOnc/vh8AKso0eP8lb74osvPvvsM90lrFQ0Nd+IjOEvhTGjGZZarVapVEoQgQJYWLjvUHhGJn8pjAo9M9Vq9f8+cDgqOxfpFSts/78roBANgPThLAUAIQRYYLx4KdXcuXO3b98+6ENTp049e/Ys92dcXJyJiUlpaSmdsfuNN96ws7O7cuXK9OnTVSoVIeTKlSsvvfRSuQ56O9XJkyenTZvG7YfDC7BOnjz50ksv6a5gampqZmamu4QVdA5EciMypqKxSfsTDTCiVqvtb9+bvNgMhZJyRWXn8T8UYLQQYIkBV3+QPpylMC709/mb+MNrQDwIsMB4mZiYbNq0if67sbHxxRdf5EYU8gKsefPmmZqacn/u2bPnjTfe0Gg09M/9+/e/9dZb8+fP50b50YQrNzeX24Sic11xM221trbKZDJCSG5uromJSUpKCl1O7+qKi4ujfzY3N0+dOvXatWv/3hE76ByIBN+4mONyQHtvBFgoqRfuwGIIH6diwNUfAIAJXKQMDAGWiHA2M8e2SU1MTKZOnfrll186Ozv/+c9/fuutt7hZq3gBVlhY2AsvvPDNN9+4ublZWVm9+OKLuj8LWFxcTH8ukEug6HxYb7zxxoULFx48eHD8+PHly5fT27VmzZr1+uuvnz9/3tHRcfr06TTkkslkU6dO/f77752dnYuLiwkh8+fPnz59+unTpy9cuDB79ux3332XOza20IUVCdtzFQgh//vA4cisXJVKddDLV5gXoFASqn+ueJKZjTmwWMHHqRhw9RcDWhWkD5+ozKFJDQwBlohwNjPHtklNTExu3bplaWlJb57SnTR91apVGRkZuisnJSWtW7du/vz569ati4yM1H2Izp/1X//1X7pLFArF6dOn//nPf86fP3/VqlVBQUF0eWdn5549e0xNTb/44ou7d+9y6z9+/HjRgNraWrq5o6PjFwPs7OzojVpiwBxYImF7roJWq/3fBw5HPMuWy+W2N334eQEKJaWyvekjl8tVKhUyLACjggALpA8dVObQpAaGAEtEOJuZY9ukvNusRk2hULz66qtHjx7lPwBGDOPh2eoPsPY7hKU96+zstHH3FEYGKJR0ysbds7Ozk2ZYCLAAjAcCLLbQnmJg+2UK0Oc3PARYIsIHBHNsm5RVgOXj4zNp0qTKykr+AwDAiEaj+d/7DwWnpLW0tFhf8xBGBiiUdMr6mkdLS0tPT49SqeRmSwSACQ+BC1toTzGw/TIFYHgIsMB42dnZFRYW8peO3OPHjy9dusRfOk5gCCFIn1arVavVfX19nZ2ddXV1lpdchZEBCiWh+j/f+EU97ezs7OvrU6vVuAlrjPB1SwyIBkD6cJYCgBACLACjhs6BSHA7MUM0wJLL5e3t7VVVVTtcrvDzAhRKUrVomW94ZHt7u1wuR4A1dgiwxICrP0gfzlIYF9DnNzAEWABGDZ0DkeAbF0NcgNXW1lZRUbHd6TI/L0ChJFWLlt4Ji2hra0OAxQQ+TsWAqz8AABO4SBkYAiwR4Wxm7kOrA5nlmGqKJXRhRYL//BmiAdZCG/tHsQllZWXbzl/i5wUolKRq0VKfkPDW1tbe3l4EWGOHj1Mx4OovhkfJaV8fO8tfCiAl+ERlDk1qYAiwRISzmTkEWMxhDiyR4D9/hnQCrHgEWCjp17bzl8rKylpaWhBgARgVBFggfeigMocmNTAEWCLC2cwcAiwYLzAenqExBlj/sX77O5st39ls+avVPwgfZVK5ldXZFVXC5cMpe+97jnceTFmyUnfhIvvjXb29t6PjhOsPv5z8Qwpq6j7ee1D40Ehr8wXXiqbmjS7XhA9JoT6y/vFiUNh8m0PCh55LIcACME4IsNhCe4oB30+ZQ5/fwBBgiQgfEMwhwAIwQmMJsL4+dk53V00dncfuPZ62bI1wzbEU3blw+S/Wr9dspdvO+GEXt/Dl5evKGppK6htfW7lZuMnw6+nABejrY2eFD420HHz8CCEOPn7Ch6RQl4PDCSFeY8v7GBYCLADjhMCFLbSnGPD9FMY7BFgARq2wpu5ObCJ/KYCU0ACrt7e3paVlpAHWeuer9Dx38PHzjknQDEQJdl6+wjXHUvQ4hcuHU3s8bm+/4qF7B9bHew96RETP3GYtXHlEZTwB1kfWP9p5+X6wc7/woedTi5YGPo1FgMUK/r8rMSAaAOnDWQoAQgiwAIwaOgciuRrypKG9g78URmXsAdaj5DT654n7/oSQmLwCboWZ26wtXW86+Ph9d8p56tLVdOF0s03br3g4+Pjt8bj9m7XbuJXf2Wy59bK7g4/f9isef9hixS2nxzl5sdnUpatXn7v03Slnbj/rna8usj/OrfnBzv3W7l4OPn7cwtXnLq0+9+9XNNRTrD53ydTW8dUVGzdfcLX3vmdq68g9pFu/Wv2D+bUb+2/d+bPlPl6ANXXp6mXHz9t737Ny85y1Y49w28mLzaYsWbn46Jn9t+7Yet79+tg5LlbjAqzPDh5z8PH74ZKb7njMBfsc7L3vOfj4/dPxNLdw0KebY2Gz3vnqays3b7183fHOgz9ssVrvfFX3tSw7fn6981X6Rsy3sd9/646Dj5+1u9fvNlpw60xbtmb1uUsOPn5Wbp6/XrOV2+0cCxv9r4KuNt1s08d7D9p63rV0vTndbJP+A9ZzMugrBFhMIcASA67+IH04S2FcQJ/fwBBgARg1dA5Egm9cDDEMsI74PtT9c/W5SwqVSqFSdfTICCFJRSXTlq2ZbrappqWVEFLV3CJXKj0iounKK89elPUpuKOS9SkWHz1DH6JLaNhBCOnokdHlprZHCCGZ5ZX0zx8uuanUGm4Py46f5929pf8pMsoqCmvqeJvr1m83mNMjJ4QoVKqWri4uwHrluw0pxaV0ECV99NuTTrzNX/luQ1x+Ibd/Qkhkdh4dbkkDrKrmFu6hwpq6V1dspHeQEUK6entp740mTUM9Hd1P+LNsupMvHE4QQlq6umnG9Os1WzVaraxPMW3ZGrpbjlyppKHSqys25lbVcMvp1GO6N4j94qu4E5tIb8Sjbw196qEOeKiT4RcKARZT+DgVA67+AABM4CJlYAiwRISzmbl3Nu/EJHlsoQsrEvznzxANsN433xud/mx0ARY3hFChUsmVygX7HSYvNntt5eaWrq6Wrq7fbjCfsmSl99N4Qsh6pyvfnnAihLiGRdK45CPrH2nA0dLVpdFqvzvl/Os1W+1u+9JQg94rRI9Tf4D12srNPfI+jVa79vzlP2zZyd1FxW07nKdIKCj+4tAJOuw3/Fk278U6+YfQdRbsc6D/5gIse+97hJATfv79NyKZ26jUmorGZt7m+2/5EEKic/J/u8H8fct9JfWNhJAtl9y46EeuVG67fN3U1rGurZ0Qsv2KB53AnhDyH+t30MGPLy9fp+fp6H4IIeceB1u63py2bA2NhxYeODx5sdlGl2uEEN+4pIHJy85uv+Lx+uofpixZ6RERTQg54vtw8mKz4/ce0Xvo/rRj78IDh10CQnkB1i++CpVaY+3u9e0Jpx55HyGETv0+1AEPejL8ciHAYgofp2LA1V8MaFWQPnyiMocmNTAEWCLC2cwcAizmMAeWSPCfP0NjD7A4CpWKG7D25eFT9Lam9c5X1ztfvR4eRQhx8g9ZeOAwvaXI5oY3HaE2ebEZvVcooaCY/jllycq27h5CCB3lR3euP8CiT8ftgStu2+E8xSvfbRjIiex1b+ziKq2kjBDy2cFj9M+kwhIuwKK3F9l736cvtqWrmxDyP3UG0PWvX9S/Pje20crNkxByKyqWi37OPAykD9E/6UOR2Xk0TeOeV8/T0Q11Z1unQRvds39KOiGEG4BJf0Hy4732dODnzcgYbs+6ozJ5AdbwX0VoRtYvts+gJ8MvFiZxBzBOCLBA+tBBZQ5NamAIsESEs5k5BFgwXmA8PENjD7DCn2W/s9nSPeIpISStpIyOGvvhkhv/mQhxvPOAJh0KlYrec7T2/GVu5Tuxidye6WfRx3vthxlgbb3sztsDLW7bYT7F5MVmH1odGDTAoqccN/u77hxY9J4pXV29vbozQHHr/HH7v6Z/ok0XmpElnMSdHuqDxFQ6iRg3pi+hoJjuc6inE04GP9+mP4wrqW946du1sj6FrE9B7+Gaa2WrO1SQC7Doa+QOkpbubof/Kh4lpw2nfYQnwy8WAiwA44QAiy20pxjw/ZQ59PkNDAGWiPABwRwCLAAjNPYAi0569cp3G+g9TXT2qMVHzhBCAlOfCbei8zHRCbO6enunLFlJ+9Dc7O/Tlq3pHhiARu/Kocc5ebHZS9+upf+mGdk/HU9zSdOy4+fpNFu8J+K2HeZT6AmwcgZG83E3H9G7imhAk1FaTgjRPwKOXrA+sTtK/7T1vEsIuRwcLrx36YRf/y1RF4PCuG0X2R+nedMej9t6nk4YYE1ZspKOIrS52T/0j44f5A5m7fnLr67YSN9EGmBlV1TRybOG2u0vvopBA6yhDpgW72QQrsArBFgAxgmBC1toTzHg+ymMdwiwAIwahhCC9DGcxJ0OWIvJ7Q+J/mP9DlmfQqFSfeV4eurS1dPNNq047fK7jRYL9jksOXpm6tLVv91grlJreuR9U5as/O0Gc7lSqdFqf7jkNuOHXeceBekO96PHSf9N7+U59SBgxWkX+v/I0aTptxvM6Y08lq435+22cwkI3ehyTXfb4T/FUAHW5eAIQkhcfuFnB4/x5sCif/qnpNPf0Zu764BwEveLgWH0Gd+33LfwwGGaK9E4jJs9ao/H7RWnL+jmgFZunnTi9qshT/pzqBveep5OGGBxK9O0jhs/SJuRTqp1PyGZC7Doa0wrKft478FvTzpF5+TzdvuLr2LQAGuoAx70ZOC12yCFObCYwtctMSAaAOnDWQoAQgiwAIwaOgciwe3EDDEMsGZus6b7/LPlvsmLzSxdb+n+LCAhZMF+h/XOV3SX2HrepduaX7uhu3JJfeOfBn4Xj5cu0Vt+qMDUjB55H5c02Xre5X7/btBfIRzmUwwVYP1hy07urJP1KZ5k5nABza9W/5BfXcvtmRDyJCuXt/mvVv+gO2pPo9XSSc256Cc4LfPfm2fm0ChH967YquYWGgAN9XSDBlh0FCE9Zjp+sP8mr4F5r+i0ZcV19VyA9dsN5nRedkr4K4S/+CoGDbCGOuChToZfKARYTCHAEgOu/iB9OEthXECf38AQYAEYNXQORIJvXAyNJcD63UaL9c5XF+zr/9lBWl8fO7fe+SrNWSYvNpvxw66tl90dfPys3b3m2/TPNjVlycovD59y8PGzueE9b7ed7t7+tGPP9isetp53lx0//+qKjdzylWcvrjx7kftzkf1xOy/fxUfPTFmyctnx87ozjn+896C1u5et511uz7xth/MULy9ft9756hcOJ3WPjdZvN5hvu3zd/NqNP2yx+sOWneudr3JTj09duvrrY+f237rj4OO38szF11ZuFm4+bdmab0842Xre3X7F44Od+7nlcyxs1sFPdzYAANdDSURBVDtffeW7DbRlvjvlTH8bkT6jlZung4/feucrdI55PU/3px171jtf5VI5rlacdlnvfJWbX5/WFw4n7b3vrT536dUVG9eev8yN73t1xcbV5y45+PhtdLlGm4i326FeBW+1+TaHdM+EQQ9Yz8mgrxBgMYWPUzHg6g8AwAQuUgaGAEtEOJuZwxxYzKELKxL858/QWObAQqGeQyHAYgofp2LA1V8MNyNjeD99CyA1+ERlDk1qYAiwRISzmTkEWMxhDiyR4D9/hhBgocZXYRJ3AOOEAAukDx1U5tCkBoYAS0Q4m5lDgAXjBcbDM4QACzW+CgEWgHFCgMUW2lMM+H7KHPr8BoYAS0T4gGAOARaAEUKAhRpfhQALwDghcGEL7SkGfD+F8Q4BFoBRyyyvfJTU/1NcAJI1lkncUajnUIuWxqSkIcBiBf/flRgQDYD04SwFACEEWABGDZ0DkTj5h3T0yPhLYVQQYKHGWSHAYgoBlhhw9Qfpw1kK4wL6/AaGAAvAqKFzIBJ842IIARZqnBUCLKbwcSoGXP0BAJjARcrAEGCJCGczc9PNNiHhZgtdWJHgP3+GaID19vodGQVFCLBQ46AQYDGFj1Mx4OovBrQqSB8+UZlDkxoYAiwR4WxmDgEWc5gDSyT4z58hBFio8VWYxB3AOCHAAulDB5U5NKmBIcASEc5m5hBgwXiB8fAMIcBCja9CgAVgnBBgsYX2FAO+nzKHPr+BIcASET4gmEOABWCEeAGWq9+jNUdOfWfnuHTfwcV7bf+5+wAK9dxr8V7bpfsOfmfnuObIKVe/RwiwAIwQAhe20J5iwPdTGO8QYAEYNQwhBOmjAZZcLm9tbS0vL09PT4+IiPDz8/Py8nJ3d3dzc3OF0Zo+/x/Hz57lL4URcnNzc3d39/Ly8vPzi4iI+M2S72NT01tbW+VyOQKsscPXLTEgGgDpw1kKAEIIsACMGjoHIsHtxAxxAVZbW1tlZeWzZ8+ioqIeP358584dT0/Pmzdv3oDR+n8WfHra2YW/FEbo5s2bnp6ed+7cefz4cVRU1Jtfr4hPz2hra0OAxQQCLDHg6g/Sh7MUxgX0+Q0MARaAUUPnQCT4xsUQDbD6+vo6Ojpqamry8vISEhLCwsIeP37s5+d37949Xxit1/7xfy66XecvhRG6d++en5/f48ePw8LCEhIS3ly2KjEzq6Ojo6+vDwHW2OHjVAy4+gMAMIGLlIEhwBIRJmxiDk3KHLqwIsHFjC2NRvPOBvPcsvLGxsbS0tLMzMyEhISoqKiIiIgwGINfL1py664vfymMXERERFRUVEJCQmZm5n8sX5uWm9/V1aVQKDQaDf9shhHCx6kYcPUXg5N/iJWbJ38pgJTgE5U5NKmBIcASEdIW5tCkzGEOLJHgYsZWf4C10aKgsqq9vb2urq60tDQvL+/Zs2fp6elpaWmpAM9VWlpaenr6s2fP8vLySktL6+rq2tvbe3t7VSoVAiwA44EAC6QPHVTm0KQGhgBLREhbmEOTwniB8fBsabXadzZZFNfU9fT0tLe3NzY21tTUVFZWlpeXlwFIQHl5eWVlZU1NTWNjY3t7e09Pj0KhwPhBAKOCAIsttKcYkLYwhz6/gSHAEhHSFubQpADGaSDAsiytb1AoFL29vV1dXR0dHW1tba2trS0AEtDa2trW1tbR0dHV1dXb20vTK41GgwALwHggcGEL7SkGBFgw3iHAAjBqSUUloRlZ/KUA0qPVajUajVqtVqlUCoWir69PPqAXxuB/freuvqWVvxRGjp6NfX19CoXif36/obWzi5deBRe5BKFGVQuPf+aXc1a4HDWWOuhvaemzKajIJbjI5WcftQCSgQALAIQQYAEYNXQORHLCz1+uVPKXwpjRGIsmWTBqKpUqsMApoMBp4bFP72WdDhj4N2rsFVjgpFarp6/Y2Nbdo3vSarVa84AZKJQ0i56iP/uoBZAA9FFhXECf38AQYAEYNXQORILhrmKj37hgpLj4T/glFsWkNBrNdLNN7T/950/bXKVSCddEoSRS9NcGkGEBAIwC+vwGhgBLRDibmZu82Iy/CMYGAZZI8J8/c2hSJpCniF0qlYq7A4trbblcLlwThZJIyeVyZFhMoE8F0ofeFHNoUgNDgCUinM3MIcBiDnNgiQT/+TOHJh075CkGKC4LoGhrd3Z2CtdEoSRSnZ2d3HnL/9SAkUCABdKH3hRzaFIDQ4AlIpzNzCHAgvEC4+GZwyfq2CFPMUBxWQCdbkyhUHR1dTU1NQnXRKEkUk1NTV1dXfSnM3ET1lggwGIL7SkG9KaYQ5/fwBBgiQgfEMwhwAIwWvhEHSOtVjvGPMUm9KN9YfOEy7nyzrItbEk4G/+d8CHp197QubmNUbGVt4UPjai4LEClUimVyt7e3ra2turqauGaKJREqrq6uq2trbe3V6VSIcAaCwQubKE9xYDeFIx3CLAAjBqGEAIYCa1Wq1KpRpen3M051NpbQ/fTo2jzyLASrmMeMCO55gEhxCtzn/Choaq0NVVLNBeS1nJLrqdZEEJSah4KVxa17CNNCSGtvbXCh0ZU1dXVr36zur65RalUKhQKmUzW1NRUWloqXBOFkkiVlpY2NTXJZDKlUokAC6QDARYACCHAAjBq6ByIBLcTg9RotVqlUjm6PIUQIld113cVqzX9Z7Vaozz4ZKFwtVEEWDWd+YQQ19Rt3BKvzH2EkOyGCOHKoharAKu0tPR/LF1V29TcN6C7u7uhoaGwsFC4JgolkSosLGxoaOju7lYqlZgGC6QDfVQYF9DnNzAEWABGDZ0DkeAObZAajUajVCpHl6fczty/K2i2ecAM93RLurcrKVvoQ5aB711MWn/z2e6DTxYKA6zDUZ+7p1t6Ptt7Ou4b4W6HE2Cdil16/OlXFoEzLydv8ny292j0F7qbH4ledPPZbvd0S+fEVc6Jq36M+Dvd5ETM4r2hc72zbLnxjE4JK70y93ll7uMdiX2k6Y0M60vJGw9F/oMXYFkHz7mSvMkrc59z4iqLwJm8Ix+qCgsL/8fXK2saGuUDurq66urq8vPzhWuiUBKp/Pz8uro6BFgAAKOAPr+BIcASESZsYg5NyhwCLJHgYsYcmnSMuABrLHnK2bjldG/n41eYB8zYFTS7qCWRLlGq5U09FboBVmSZh5b8+8twVkPEzqBZvB3+YoDVq+pq6ikvakmiO9ESzZ3sg/Sh0OLL3M6p8NJr3CbVnXncfkpbU3VXS6jypXu4lrpVpemjC+mRcAHWyZiv23rruE0KWxKEBz9o5efn/4+vzbgAq7Ozs66uLi8vT7gmCiWRysvLq6ur6+rqQoA1Rg4+fg4+fvylAFKC3hRzaFIDQ4AlIqQtzKFJmcMcWCLBxYw5NOkY0QCL3hA06jwlrtJnIOWpoXck3ck+SAjp7GvyfLY3vuoufSIaYLml7SCEtPXWXUha65K4hmZb93IdeTscToBFc6Vbz3bTp5ApO3YFzd4XNk9LNFUdOTahH/lk29FN7CIWcJv0KrvCS67Rg0mvC7yduf9w1Odn4r7tU/efRfvD/7ozaBaNqOKr7npn2bb21nIBlkXgzLquQi3RXE7ZtDvk/fS6wEEPftCiWQD9LUIuwMrNzRWuiUJJpHJzcxFgMYEAC6QPvSnm0KQGhgBLREhbmEOTwniB8fDMoX8wRroB1ujyFJfENfSOqotJ6+mSzPowQsjdnEP0z5zGJ1yA9aw+lBDinWVLH7qduZ8QktsYxdvnMAOsU7FL6XDFHkUbIeR03DdHo78ghKTXBZoHzDj4ZCEhJKcxUneTqz8NcuTKMvA9+0jThu6S/v9CYxYff/oVIaSrr5mGcSdjl3AB1rGnXxJCmnoq6MjExwWnCSGptY95Oxy0aBaAAAs1jgoBFisIsNhCe4oBvSnm0Oc3MARYIkLawhyaFMBoocs1RmMMsI4//Uqm7CCEPMw/wS2sbO+/f9MlcQ39U3cOrOqO/hF8XNTlnLiKDtPj7ZYO9LueZs4toVEXL8CyjzSlf9LA61LyRsvA95pllRqtOqfxSW1XISHkdtb+QTcxD5hxI8O6sadMtzVOxCy+nLyJEFLamkrX0Z3E/VrKVt2VKRqW/WIZbYBl/8S0sbsstWZYMR/Dsgn9aF/YPOFyVrUzaBadW21EtStotn2k6a6g2RaBM+0jTS0D3xOuI51CgMUKAhe20J5iQG8KxjsEWABGLTonPzqn/wshAExsYwmwHCI/7epr7p9kqqR/kimuCprjCCGez/bSP1NrH3MBVmFzAiHk5rPd9KEbGdaEkPymWN6eM+qCCSHBRS7ckohSN0LI0/Jb9E+aRjlEfUpH9tHDOBW71C5igVzVXd2ZV92ZV9Acx93qJQywDkd9riWadnnD1ZQtundgnYv/jhDSIqv+12uM+pQLsM7Hr6Bxm32kKVd0GvtfrNzc3P/f518/rwDLInDm6bhvfHMO++Ue5aar3x3yvke6FZ3D/nqaxZHoRdz6O4NmuadbemXu80i3ck5ctT/sY94OLQPfo9Pw/2IE419wlhASWnxZd+Ev7n/spdGqtUQjXM6q6L2E3K8WDKduZFjT3+ssb8sIKDxPCAkqchKupltn4r6t7SoMLb4kfMgAhQALpAkBFgAIIcACMGroHIgErQpSM+oAyzp4TousmhBS1pZGh9Q5J66iIciTsuuEkIr2zCPRi7wy92m0ai7ACi2+RAipbM/eH/bx/rCPK9ozCSEP8o7xdu6T/SOd1sotbYd9pKnns710jqrLKZvoCjSNKmtLPxm75EHecUJIn1pmHTzHI8OKEJJZH3Yhaa1z4qqj0V9wPxTIC7CupmwhhBS1JJkHzLCLWNCtaKUBlk3oRzRl8MrcdyR6UVlbOhdg7Q2d26eWqTXKcwNz1dMb0Oyf/PuWLj31HAMsh8hP6avgxFR4cemhror2THrXkkd6fzNytESTUOXLTVd/KnYpvUWOELI39C/CZ9QtmgzqpmO/uH8mRfcsXM6qshsieKNcf7HoQNfYytsP8o4FF7nwItpByy/vKHeWGr4QYIE0oY8K4wLOUgNDgAVg1NA5EAmGu4LUjDrAOhGzmL+vn75pH4r8B/2uTpW3ZXAB1r6wec2ySt1NSltThcmFReDM/KYY3dUIIVHlN7gVaBpFRy9SjwvO0IFj9G4sTmVH1p6QD4UB1r6wefQgW3trVZo+uqsTMYvp7yRym7f21nb2NXK/QuiXd5RO+NXV19yjaNe9m0x/Pa8Aa2fQLBohNcsq7+U4eKRbZdQFV3XkcNOK1XTmOyeu8sn+kUZ4sZW3dR+6mrLlYf4JpVrOjRI9G/+dRqvm3l/9AdbJmK8JIfTpdEvP/lkVPTzhclY10gDLJvQjesbSP4cZYO0Kmu2cuIr+CoHhCwEWAMCooc9vYAiwRISzma2OHtl0s/4pS4AhBFgiwX/+zKFJx2jUAdbukPcDCs8HF7nolnu6JX3UIfLTkOKLidX3L6dsOhT5j+Ail6PRX9CHrIPn3M91jK28HVnm4Z5uyd0hJaxrqVvDS64l1zzwLzh7Ju5b3YdoGnU2fnl4ybWYCi8uR/DOsqV3GNlHmp5PWEFvFKIDCe/nOgYUnrcOnsPtxCHq0/CSa3GVPjcyrM/EfRtc5MLNmuT5bG9cpU9YyRWb0I9uZ+7nJqSnoUxI8cXkmgexlbdvZ+7X3aGeel4B1t2cQ4QQuapbd0Io+m+aIpW0JtOFj/JP0bRR+FBMhRc31/6ZuG8DCs/bRfwvev7oD7DovXjCO+z07P9qypbkmgfHnn6ZVP2gpDXVOniOW9qO5JoH3JRqd3MODazw3/RP2/C/Pa24VdSSlNkQRkNSWvTwTsYueVYfWtiSEFzkwo12PB+/IqHKt6Q1uaQ1Obr8pm343+jyU7FLM+qCS1qTcxojuafTrbPx3z2rD81vir2bc4gXYA11GLSORH9Bhxz2qWXJNQ+upmzRDbD0vMBTsUuTax74ZNtxu7qasiWl5mFJa3JGXfCNDGvhQTIsBFisoE8F0ofeFHNoUgNDgCUinM1sIcASA+bAEgn+82cOTTpGow6wnm8JZ2SnRWMCv9yj1sFz9oXNq+zon07eLW2HcA8Gruc1iXtabQAhJL7qrvAhXoqUXPOQEJJc80D4EL0lLaXmIbft3tC/0PNHT4BlETizs69RSzTCyc717J8mO3R0KiHELmJBdPnN/vc07yhdWTc5+jHi7z2KNrVGmdkQRjcJKb5IV6ObqzR99PYubgI16+A/qzXKPrWsrC2ttbeWEFI8cBgHnyzsU8vkqu7U2sdVHTm0HXTr2NMvVZo+QggdYUoHxv7iYdC6kLT2X/+9DXhccFo3wNLzAnk/vkm3UmuUjd1l9AACCs/zjpNhIcBiBQEWSB96U8yhSQ0MAZaIcDazhQALxhF0YZnDJ+oYTbAA62rKFpoyUFqiiav00XOTl8HqeQVYVR05hJBH+aeED9FwpFfZVdKaTGOXZlnloch/cA9VtGc6RH3qkW5Fx1fe0hksOZwAyyVxDSGksDlB+JCe/dOMRqmWX0vdeiJmsUXgTD35ztPyW4SQezmH6Rg9LdHIVd10NXp4UeU3LAPf83y2l5sljd7xRKfe3xU0W67qJoTsDnnfPd2SEJJa+69fS9wd8j7vmFMGAr7UmscWgTNdU7fR0+wXD4Mr3Z+z5A0h1PMCdQOsHyP+rtYo1RrlkYGbGWkoxr0oMQoBFisIsNhCe4oBvSnmcJYaGAIsEeEDgi0EWADGDJ+oYzROAyzX1G03n+0WTp5Fp1q/lrrVK3OfW9oO+jOFUqjnFWDVdPbfS/u44LTwIRqOqDR99EYktUbpnLhK9yEOzQF1tx1OgJVQ5UsIuZ25X/iQnv3TZCeyzINbWU++U9nef4ddTuOT5JoHyTUP6M1WdEgg3TPdxCJwpmLgRwDoXPIWgTOdE1fdyT4YXOTSq/xXEno46nN6a1V+U+y11K3CY6YtyTXRMA+Dq7EHWG5pOwghBc1x3D475A2EkOMxXwmPlkkhwGIFgQtbaE8xoDcF4x0CLACjhiGEAEZinAZY466e1xxYdEwld2ORbumO47uTfZAQ0q1opXce0Ydae2uDi1y8Mm14vyE4nABrV9DsXmWXStNHZ9Af9KkH3b9wdnOa73BTvOvmO629NXSSeDqhVUlrcl7TU3p3FT08biftA1nPsadfWgfPqWzPptPwl7Qm0xup6K18F5PW05SK94sBtGjMx6VFwzwMrn4xwBr0BeoGWD5ZdgMxWSS3z8buMkLIufjveIfKqhBggTQhwAIAIQRYAEYNnQORoFVBahBgGaaeV4Dll3uU3l3l+FNIZBE4k0YeugGWReBM+uuQdMJ13hxVwvrFAOt6mgUhJKMuWPiQ/v0LA6yAwvPczyPuCppNMyaa75S1pRNCLiatF+6HHh591XYRC+iMUTahH9Ghgs/qQ+hqNJbSHYt6MWm9RqvWaNW8+/voj2nSH50c/mFwpSfA0vMCdQOsS8kb6exgdA82oR/RW8Z0p+dnWwiwQJrQR4VxAWepgSHAAjBq6ByIBHdog9QgwDJMPa8Aa2fQLDq/lVzVnVzd/8uJDd0lNZ35whSJ/gphi6zaInCmnoDp4JOFwUUu4SXX6PkTXnItqMiJ+4E/rjLrwwghg47FEz61bgkDLBo59allkWUe9GcluXyHxnONPWUe6VbOiat8cw6HlVyhW9HVuhWtEaWudCKw/KYYbm81nfnn41cEFJ7Xkv5cxj7S1D3dMqzkikviGvd0S41W3aNo5x0YjZm6+ppDiy/RMGs4h8GVngBLzwvUDbB2h7zf2ddEZ7u/nbm/pDWVEJJWG8B7IoaFAAsAYNTQ5zcwBFhiwYRNzFU0Nb+zeSd/KYwNAiyR4GLGHJp0jBBgGaaeV4BFI6eC5jjuHVeq5XS6JRqOFLUk0dX2h31M7+hxTlzFe0i3rqRs+dkJNIA35fne0LlqjbJX2TXoJGXCp9atoCInXoC1M2hWcWsyfaL67mI6YzrNd3YGzUqo8qUhFMX9VCLdf1FLEl3eIqs+HPU5vcWJi586+5poDHTwycKLSevpyyeEyJQdrqnbeQe2O+R9eqcVne0+tuL2cA6Dq4NPFuoGWLovU88L1A2wzANmOCWsbOut454lqyFCvNuvEGAxhD4VSB96U8yhSQ0MAZZYEGAxhwBLDJgDSyS4mDGHJh0jBFiGqec1iTtXe0I+PBu3/Gzccm5upp1Bs+wjTfeGzuXWsQ3/m32k6c6gWcKHuLIMfM8+0lS37CIW8NahszXFV90Vbk5Lz/6tg+fYR5ryfllvZ9Cs4zFfnYhZTBMo+0hT3Xu+bMP/di7+O+fEVXYR/4tbaBexwCb0I/OAGSdjvz4Z+7Xu+haBM0/FLj0Vu3RX0Ow9IR8efLKQLrcJ/cg5cdXpuG/0/K7f4ajP6W8j0sPQTegGPQzdOvhk4f7wv9J/817mUC/wduZ+3hRmloHvHY3+4nzCCm5X4hUCLFYQYIH0oTfFHJrUwBBgiQUBFnMIsGAcQReWOfQPxkhqAZZF4MyMuuDG7rIDP/8Rt2GWTehHd7IPnhVtWutR13MPsAxZ9L4np4SVwodQw6+gImc6/JNOTGb4QoDFCgIsttCeYkBvijmcpQaGAEssCLCYQ4AFYMzQ5Rqj5xVgHXv65fGn//pBN926l+NACLmf6yh8aDhF7/0pa0sTPvR8y6gCrAd5xx7ln7IInCl8CDX8ouMK85tieCM0DVYIsFhB4MIW2lMM6E3BeIcAC8CoYQghgJF4XgEWnTBIuDyrIUx3/qORlmP0ouSaB/Sn4iRVz3EOLBRqdIUAC6QJARYACCHAAjBq6ByIBK0KUmP4AMsicKZz4ir67M6Jq07FLuUeOhz1uUe6lXu65aHIf+hucvzpVzef7fZIt6KzGu0NneucuGpf2Dyb0I+up1lcT7PgZlOiDx2JXjTUtrQORf7DLW2HV+a+c/HfGeZGIQRYqHFXCLBAmtBHhXEBZ6mBIcACMGroHIgEd2iD1Bg+wDoU+Q/dA+hWtNLlYSVXuN9xU2uUNzKs6fKo8hvcyj2Ktl1Bs+lPsyVU+XYrWunyZlklHWbF+9U24bbmATOCi1w0WjW3vKwtfU/Ih8LjZFsIsFDjrhBgAQCMGvr8BoYASyyYA4s5zIElBgRYIsHFjDk06RgZPsCyDHzP89le+uxemfuupmwxD5jhlND/Ppa3ZewLm3f86Vc9irY+tWxv6NxLyRsJIV19ze7plq6p24pbk3cGzaIpFQ2qfLLsaIzlnWXLC7AG3Zbe/NWtaL2WutUpYWVNZ/9Y6fCSa8LjZFsIsFDjrhBgsWLl5unkH8JfCiAl6E0xhyY1MARYYkGAxRwCLDFgDiyR4GLGHJp0jAwfYNGiz879GVPhRQiJKHV1TlzlnLiqvC2DEHI+fgVdHlB4XndbmlKVt2XQ0X/RA7dZBRU58QKsQbeNq/TpX7nQmf55Obn/ilzdKfoLN6pJ3FEToxBgsYIAC6QPvSnm0KQGhgBLLAiwmEOABeMI7mtjDv2DMZJIgJXX9JR/ZIS4JK7Jb4olhLinW+puyxsnGFzkQgihU7/rPjTotvSJPNKt6J8nYhbTu7SER8i2EGChxl0hwGIFARZbaE8xoDfFHPr8BoYASywIsJhDgAVgzNDlGqPnG2BZBr5H/0ypeUgIeZh/wj7SlNaPEX83D5iRVhtACPHNOay77TADrEG3Ta19rLvQJXENIaSqI0d4hGwLARZq3BUCLFYQuLCF9hQDelMw3iHAAjBqoRlZSUUl/KUAMOE8rwCrR9HWfydUhtXhqM/NA2bcz3UkhJS2ptL51K2D51xIWmseMONB3jFCSH138eGozx2iPk2peWgT+tEwA6xBt+UW2kUs2Bs6l96QFVZyRXiEbCsxNe3Vr80QYKHGUSHAAmlCgAUAQgiwAIwaOgdikCuVJ/z8+UsBnqvnFWBl1ofRA6C/QrgzaFZdVyH9/cHW3lq1Rtmr6jIPmLE75P2mnop/H61WPfwAa9BtdwbNohO3c6o6cugvGIpaCLBQ464QYIE0oY8K0oc+v+EhwAIwaugciAEjiEGCnleAtSfkw8cFZ5JrHnhl7qNLdgbNup25/2n5reSaB2ElV87ELafLd4e8/yDvWEKVb1SZx8nYJeYBMw5HfR5c5OKWtoOucCbu2+Ail3Px3wkfEm5Ln+hO9sGYCq/o8hu3nu3mhjGKWgiwUOOuEGABAIwO+vyGhwBLLJiwibnM8soPrQ7wl8LYIMASAy5mzKFJx+55BVjGVoMGWHl5eVfCd5/333Hy/uajdzc4+qxz9F6LGk4d9Fz1t93vC5ejxlQ+674/+enmC4vP+++4Er47Ly8PARYT6FOBxKE3xRya1PAQYIkFARZzCLDEgDmwxICLGXNo0rFDgGWY4k3iThs8Pz8/Li4uICDgzp07N2/evH79uivA83P9+vWbN2/euXMnICAgLi4uPz+/rq6uu7sbAdYYIcACiUNvijk0qeEhwBILAizmEGDBeIHx8MyhfzB2CLAMU7wAq7u7u6GhobCwMDExMSQk5P79+7dv375169bNmzdvADwPN2/evHXr1u3bt+/fvx8SEpKYmFhYWNjQ0IAAa+wQYLGF9mQOvSnm0Oc3PARYYkGAxRwCLACjhS7X2CHAMkxxAVbfgJ6enqamptLS0vT09Ojo6KCgoIcPH96/f98X4Pm5f//+w4cPg4KCoqOj09PTS0tLm5qaZDKZUqnUarX8zw4YNgQubKE9mUNvCiYABFgARg1DCAGMhG6AlZeXFxsb63Pv3v//4//t4eHh6up6jZ2rV69euXLl8uXLFy5ccHJyOnPmzKlTp06ePHlqwMmTJ0+cOHH8+PFjx44dP378xIkT9CG6nMOtf+rUqdM6uIXUyQG6G544cYJ7iD4RdeLEidOnT587d87Z2fnSpUtXrly5OoB/9CPn6urq4eHh7e3t7+8fGxtL58Dq6urq6+tTKBS9vb1tbW3V1dX5+fmpqakxMTFPnjwJDw8PM6DQ0FCnQAunAPPxWKcebvv7/v9XuBw16nIOtAgLC1u6y8bi+OnU1NT8/Pzq6uq2trbe3l6VSoUAC6QDARYACCHAAjBq6ByIAbcTgwTRAKu7u7u+vr6goCA+Pt7X78FLfzP19PT08PBwd3e/zojbAFdX16tXr9IYy/knLi4uzs7OTk5O53/i5OQkXE4X0uUuLi4Xfo4u1CXcdtAncnFxuXjx4pUrV2jq5Obmxj/0kXN3d/fw8PD09PT19Q0KCoqPj09Oz3j165Xd3d19fX1KpbKvr6+rq6upqamysrKwsDA7OzsjIyNtQKpBpAwQ3imGMuZKTU1dYXfYxuVyYWFhZWVlU1NTV1eXQqFQq9UIsEA60EcF6UOf3/AQYAEYNXQOxIA7tEGCaIDV09PT2NhYVFSUkpLy0D/gpb9/6uvr6+3tfZsprwGenp50picakNGsRxiWDbpcd32K7mcovG25Z+QtpLP/eHp6enl58Q96tLy9vX19fR89ehQeHp6SkpKWmfXq0pU9PT1KpVKlUimVSvpbhC0tLXV1dVVVVRUVFeXl5WXiKy0tLSkpKS4uLioqEkYYKGOu4uLidcfO2F+/WVdX19LSQqdsU6lUmAALAGBE0Oc3PARYYsGETcyhScWAAEsMuJgxhyYdO61Wq1KpZDJZS0tLRUVFVlZWaMST/+t//5+goCB/f//HrD0a8PDhwwcPHvgJ3P8J/4GfHuL+fDAMutty/+aWcDt88ODBw4cP6YE9evSIf8Sj5e/vHxQUFB4eHh8fn5WVlZWX/+qyVXQ6IbVardFoVCqVXC7v6enp7Oxsb29vHdAivubm5qampoaGhtraWmGEgTLmqq2t3XL2wrHbvh0dHT09PVx6hduvxmi989WbkTH8pQCSgd4Uc2hSw0OAJRakLcyhScWAObDEgIsZc2jSsdNqtWq1Wi6Xd3R01NfXl5SUZGVlpaSkxMfHxw6IEcHTwUQL6F8+HINuOOhC/iGODW26+Pj4lJSUrKyskpKS+vr6jo4OuVxO0yutVkszLDqckP40Ya9B9PT0dHV1tbW1NTY2CiMMlDFXY2NjW1tbd3d3b2+vQqFAesUKAiyQOPSmmEOTGh4CLLEgbWEOTQrjBcbDM4f+wdjRJEWpVMpksra2tvr6+oqKiqKiooKCgrwBuYaV8xP+A+MKbbqCgoKioqKKior6+vq2tjZ6+xWXCGgHaDQatQEplUqFQiGTydrb2+vr64URBsqYq76+vr29vbe3l94nSE9R/kcGjBwCLLbQnsyhN8Uc+vyGhwBLLEhbmEOTAhgtdLmYoDdh0Vyjo6OjpaWlsbGxvr6+Dsamvr6+sbGxpaWlo6NDJpMNNRk2jQkMg2ZYdMRoZWWlMMJAGXNVVla2tLTIZDLMe8UWAhe20J7MoTcFEwACLACj9igpLbO8kr8UACYi7j4gOrN4QWXV79Zt7+7u7oKx6e7u7unpkclkcrm8uLbunU0Wz31AllarpQFWU1NTaWmpMMJAGXOVlpZ+d+SUa1C4Uql8vicqgB4IsABACAEWgFFD50AMHT0yTI0P0kRvz6ExVkld/dsbLZTAiEqlUqvVZfWN72yyfO6hAB0u2t3d3dDQUFhYKIwwUMZchYWFyw+fvBYYRse68s8eAGlAHxWkD31+w0OABWDU0DkQQ0VT8zubd/KXAkgGjbHKG5re2WSpARa4sXvljU1S+M+fC7Dq6ury8/OFEQbKmCs/P3/54RPXAkMRYAEAjAX6/IaHAEssmLCJueicfFNbR/5SGBsEWGLAxYw5NKkYKhqb39lsyV8KYyORc5UGWF1dXXV1dXl5ecIIA2XMlZeX963DiasBCLAYQ58KJE4iV6iJBE1qeAiwxIIAizkEWGLAHFhiwMWMOTQpwIjoBli5ubnCCANlzJWbm1tXV9fV1YUAiy0EWCBx6E0xhyY1PARYYkGAxRwCLBgvMB6eOfQPAEZEUgHWjxF/t480pbUn5EPhCmOvzPqw1t7aEzGLhQ/9Yj3IO55Q5ftjxN91FzpEftqnljX2lFkGvifcZJh1J/tga2/t3ZxDwoeebyHAEgkCLLbQnsyhN8Uc+vyGhwBLLAiwmEOABWC00OUCGBHpBFj2T0x/dmBadW5j1MEnC4VrjqVqOvMJIc6Jq4QP/WK19dYRQq6nWeguLGxJ6FV2OUYvEq4//AouciGEBBe5CB96voUASyQIXNhCezKH3hRMAAiwAIwahhACGC10ZMUgkVaVToB1ImYxIUSl6QsucgkruSJTdhBCCpsThGuOpcYSYF1IWuudZbs75H1uyf7wvwYXuZyJ+1a48ohKygEW5sAC6UOABQBCCLAAjBo6B2LA7cQwLkgkaplgJNKqUguwelVd9M8rKZsIIWqNklvhUOQ//AvOJtc8eJR/yjb8b3Th7pD3fXMcEqp8n5bfOhf/Hbeybfjf/HKPxlfdDS+55pK4hluuG2D5ZNsFFTntDZ1LH3pccPpxwWluTYfITx/ln0qsvn8/15GOZ/TIsAooPL8//K/6n8Irc59f7tGdQbPuZB+Mr7p7J/vgoKMLd4e8fz/XMb7q7q1nu4UB1o2MXU/Lb0WX37iWulW4rcEKARaMC+ijgvShz294CLAAjBo6B2KQyDdYAP1woopBIq0q2QDrepoFIaSzr5H+eT5+hVzVrdL0NXSXaLRqmbKDjtora0sjhDR0l/Qo2pt6KujKZ+O/ozdwcaLKb9CHdAOs1t5aQgg3HxZdk/7bOXGVUi3nNn9acYu3rf6nUKrl5W0Z3EMxFV68F7szaFbtwN6oXmWXboCVWR9GCGntrelWtBJCYitu8zY3WCHAAgBgQiIXfaOCAEssmLCJOTSpGBBgiQEXM+bQpGJAq4pBIq0qtQBLrVEm1zxIqw2g+ZF3li19tK6rUEs0p2KXmgfMuJ21nxCSUOV7KPIfhJCqjhy6zrGnX9J/VLZnE0L8C8/uDJrlkrhGpenTEs3hqM+HH2A19pTRPewOef9a6lavzH28bX/xKRp7ypwTV/nlHSWEKNVy3ov1fLaXENLWW3cydol7umWfWsYFWG5pOwghWQ0RFoEzrYPnNPaUaYmG+VxgwywEWCL5+tjZR8n92SuANEnkCjWRoEkNDwGWWJC2MIcmFQPmwBIDLmbMoUkBRkRqAZYuv9yj9KF9YfPobUpemfu8Mvc9LjhDCKlsz9oT8iGNflJrH3PjB21CP6KZ0c6gWXRJXtNTQsitZ7uHGWA5RH1KCFGoZdweaHHbDucpLiStNQ+YYRE4U61REkJ0Z84yD5gRU+FFCAkscqJ/hhZf4gIs+lBS9QP6YivaMwkhl5M38ZrLMIVJ3EWCAAskDr0p5tCkhocASyxIW5hDk8J4gfHwzKF/ADAiUguwelVdloHv0Xus+tQyeucRd3NWa28tV6k1j80DZlxO2UR/HJAQklLzkFu5rbeO23Nq7WNCiG+OwzADrJOxX/P2QIvbdvhPYR4wo1fVPzxwb+hfdHeVXhdECLmduZ/+qTsHVnZDBCGkW9Gq+2LprWeGLwRYIkGAxRbakzn0pphDn9/wEGCJBWkLc2hSAKOFLhfAiEgwwKJ/FjTHcdM/0TuwZMoOi8CZwg0tA99zS9tBZ6Q6EbPYNvxv9NcMuZue6HRUV1O28NIl+u/z8SvojOy0Qbh/6+6BFretcIWhnmKoACu2wpsQElp8if75tPwW7w4s7u6z51sIsESCwIUttCdz6E3BBIAAC8Co3YlNLKz51//LDQBGJbO88kOrA/ylMDYSaVXJBliuqdvoTVj0VwJpKhRecu1Q5D8coj71SLdySjCzi1jwKP/UwScLbUI/orNWHRmY2b2+q7h/XGHN49Nx3zzMPzEwGXwTDZt006Vn9aGEkMLmhDvZB+nm3BxYDd0lhJD02sBLyRvDSq7EVfrwth3mUwwVYN3MsKaR3K1newMKz2tJfzZEAyz6wltk1efjV9hHmtL9C5vLMJWbm7vI5uCdqBgEWCBlCLAAQAgBFoBRQ+dADA3tHVdDnvCXAkiMRKKWCUYirSrZAMsy8L3OvkZCyP1cR/OAGWfivu3sa9I98gd5xw5HfU6jHyq1tn9QoXDlbkUrnZGKly45J65SafroOrVdhTSToqu5JK7R/ZHBwEJn3rbDfIqhAqydQbOKW5PpthqtOrn6ge6vECZW3+f2TAiRq7qFzWWYQoAF4wL6qCB96PMbHgIsAKOGzoEYJPINFkA/nKhikEirSifA2hk0yzlx1dm45dySI9GLnBNXHYr8B/1zT8iH11K3Psg75p1lezJ2CV14OOrzO9kHfXMOc4ERt/LVlC13cw5dTdliE/oRt/z406+cE1dxQ/8coj69m3PoUvLGnUGzjkZ/4ZSwklvTNvxv19Ms7uc6no77ZtBth/kU5+K/c05cJRz8uDNo1tWULd5Ztg5Rn1oHz3FOXKX7U4PHn37llWnzMP+EW9oOeg/acykEWAAATEjkom9UEGCJBRM2MfcoOe3rY2f5S2FsEGCJARcz5tCkYkCrikEirSqdAAslwUKAJRL0qUDiJHKFmkjQpIaHAEssCLCYQ4AlBsyBJQZczJhDkwKMCAIslJ7CJO4iQYAFEofeFHNoUsNDgCUWBFjMIcCC8QLj4ZlD/wBgRBBgofQUAiyRIMBiC+3JHHpTzKHPb3gIsMSCAIs5BFgARgtdLoARQYCF0lMIsESCwIUttCdz6E3BBIAAC8CoYQghgNFCR1YMEmlVBFgoPYU5sGBcQIAFAEIIsACMGjoHYsDtxDAuSCRqmWAk0qoIsFB6CgEWjAvoo4L0oc9veAiwAIwaOgdikMg3WAD9cKKKQSKtigALpacQYAEAMCGRi75RQYAlFkzYxNzNyJj1zlf5S2FsEGCJARcz5tCkYkCrikEirYoAC6WnEGCJxNTWMTonn78UQDIkcoWaSNCkhocASywIsJhDgCUGzIElBlzMmEOTAoyI9AOsGxm7Wntr/QvOCh967mUROPNJ2fW4Sp9dQbOFj06AwiTuIkGABRKH3hRzaFLDQ4AlFgRYzCHAgvEC4+GZQ/8AYESkH2D55R3t/8nm8pvCh5577Q55X0v6Y51jT78UPjoBCgGWSBBgsYX2ZA69KebQ5zc8BFhiQYDFHAIsAKOFLhfAiCDAGmO5p1v6ZNlZBM4UPjQBCgGWSBC4sIX2ZA69KZgAEGABGLUbkTEVTc38pQBgBKJz8k1tHflLYWwk0qrSCbAsAme6p1tGlnnEVHjdyT5oHTyHLucCrMspmxKqfIOLXA5F/oPb6lLyxujyGwlVvj7ZP1oGvkcXHn/6VUjxxfiqu/dzHfeEfEgXnoxdQrf1yzsaX3X3eMxXwUUuXpn7uF15Ze4LLnKxCf1oX9i8uzmHEqvvx1X63Mk+qDs8cGfQLO8s25gKr4hS1+NPvzIPmHE359Cj/FM7g2bpfxX02e2fmDonrnpafiu0+LJdxAJut5aB7/lk2cVW3o4odT0fv0L/qzNk5ebmfmyxJzgpFQEWSBkCLAAQQoAFYNTQORBDRVPzjcgY/lIAiZFI1DLBSKRVJRJg7QyaVdqaqntgTT0Vu0Pe5wKsrr5//z8oXX3NNP25k32QECJTdtR1FRNCTsQsNg+YcT3dQq1RylXdDd0lwv1Ud+TRnbimbu9/+Vr13tC5dDCgStOn0vTtDnm/Xd5ACJGrutUaJSGksCWBHqR18Jyazn9fB7sVreYBM3pVXYSQvaF/Gc6rKGpJpEMOCSGdfU003toZNKuiPZMQ0thT1qvs0hLNneyDQ706AxcCLBgX0EcF6UOf3/AQYAEYNXQOxCCRb7AA+uFEFYNEWlUiARbNdyrbs/eFzdsf9nFlezYhJKT4IveQStPnlbnv2NMva7sKCSHhJdfMA2bQtIjOP2UfaWodPMc6eE5XX3OfWkYTrpDii4SQxwWnuf3Q3bql7bAOnlPZntV/f3HGLvOAGW5pOwghWQ0R5gEzAoucDkd9bh4wwyb0I7mqmxCyP/yv5gEz/Av6J3wob8vYH/bx0egvnpRd5wVYv/gqNFr1/VzHM3HLO/uaCCHXUn8wD5jxIO/YwC1mN8wDZuwLmydTdshV3VwWpvvqhO0mdiHAAgBgQiIXfaOCAEssmLCJOTSpGBBgiQEXM+bQpGJAq4pBIq0qkQCrsDmBEOKWtoP+6flsLyGkoDmOi37iKn3oQ745h7mHUmoe9s+M213ilbmPDvQ7Fbt04L6ncq/MfV6Z+56UXieEpNUGcPuhERWtR/mnCCHpdYHcrmiYZR4wY3/4X50TV7mmbmvr7f/5XXr3E71PijtIWroB1vBfBX063xyH/pCoMYoQElHqSo+5WVZJCDkc9bnw1Rm+EGCJBH0qkDiJXKEmEjSp4SHAEgvSFubQpGLAHFhiwMWMOTQpwIhIJMBq7CkjhDgnrqJ/XkxaTwip6sgRTuJOb5WqaM80D5jxY8TfaWZECGntrT34ZKFr6jZCiFItb+2t5Sqs5IpwP/23NT0xpUMFrYPn9CjaVJq+PSEfWgTOjKnwooMHZcoO+g8aYNFoiTtIWroB1vBfRXLNA0KIX95R84AZdFhip7yJO+BmWeWPEX8Xvjphu4ldmMRdJAiwQOLQm2IOTWp4CLDEgrSFOTQpjBcYD88c+gcAIyKRAKu4NZkQcjtzP/3TJ8uOEPKsPpSLflJqHtKH6Dg+etsUraPRXxS39G8eUep6Nm55/0RXnXnCpxAGWOYBM+gowtDiS9zNWWfjvyOE1HcV02GDNF2iARY9SN1533kB1i++ikEDrPym2IHhhFuFx8x7dcJHxS4EWCJBgMUW2pM59KaYQ5/f8BBgiQVpC3NoUgCjhS4XwIhIJMCisVRTT4VL4ppLyRvpNOo00+Hmroouv3Ejw1qm7OBCokf5p07HfWMZ+McnZf1DBUOLL9N7qQgh93Ic7CNNj0QvGpg567+FERItOoqQ3mZFxw9eS/2BzmO1O+T9yymb6BxYNMAKLnKhN0O5pe3wyrRp6C7hBVi/+CoGDbDoMVR2ZJ2MXWIfaeqUsNIn+8dBX52w3cQuBFgiQeDCFtqTOfSmYAJAgAVg1DCEEMBooSMrBom0qkQCrJ1Bswqa47ij0hINnSKdi37ymp5yv99X3Jq8M2iWecCM6s5//aQg/VE/OsjOLW0HTZ04V1O2CCMkWvZPTOlu6fhB84AZe0I+pCMB6ZzrdM54GmDtDnm/rC2d222zrFL4K4T6X8WgAdauoNmFLf8aKkjRUYeDvjoDF+bAgnEBARYACCHAAjBq6ByIAbcTw7ggkahlgpFIq0okwKJ1Pn7F3ZxDNzJ20R8BpPVjxN+dE1ftDZ17MnaJX+7Ra6lbaXplHjBjb+jc62kWD/NPeKRb6f5I3/7wv7ql7XiUf+rms92O0YvoQtvwvzknrjoU+Q/ek56KXeqcuIpGVLSsg+fcyLC+k33wcNTnB58sdE5cxe3cInDmxaT193Md3dJ20InVz8Ytd05cZRE4U/+r4D37och/OCeusg3/G7fCmbhvfbLs/HKPXk7ZRJ9uqFdnyEKABeMC+qggfejzGx4CLACjhs6BGCTyDRZAP5yoYpBIq0oqwEJJrRBgAQAwIZGLvlFBgCUWTNjEnJN/iJWbJ38pjA0CLDHgYsYcmlQMaFUxSKRVEWCh9BQCLJF8aHUgs7z/Ry0BpEkiV6iJBE1qeAiwxIIAizkEWGLAHFhiwMWMOTQpwIggwELpKUziLhIEWCBx6E0xhyY1PARYYkGAxRwCLBgvMB6eOfQPAEYEARZKTyHAEgkCLLbQnsyhN8Uc+vyGhwBLLAiwmEOABWC00OUCGBEEWCg9hQBLJAhc2EJ7MofeFEwACLAAjNrVkCcN7R38pQBgBB4lp3197Cx/KYyNRFoVARZKT+Xm5v5pk3l8di4CLJAyBFgAIIQAC8CooXMghsKaujuxifylABIjkahlgpFIqyLAQukpBFgwLqCPCtKHPr/hIcACMGroHIhBIt9gAfTDiSoGibQqAiyUnkKABQDAhEQu+kYFAZZYMGETc2hSMSDAEgMuZsyhScWAVhWDRFoVARZKTyHAEgn6VCBxErlCTSRoUsNDgCUWpC3MoUnFgDmwxICLGXNoUoARQYCF0lOYxF0kCLBA4tCbYg5NangIsMSCtIU5NCmMFxgPzxz6BwAjggALpacQYIkEARZbaE/m0JtiDn1+w0OAJRakLcyhSQGMFrpcACOiG2Dl5eXFxsb6+/t7e3t7eHi4urpeAyPj6urq4eHh7e3t7+8fGxubl5eHAEsMCFzYQnsyh94UTAAIsACMGoYQAhgtdGTFIJFWpQFWd3d3fX19QUFBfHx8UFCQr6+vp6enh4eHu7v79XFix4Ef3/96OX8pjIS7u7uHh4enp6evr29QUFB8fHxBQcGfNlkk5OQhwAIpQ4AFAEIIsACMGjoHYsDtxDAuSCRqmWAk0qo0wOrp6WlsbCwqKkpJSQkPD3/06JGvr6+3t/ft8cPKwfHDb834S2GEvL29fX19Hz16FB4enpKSUlRU9KfNFom5+QiwQMrQRwXpQ5/f8BBgARg1dA7EIJFvsAD64UQVg0RaVavVqlQqmUzW0tJSUVGRlZUVHx8fHh4eFBTk7+//ePw4cOrsvFXr+UthhPz9/YOCgsLDw+Pj47OysioqKmb/sDMpr0ClUmm1Wv7ZAwAAwyORi75RQYAlFkzYxJyDj5+Djx9/KYwNAiwx4GLGHJpUDGhVMUikVbVarVqtlsvlHR0d9fX1JSUlWVlZKSkp8fHxsQNixomjV1z/vmk7fymMBH3H4+PjU1JSsrKySkpK6uvr52zblVJQpFarEWAx9M7mnRVNzfylAJIhkSvURIImNTwEWGJBgMUcAiwxYA4sMeBixhyaFGBEtFotHUUok8na2trq6+srKiqKiooKCgryBuSC0aDveEFBQVFRUUVFRX19fVtbm0wmo+MHEWAxhAALJA69KebQpIaHAEssCLCYQ4AF4wXGwzOH/gHASNGbsBQKhUwm6+joaGlpaWxsrK+vrwOjVF9f39jY2NLS0tHRIZPJFAoFbr9iDgEWW2hP5tCbYg59fsNDgCUWBFjMIcACMFrocgGMFL0JS61WK5VKuVwuk8l6enq6u7u7wCh1d3f39PTIZDK5XK5UKtVqNW6/Yg6BC1toT+bQm4IJAAEWgFFz8g/p6JHxlwKAEbgZGbPe+Sp/KYyNpFpVO4DGWCqVSjkOXQ+LXHvuIn8pjJZKpaLR1TubLMsbm/hnDICUIMACACEEWABGDZ0DMWSWVz5KSuMvBZAYSUUtE4YEW5XGWFyYNb54RESvO3+ZvxRGRfdMeGezJa7+IHHoo4L0oc9veAiwAIwaOgdikOA3WAAhnKhi0G3V4CKXIOlUofN4rGMh1lturREuR42+Bs6HRWf+2zvjBP8kQY2hgotciluS+Z8IADChoStleAiwxIIJm5hDk4oBAZYYcDFjDk0qBrSqGG5GxqxzukJvcjEPmIFCoYyn5jksLG/AwEyQLlz3mUOTGh4CLLEgbWEOTSoGzIElBlzMmEOTwjhCR+qpVCrh91sUCjWBa96hhWX1DZgdHyQLvSnm0KSGhwBLLEhbmEOTwniB8fDMoX8A4wWXXsnlcuH3WxQKNYFr3qH/VVxTh194ZAWjBJhDb4o59PkNDwGWWJC2MIcmBTBa6HLBeMGlV52dncLvtygUagLXPPsF+RWVCoVCrVYjwBo7BFjMoTcFEwACLACjhiGEAEYLHVnmtFqtR0T0mjMXurq6mpqahN9vUSjUBC7fjOPt7e29vb0qlUqj0fA/IGCEEGABgBACLACjhs6BGHA7MYwLCLCY6w+wwqNWn3Zpa2urrq4Wfr9FoVATuLxTHBsbG7u6uhQKBQKssUMfFaQPfX7DQ4AFYNTQORADcgEYF3CiMqfVat3Doladcm5qaiotLRV+v0WhUBO4PBPsa2pqOjo6+vr6MIoQwBigK2V4CLDEggmbmLNy83TyD+EvhbFBgCUGXMyYQ5OKAa3KnEajcQ+LXHnSqaGhobCwUPj9FoVCTeCad+Cv2fkFbW1tcrkcARZIEK77zKFJDQ8BllgQYDGHAEsMmANLDLiYMYcmhXFBo9Eolcru7u66urr8/Hzh91sUCjWBa96BeZm5ea2trQiwQJrQm2IOTWp4CLDEggCLOQRYMF5gPDxz6B/AuEADrK6urrq6ury8POH3WxQKNYGLBlgtLS29vb0IsMZuutkm/J+sbKE3xRz6/IaHAEssCLCYQ4AFYLTQ5YJxQTfAys3NFX6/RaFQE7j6A6ycXARYrCDAYg69KZgAEGABGLUTfv5ypZK/FACMgJN/iJWbJ38pjIFGozn3MGCby1UEWCiUEZZHjG1ZWRkCLFYQYAGAEAIsAKOGzoEYkopKQjOy+EsBJAYBFnMIsFAoYy4EWGyhjwrShz6/4SHAAjBq6ByIAbkAjAs4UZlDgIVCGXMhwAIwNuhKGR4CLLFgwibm1jtfvRkZw18KY4MASwy4mDGHJhUDWpU5BFgolDEX5sACicN1nzk0qeEhwBILAizmEGCJAXNgiQEXM+bQpDAuTPhJ3C8nb/LK3Lc75H3zgBnWwXPsI00tA98Trqa/htrwcNTnwUUuHhlWwk2GX7pHOJw6H78ioPC8/RNT4UMoYf0Y8fd9YfOEy3+x9Gw40rdsdJsYphBggcShN8UcmtTwEGCJBQEWcwiwYLzAeHjm0D+AcUHUACu+6m5Ja3JJa3JGXXBcpc/1NAvhOmJXTWd+///zEbPYPGBGel0gIeRh/gnhavpr0A0tAmeWt2Uo1fKTsUuEmwy/dI9wOJVc84AQ4pW5T/jQSOtC0tqYCq/K9qyK9szw0ms2oR8J15FgnY77pqA5rqQ1ObcxKrnmwZ3sg3tCPhSuZh4w40j0IkJIr7JLGD7qL/0bjvQt07PJ1ZQtabUBdV3FVR05T8qu7w2dK9yWqwtJ6/KbYgua45i8+7QQYLGFUQLMoTfFHPr8hocASywIsJhDgAVgtNDlgnFB1ACLPkW7vEFLNPTfcZU+wtVELd3gIKzkSmtv7Y0Ma+Fq+mvQDb0y92m06rGnckNFG0MVqwArpPjiz04FQpJqHghX019OCWatvbXJ1SPecCwVXOTCO/LGnrJBox+7iAVNPRUV7ZkWgTOFj+op/RuO9C0bapOTsV/TmKytt46+kKyGCOG2tHYGzWrqqaCrJY/8nRqqEGCxhQCLOfSmYAJAgAVg1DCEEMBooSPLnKhzYNGnsI/sH+x2J9ue/sm7zccuYsHOoFnCbelD1sFz6L/3hHxoG/434TpD7WF3yPv0iQYNDriyDf+bfaSpcHPzgBl7Q+f+GPF34XKudgbNoi9t0LIOnjPUADRa+o9w0BdFSxhg7QqabR9puj/8r7w16cjHQYetnYxdoiUaLdE8yj+1O+R9y8D3bmfuDym+KFxT/z5dU7cRQkpak4Vr7g//66ChEq1ffHP1HDwNsGiI4xi9qKuvmRDyuOC07jp7Q+cKG4QrPcemZ0M9b9lQJ5KeTcwDZthHmt7JPki38i84SwhRa5TC56X1IO84IaSyo/++CYYBFiZxZwsBFgAIIcACMGroHIgBtxPDuIAAizmDBVh7Qj6kfzpEfUrH3z3MPyFXdRNCtESTVutPR4HFV93VEs2l5I30nhS5qvta6lb/grMqTR+90ebgk4V050PtwTp4TmrNY3rPV25jVLOskgsO4ip9CCH0RqpLyRtbZNX/agStWvfWsBMxi2ncQAip7y7+MeLvuhv25w5PTAubE+hTaLTq+Mq7NGexi1igJZqn5bfiKn3Umv7/o6W8LUM4Lk/PEQ71onRLN8DaGTQrrTaAPhchpFlWeSbuW7qfpOoH9CnUGuWtZ7t5O8moCyaE5DU95S2nQ+cq27Pon5eTNxFC0usCB93n3ZxD9Hmp2MrbdKv7uY49ija6sEVWfSFpHV0+zDdX+ES8g9QNsMwDZqTVBnA399Gn8Mrcp9Yo1RrljxF/1xJNU08Ft63+YxtqQz1v2VAnkp5NBq2bGbsJIZ19jcKHzANm7Aub16vsqmjPfJB3DAGWlKGPCtKHPr/hIcACMGroHIgBuQCMCzhRmTNAgHU+YcXhqM+jym8QQhq6S+iYLM9newkhxa3J11K2Jlf3JzIxFV5cOqPRqsvbMqo78+i/1RplZkMYzR2elt+iOx9qD48LTtNhWWm1Ad2KVnoMNDjQjX7SagOKW5Mf5B27k32Q3sJzJWUTvZuJxitZDRERpa5dfc3nE1bwMqPGnjJCSHbjk9DiSzSYiC6/QW+ooQfcq+x6Vh9Kc6jgIhdes+g5wqFelG7pHszhqM97FG0xFV63M/cnVfvRO3TMA2bcetafhuQ1PXVJXONfcNbz2V7eTuq7igkhd7IP8pafiFlMCKnpzKd/0hussgfGtQn3eT5+RVFLIiGkq685ueYBncyevoQeRVtYyRV6qH1qmV3EguG/ucIn4h0kL8Cq6sgZuAPrjO5TNMsqK9uz6DvS2ltL1xzOsQ26oZ63bKgTSc8munU46nOvzH2PC073KNo0WvVQI0NjKry0RHMm7lu/vKMIsABgLNCVMjwEWGLBhE3MoUnFgABLDLiYMYcmFQNalTkDBFic0tZUx+hF9CF6i9PhqM/pvSpaoumQN3A5QkKVL71pS6NVE0KupmwxD5jhnm5J72nSvweaKLmmbqO3StFkRBhg6U7OHV5yjRuDdj3NghBS0Z5JH9oT8qFl4Hu6G15PM+dyIvOAGceffkUIUarlXIDVp5bRl+mTZcelP7ql5wiHelG6xRtCyL2QXUGzCSEqTZ95wIyH+ScGnjpyqIFySrWcEHItdStvuZ4Aa9B9CocQ1ncVEUIuD4Q45gEzMuvDCCGP8k8N/80d9Il0iwZYNZ35wUUuxa3JNCfSzaHK2tJ2Bc3m3hEuh/rFYxtqQz1v2VAnkp5NdCuoyIn7D6SwJeFU7FLh6z0S/YVGq06teWweMIN5gDXvwDwEWCBluO4zhyY1PARYYkHawhyaVAyYA0sMuJgxhyaFccEAk7hHl98oaI4jhNR2FXKRBA1Q2nrrWntrW3trtURDZ//hpTO9qi5CyN7Qv5gHzHBOXKWbrQy1Bzqejpt/SnfuId2d7w55P6DwfFFLUl1Xca+y/1norVIBhed17/OipbshTRx0V6DP+GPE33mphzDc0V1/0CMc6kUNdTB0GvX0usCytrTW3lra4OYBMw4+WUjv+lGq5XGVPsIkqEPeQAjxzrLlLdcTYA26T95rtAx8j746buAkndopvuqu8MiHenMHfSLd4k3iXtyazOU+vKfQfUdGdGy8t1LPWzbUiaRnE92yDf+bc+Kqi0nrcxqf0PyRC3m5yqwPU2uUTgkr7SNN6dT7z+pD9c+wNvxCgAUSh94Uc2hSw0OAJRakLcyhSWG8wHh45tA/gHHBAAGWfaSpReDMyvZsQkh4yTX6EJ326G7OIa/MfbTonTjDzDj07IEGB/vDPqarDRVg5TfFEkJyGiIfF5zOaojgcgcajsRWeOu+EN0N6Qo09aAjCuk8R3tCPhxRgDXoEQ71ooY6mPPxKzRadbeiNbzk2p3sg7TB6Wr7w/8aWnyZ3vgj/G07euMSndxKt449/ZLOpUX/1A2wBt2nMMCi91Vx89+HFl8ihESWeYzozRU+kW7Rt+BZfahwEn09OdSIjm3QAGvQt2yoE0nPJoPWzqBZ9PAe5p/gPdTY3T9klaehu0S4k1EUAiy2Ji824y+CsUFvijn0+Q0PAZZYkLYwhyYFMFrocsG4YJgAyzxghlvaDkKITNlB5zuv7SocmC3o3+kM/S224WccQ+2Bftu/m3OITrBNIyFegGUZ+J6WaFQaBZ2Q62n5LS53uJFhTe+Bosd5PmGFQ+SnukdFB7u1yKrpCvRPmvgMM8DSc4RDvSjd0j0Yej+Of8FZ84AZNqEf0QanP6VHVz4U+Q9CSLtgHOLtrP10nvjbWfvpEpfENX55R/eHfUyngrKLWLA75P38pv4+DA2wBt2nS+Ia3cDLPGBGQ3cJ9+p2Bs2iwQ2diH2Yb+6gT6RbvDmwdEt/DjX8Y+NtONRbpudEGmoT3aN1iPyUDhc1D5hxOu4b+va5p1vSubHiq+5eT7Og02kl1zygRX+FsFlW6V/Y/6aPvRBgsYUAizn0pmACQIAFYNQcfPrnqQUAI+Tg44dPALY0Go2919391z3FDrB2Bs2iU1zTYWt0Om2lWp5RF5xc86C+qzijLliYIwyVcejZg2/OYRrBNHSXaImGzqQuvAOLTlGU1RCRVhtAb6GiucPOoFmtvTV0YnIacFxL3aq74c6gWXQG9LbeurK2NLVGqSUa19TtwtRjqABLzxEO9aJ0S/dg6HznnX1NT8tv0VdEA6wnZdcbe8qelt/6151Wtfw7rSwCZ9JxnXTSLnoMGXXBFoEzacrTq+xSquV0TBwNsAbd5/6wj+mtRs2yyqcV/cMqaQJIZ2qnP89X1ZFD851hvrmDPpFujTrAGv6x8TbU85YNdSLp2YSr+7mOtOmqOnLo7Vd1XYX0dyfpXFdFLUm8F8h8DixM4s4WAiwAEEKABWDU0DkQQ3ROfnTOv342HkCyEGAxJ2qAVdAcV9SSxE05dD/XsaQ1OajImf7plrajqCWRTvZU2JxAp9b2yzta0pp8IWkdXedZfWhRS5J18J8HprJeVNKarPurfIPuwTxgRmCRU11XcVVHzr2cw95ZtiWtyfZP+kM03Z2fjPm6qCWptbc2vynWLW1HSWvyjQxruvmPEX9PrX3c2F3W1FMRU+FlHTyHd1Q2oR/FVfrUdhU2yypzGiPPJ6zglhe1JNHJts0DZpyKXVrSmsyNmtStoY5Qz4viSvdgLAJnhhZfbuqpqOsqDi5yCSu5UtAc1//qYpcUtiS09tY29VQ8Lb8lnEaKbuub45DX9LRFVt3YXRZfdZceg2P0ItoyGXXBDlGfFrUk0URmqH3eztpf21XYIqvmbuZyTd1W2Ny/ZlVHTmjxJevgOcIj1/PmDvVEXN3IsC5pTfbLOyp8UcJ3SvcdGf6xCTcc6i3TcyINtQlXtuF/i6+629hd1tpbW92ZF15yjfuPhc7F9qTsOu8FXk3ZUtKaLBxmOOpCgMUW+qggfejzGx4CLACjhs6BGJALwLiAE5U5UQMsFAo1irIInNnUU9HV18zlWeIVAiwAY4OulOEhwBILJmxi7utjZx8lp/GXwtggwBIDLmbMoUnFgFZlDgEWCiW1upKySUs0l5I3Ch9iXpgDCyQO133m0KSGhwBLLAiwmEOAJQZ85ooBFzPm0KQwLog6iTsKhRpF7QqavT/8r8LlYhQCLJA49KaYQ5MaHgIssSDAYg4BFowXGA/PHPoHMC4gwEKhjLkQYLGFUQLMoTfFHPr8hocASywIsJhDgAVgtNDlgnEBARYKZcyFAIstBFjMoTcFEwACLACjhssYgNFCR5Y5zIGFQhlzYRJ3thBgAYAQAiwAo4bOgRhwOzGMCwiwmEOAhUIZcyHAYgt9VJA+9PkNDwEWgFFD50AMyAVgXMCJyhwCLBTKmAsBFoCxQVfK8BBgiQUTNjGHJhUDAiwx4GLGHJpUDGhV5hBgoVDGXJ84LkSABVKG6z5zaFLDQ4AlFqQtzKFJxYDPXDHgYsYcmhTGBUzijkIZcyHAAolDb4o5NKnhIcASC9IW5tCkMF5gPDxz6B/AuIAAC4Uy5kKAxVBHj2y62Sb+Uhgb9KaYQ5/f8BBgiQVpC3NoUgCjhS4XjAsIsFAoYy4EWAwhwBIDelMwASDAAjBecqXyhJ8/fykAGAcrN08n/xD+UhgDjUZjedXj+J37CLBQKCMsTOLOEAIsABgUAiwA44XOgUhCM7KSikr4SwEkBgEWcwiwUChjLgRYDKGPCuMC+vyGhwALwHihcyAS5AIwLuBEZQ4BFgplzIUAC8DYoCtleAiwxIIJm5gztXXEJHlsIcASCS5mzKFJxYBWZQ4BFgplzIU5sEDicN1nDk1qeAiwxIIAizkEWMxhDiyR4GLGHJoUxgXdSdzz8vJiY2P9/f29vb09PDxcXV2vAcCEc/369Vu3bt2/f//BY///e9GSsrKy1tZWBFggTehNMYcmNTwEWGJBgMUcAiwYLzAenjn0D2BcoAFWd3d3fX19QUFBfHx8UFCQr6+vp6enh4eHu7v7dQCYQNzd3W/cuOHt7f3w4cNHgUH/9//5uqKioq2tTS6XI8AaI4wSEAN6U8yhz294CLDEggCLOQRYAEYLXS4YF2iA1dPT09jYWFRUlJKSEh4e/ujRI19fX29v79sAMOHcuXPn/v37QUFBQWHhr3yxtKqqqr29HQHW2CHAEgN6UzABIMACMF4YQghgzNCRZU6r1VpevXHq3sOWlpaKioqsrKz4+Pjw8PCgoCB/f//HMHJf7di50fYgfymMjfdd3/9rwaf8pTAqAQEBISEh0dHRqamphYWFdXV1nZ2dfX19CLDGCAEWAAwKARaA8ULnQCS4nRjGBQRYzGm12p3Xbp6+/7ijo6O+vr6kpCQrKyslJSU+Pj52QAyM0Ld7bc2Pn+IvhbEJCgt7+ZP/5i+FkYuNjY2Li0tMTExPT8/Pz6+srGxpaenp6VEqlRqNhv8BASOBPiqMC+jzGx4CLADjhc6BSJALwLiAE5W5/gDL9eaZB/4ymaytra2+vr6ioqKoqKigoCBvQC6M0GqH4/suXOEvhbFJTE175b+X8ZfCyOXl5eXn5xcWFpaWllZXVzc1NXV2dsrlcpVKhduvAIwBulKGhwBLLJiwiTk0KXMIsESCixlzaFIxoFXFYOV669yjQIVCIZPJOjo6WlpaGhsb6+vr62BUNp9xPnzDi78UxqagpPR/fG3GXwqjUl9f39DQ0NTUVF5T8+rytTS90mg0CLBAgnDdZw5NangIsMSCtIU5NClzmANLJLiYMYcmhfFCq9VqNBq1Wq1UKuVyuUwm6+np6e7u7gKAiah7gEwmq29p/Z/fb0B6BVKG3hRzaFLDQ4AlFqQtzKFJYbzAeHjm0D+AcUQ7gMZYKpVKCQBGoKWjc/qKjUivWMEoATGgN8Uc+vyGhwBLLEhbmEOTAhgtdLlg3KExFhdmAcAEptVq27p7ELgwhABLDOhNwQSAAAvAeGEIIYAxQ0dWDGhVtqzcbjn5B/OXwti0IxoAyUOABQCDQoAFYLzQORAJbieGcQFRixjQqmyhPcWAqz9IH85SGBfQ5zc8BFgAxgudA5HgGxeMCzhRxYBWZQvtKQZc/QEAmMBFyvAQYInlQ6sDmeWV/KUwBmhS5tCFFQkuZsyhScWAVhUDWpUttKcYcPUXQ0VT8zubd/KXAkgJPlGZQ5MaHgIssSBtYQ5NyhzmwBIJLmbMoUkBAMRQ3JIcXOQShBptBRe5FLckI8CCcQG9KebQpIaHAEssSFuYQ5PCeIHx8MyhfwAAwJxWqw0qdDYPmIEaSwUVOmu12opGBFgsIRAUA3pTzKHPb3gIsMSCtIU5NCmA0UKXCwCAIa1Wq9Fo1Gp1YIGTMJFBjagCC5zUanVZQ+M7my35DQ2jhQBLDOhNwQSAAAvAeHX0yHAZAzBa652v3oyM4S+FsUGrsoX2FEN5Y9M7myzVarVCoXicd06YyKBGVI/zzikUCrVardFotFotv7lhVBBgAcCgEGABGC90DkTyKCkNdwuC9CEaEANalS20pxjKG5re2WihUCh6enoeZJ8WJjKoEdWD7NM9PT00w0KAxQr6qDAuoM9veAiwAIwXOgciwTcuGBdwoooBrcoW2lMMZQ2Nb2+06O3tbW9v9804LkxkxntdSFrn+WzvzqBZwofEKN+M4+3t7b29vSqVSqPR8JsbACYuXKQMDwGWWDBhE3PvbN5Z0dTMXwpjgABLJLiYMYcmFQNaVQxoVbbQnmLoD7A2mHd1dTU2NnqnOAoTmXFde0PnqjR9fWqZdfAc4aNilHeKY2NjY25Z+TsbzBFggZThE5U5NKnhIcASCwIs5hBgMYc5sESCixlzaFIAACa0Wq1are7r6+vo6KipqfFMsBcmMqJWSPHF1t7aO9kHuSWHIv/RIquuaM/UXc0h6tNmWWVrb21i9X1uYWChc2tvrbCcE1dx63hn2RJCUmsfC59apPJMsK+pqckqLn17gzlGEYKUoTfFHJrU8BBgiQUBFnMIsGC8wHh45tA/AABgggZYcrm8ra2tsrLyRpydMJERtZJrHhBCgotcuCUnYhYTQnpVXbqrBRY50QPWaNUHwv9GFwYXudDESqmWE0Jkyg5hgFXUkkQIuZS8UfjUItWNOLvKysrMouK3N+xAgMUKRgmIAb0p5tDnNzwEWGJBgMUcAiwAo4UuFwAAE1yA1draWl5e7hH7ozCREbWGGWA19pSpNcqytjRCyL0cB95OshsiCCF+eUd5y+0iFmiJpquv2TLwPd5D4pVH7I/l5eXPCosQYDGEAEsM6E3BBIAAC8B4YQghgDFDR1YMaFW20J7MabXa0vqGt9dvb2lpKSsr84ixFSYyotZwAiy6JK/pqVfmvv6fTWzL4O1kqADrUf4pQsjT8lu85aKWR4xtWVlZS0tLb28vAixWEGABwKAQYAEYL3QORILbiWFcQDQgBrQqW2hP5sZFgBVR6koI8crctzd0rlqjJITYPzHV3clQAVZ1Zx4h5HTcN8LnFa8QYIkBfVQYF9DnNzwEWADGC50DkeAbF4wLOFHFgFZlC+3JnPQDLIvAmW29dWqNcm/oXPOAGXlNTwkh/gVndXcyaIB1NPoLQkizrFL4pKIWAiwAo4WLlOEhwBILJmxiDk3KHAIskeBixhyaVAxoVTGgVdlCezL33AOshCpfQkhYyRVuCQ2wZMoO+ufZ+O8IIZ19TcFFLsFFLgXNcYSQ+q5i3Z0MGmCFlVwhhIQUXxQ+qahFA6zo9Gfvm+9FgAVShk9U5tCkhocASyxIW5hDkzKHObBEgosZc2hSAAAm6CTuvb29zyvA8i84SwjJbAjjllxN2UIIqe7MpX/GVt7mH/SAY0//m9tEGGBZBM5s7a0lhByO+lz4pKIWAiwYL9CbYg5NangIsMSCtIU5NCmMFxgPzxz6BwAATDz3AOtC0lpCiEardk+33Bk063DU53VdhYSQyDIP84AZloHvdSta6TxW9pGmtCraM3k3bQkDrPPxKwghle1ZwmcUuxBgiSGzvPJDqwP8pTA26E0xhz6/4SHAEgvSFubQpABGC10uAAAmnnuAZR4wI7XmMe+oGrpL9oR8aB4w42LSekJIVUeO7vr3chwIIS2yam6JMMCi923dz3UUPp3YhQBLDAiwxIDeFEwACLAAjFdDe8fVkCf8pQBgHL4+dvZRchp/KYwNWpUttCdzWq02vaTsffM9zzHAMg+YcT3NIqHKt7AlIaXm4d2cQzuDZtHlF5LWJdc8uJa6VXflfWHzEqvvx1fd3RU0my65nbU/uebBmbjl9M+dQbN6FG0arfpA+N+EzyV2YRJ3MSDAAoBBIcACMF7oHIjkTmxiYU0dfymAxCAaEANalS20J3MSCbDYFp1Fq6A5TviQAQoBlhjQR4VxAX1+w0OABWC80DkQCb5xwbiAE1UMaFW20J7MTcgAi44f9MiwEj5kgEKABWC0cJEyPARYYsGETcxNN9vU0SPjL4UxQIAlElzMmEOTigGtKga0KltoT+YmZID1fAtzYMF4gU9U5tCkhocASywIsJhDgMUc5sASCS5mzKFJAQCYkMIk7hOsEGDBeIHeFHNoUsNDgCUWBFjMIcCC8QLj4ZlD/wAAgAkEWMwLAZYYMEpADOhNMYc+v+EhwBILAizmEGABGC10uQAAmECAxbwQYIkBAZYY0JuCCQABFoDxwhBCAGOGjqwY0KpsoT2ZwxxYzAuTuIsBARYADAoBFoDxQudAJLidGMYFRANiQKuyhfZkDgEW80KAJQb0UWFcQJ/f8BBgARgvdA5Egm9cMC7gRBUDWpUttCdz0g+wLAPfi628HVPhJXyIVflk2yVW33eI/FT40CgKARaA0cJFyvAQYIkFEzYxhyZlDgGWSHAxYw5NKga0qhjQqmyhPZljEmAlVfu19ta29ta2yKrzm2LvZB+0DHxPuNroam/oX+ihCh9iVSWtyYQQ19RtwodGUTTAehQbv9DGHgEWSBk+UZlDkxoeAiyxIG1hDk3KHObAEgkuZsyhSQEAmGAyiXuvqosQUtWRU9tVqCUaQkh6XaBwtdEVAiwAkaA3xRya1PAQYIkFaQtzaFIYLzAenjn0DwAAmGAYYJ2IWWweMONS8ka6Z7uI/2UeMONEzGK7iAXWwXPc0nbYRSygS45Gf0E3tAx873TcNwefLOR2ZR0851Ts0ivJm36M+DtdohtgnYz9+mrKlr2hc3Wf/VDkP66mbLmUvNE+0lR3+anYpW5pO87GLbcInCk8ZsvA907ELL6YtH53yPvCAOvgk4VXkjedjP16V9Bs4bb6CwGWGKJz8k1tHflLYWzQm2IOfX7DQ4AlFqQtzKFJAYwWulwAAEwwD7AsA/9I93wqdumekA8JIYXNCdWdef0ZRPlNmkb1qrrohk4JKwkhNZ359M9TsUvbev/13U9LNOEl13QDrLymp/QffWrZ2fjvaAhV1vbva4FGq/bNOUyXcysPPO8N3gFbB88paI6jj7b11rXIqrkAyyJwZkyFJ7dts6ySi9uGWQiwxIAASwzoTcEEgAALwHhVNDXfiIzhLwUA42Bq6xidk89fCmODVmUL7cmcVquNzMz5XzYHWQVYLolraPxkHTyHy57kqu6UmofeWba8AMs5cRUXYO0MmtUsq1RrlG5pO449/bKyPZsQcjFpPbeTtt463xyHktZUbpNdQbOrO/Pu5zo6J67yzrLVEk2fWmYeMONyyiZCSHbjE/tIU5fENR4ZVrwDfph/gu7wQd5xLgKjAdbtrP2EkNzGqCPRi3yy7Qgh5W0ZwpespzCJuxgQYAHAoBBgARgvdA5EciMypqKpmb8UQGIQDYgBrcoW2pM5hgFWVUdOSWuyWqMkhIQWX9K9eep8/Aq6pp4Ai/67pDXZPtLUPtL0Uf4pQkh4yTVuJ/ZP+kcIHgj/G51mixtjyFW7vIEQsjf0L9dStxJCGnvKnBLMhEdrHjCjrC2dEOKebklTsMaeMi7AKv5pOCE9jM6+RkLIiAYSIsASA/qoMC6gz294CLAAjBc6ByLBNy4YF3CiigGtyhbakzmGARYhpFvRWtaW7vlsL512Sjj/up4AyzvL9mdHNiCu0ke4k66+/u+H9IYv93TLivbMPvW/55TYG/qXnUGzilqS6J81nfknY77mHXDHQNR1OOpz+qfuHFj0IR7b8L8JX/VQhQALwGjhImV4CLDEggmbmJu82Iy/CMYGAZZIcDFjDk0qBrTq/9fenYe1md15ov/z1pKk+066O5mtp6d77s19xlPpupVJVzqdZDqZdPWkk5tJ2nYlVZWyXYtrSapSxgs23lfAK7YBYxsbY2OwwQvG7GAMGGPMvu9aEBJCAm0I7dt7H+nYb71+BRjDOUiyvp/nPP2Yd5V+peYcvnnPEQuoKl2oJ3UUAyySKAlbcPZEVsXy+jzkR2GAldm2nuM4maE15eEavsVVfE90kfUl33Z57IFF4n+SVP+Wj/MabOrMtvUpD9eQYCuu4u/JkWebPxnSPfQ/ijUtE70wsujVicBCWqIASzMt4TjuatdO/jUEv6+5G9bAgkiB36jUoaRLDwEWKwiwqEOARR3WwGIEnRl1KCkAABXUF3EXtuAAa13xMrfXwXFcRusXe+7+lEzlIwFWYu0vfZzX4jTwjzvtufvTLeWv8xepG8neXP7dW32HOI4zOyZjSl653rOf47gm5a11xct2Vf3Y5vK/jLiKv99X/c/bKn/gnx5Y9prX53F7HaIX1qOt5jiuUXlrQ+mrF9s2en0ePsBqU5fwUyBJXhZf+wvR6XM3BFgQKTCaog4lXXoIsFhBgEUdAiyIFJgPTx3GBwAAVCx9gNU6VszffdKqcHsd/LcQPlTeJF8yOGrq0dtUHMcFHsLyX8Ro15CYicjvTVxXvOxI3Uqvz+Pxuob1TVaXiTyZFVfx9zd7491eh8zQOmGRcxzXOlYkemEpD9cIrzZpVfABVnztL8h19DaVcqrP7p6W6JtEp8/dEGCxgFkCLGA0RR3G/EsPARYrCLCoQ4AFELUw5AIAoIJKgFUxfPrB6LXtd34o2r6h9NX7iiv3Ri4LN8aWfadScrZXW1MxfDqu4nt3ZRdu9x/l92Z3xDWrCiT6po7xivzexNiy72wofbVh9Hpe956TDe92jld2aiovtcfyx6c1ru0Yr+jUVF7p3J7R+kXD6PVNpa9tq/xBlfT8oK6hU1OZ35u4ofTV4Nec+vD9h8qbrWPFGa1fJDesblLdSqz9Jdm15+5Pa+WXerTVg7qGe/LLSfVvBZ8+R0OAxQICLBYwmoLnAAIsgOiFKYQA0QwDWRZQVbpQT+qorIGFJmxYxJ0FBFgAMCMEWADRC4MDRvA4MUQERAMsoKp0oZ7UIcCi3hBgsYAxKkQEjPmXHgIsgOiFwQEj+IsLIgI+qCygqnShntQhwKLeEGABRC10UksPARYrWLCJOpSUOgRYjKAzow4lZQFVZQFVpQv1pA4BFvVGAqzLFVXL9x9BgAXhDL9RqUNJlx4CLFaQtlCHklKHNbAYQWdGHUoKAEAFlUXc0YQNARZECoymqENJlx4CLFaQtlCHkkKkwHx46jA+AACgAgEW9YYAi4XbTa0rDx4Xb4XFwWiKOoz5lx4CLFaQtlCHkgJELQy5AACoQIBFvSHAYgEBFgsYTcFzAAEWQPQaVKnz7j8UbwWA6PD6xh2dcoV4KywOqkoX6kmdz+e71dD8r/sPI8Ci1bCIOwsIsABgRgiwAKIXBgeMpJff1RhN4q0AYQbRAAuoKl2oJ3XhE2BtKH21aOB4k+rWXdmFAzU/b1Ldutr19BcTX/uL7I64uIrvBe8KVUOAxQLGqBARMOZfegiwAKIXBgeM4C8uiAj4oLKAqtKFelIXPgHWHck5/lWdb/mc47huTVXwYaI2qGvgOK5w4FjwrlA1BFgAUQud1NJDgMWEyWL95qpPxFthEVBSFhBgMYLOjDqUlAVUlQVUlS7Uk7rwCbA00xKO45IbVm0ofXX+AdatvkNDusZj9b8N3hWqhjWwIFLgNyp1KOnSQ4DFBNIW6lBSFrAGFiPozKhDSQEAqAiTRdz3Vr9hdfnn3RyuW76t8geiAGt/zc+O3n8zpuQV8uOhe78+dO/X5N/bKn9w4sE7m0pf4y+1r/qf05t/f7z+7S3lrwffaAkaAiyIFBhNUYeSLj0EWEwgbaEOJYUIgvnw1GF8AABARTgEWLuqfix8SQOT9aIAS2dVkmyL/EgOI//u1FRyHJfdEUfCrF5tDX8dq8t0tvn3wbdj3RBgsYBZAixgNEUdxvxLDwEWE0hbqENJAaIZhlwAAFSEQ4C1ofTV4sGTbq+D47g7knPnWz4XBVh629hsAVa3porjuJzObeuKl7WpSziO65u4d77l83vyyxzHWZyGzeXfDb4j04YAiwUEWCxgNAXPAQRYANELUwgBohkGsiygqnShntSFzxpYNreZ47i4ir9fV7xsAQFWXMX3OI7zeF1bK75Pdqmm+jmOO9fyh+B7MW1YxJ0FBFgAMCMEWADRC4MDRvA4MUQERAMsoKp0oZ7UPTcB1tH7b3Icp7Mq+Qu2jhVzHHe9Z3/wvZg2BFgsYIwKEQFj/qWHAAsgemFwwAj+4oKIgA8qC6gqXagndRERYGmnZRzHka8ajCl5hbxysosPsBJqf0HWveIv2Ddxj+O4zLb1wfdi2hBgAUQtdFJLDwEWE1iwibqRiclvfbpBvBUWBwEWI+jMqENJWUBVWUBV6UI9qYuIAEuib+E4rlJydvudHzYqb5FXTnbxAdam0tfI9xhmtH6xrnjZ4brlHq/L43XtrvpJ8L2YNhJgnbpV9H7SKQRYEM7wG5U6lHTpIcBiAgEWdQiwWMAaWIygM6MOJQUAoCIcFnEnbY4AK783kX/Bdvf0lGMiOMBaV7wsr3sPOWbK7j+A47jCgWPBN2LdEGBBpMBoijqUdOkhwGICARZ1CLAggmA+PHUYHwAAUBE+AdYdybl6Re6m0tfWFS87UPPzh8qbV7q2k10xJa/k9yX2aKvrRnLia39xvedA3UgO2SUMsNYVLzvV+GG9Indgsv6+4srppo+D77IEDQEWC1nVdWtT0sVbYXEwmqIOY/6lhwCLCQRY1CHAAohmGHIBAFARPgHWs7aYklcO3fv1hGXE/0dj8++DDwhVQ4DFAgIsFjCagucAAiyA6NUpV9xubBVvBYDo8K1PN4xMTIq3wuKgqnShntT5fL6Ld2rfO5YacQHWnrs/JW9Bb1NtKH01+IBQNSzizgICLACYEQIsgOiFwQEjyUXlJotVvBUgzCAaYAFVpQv1pC5yA6wNpa8W9B/O703cVfXj4L0hbAiwWMAYFSICxvxLDwEWQPTC4IAR/MUFEQEfVBZQVbpQT+oiN8AK24YACyBqoZNaegiwmMCCTdShpCwgwGIEnRl1KCkLqCoLqCpdqCd1CLCoN6yBBZECv1GpQ0mXHgIsJpC2UIeSsoA1sBhBZ0YdSgoAQIVoEffSh9mnyjYkFXx26PrHCXlr469+wK4dIO3K+/tz3tuXvWYvaZdXi9qey6v3ZK3anbVq96V3d116d9fF3+28+Ludme/suPD29oy3tgXa9gtv78x8Z9fF3+269O7ux21P1qq9l1fvy16z/8r7B668fyDoBVBsCXlrD13/OKngs1NlG0ofZiPAgoiA0RR1KOnSQ4DFBNIW6lBSiCCYD08dxgcAAFSQAMtut+v1erlc3tbWVlVVlZ+fn5OTk5mZmZGRcZ6lc+fOpaennz179syZM6dnkZaWdurUqdTU1JSA5OTkkydPHj9+/NixY0eOHDl06NDhw4ePHj16/PjxkydPkmNSUlJSU1NPnTp1+vTpM2fOpKennwsQ356SjIyMzMzMnJyc/Pz8qqqqtrY2uVyOAIsuzBJgAaMp6jDmX3oIsJhA2kIdSgoQzTDkAgCggg+wDAaDQqHo6OioqakpLCzMy8vLzs7Oysq6xNjFgMzZXXiMT9POnTt39uzZtLQ0kmqlpqampaWdPXuWj6gyAshZmZmZ5BbiG9OTlZWVnZ2dl5dXWFhYU1PT0dGhUCjSCkoQYFGEAIsFjKbgOYAACyB6YQohQDTDQJYFVJUu1JM6/xpYVbXvJZ0ymUwqlaqvr6+hoaGysrKwsDA/P//GjRvX2bs2P3kBubm5V69evXLlCsnXiOzs7CtXrly9epUck5eXJzxRfD/abty4kZ+fX1hYWFlZ2dDQ0NfXp1KpTCaTw+FAgEULAiwAmBECLIDohcEBI3icGCICogEWUFW6UE8WLlbVvn88zWw2a7VaqVTa2dnZ0NBQU1NTVVVVuYQq5q28vLysrKwkoLi4uKSkpLS0tKysrLy8XHxoRYX4NmxUVVXV1NQ0NDR0dnZKpVKtVms2m51Op9frFZcbFgRjVIgIGPMvPQRYANELgwNG8BcXRAR8UFlAVelCPVm4WHXv/ROnbTab0WhUq9VSqbSvr6+jo6Otra21tbUl/DQ3NzfNpLm5WXzokmhtbW1ra+vo6Ojr65NKpWq12mg02mw2t9uNAAsgqqCTWnoIsJjAgk3UdcoVr2/cId4Ki4MAixF0ZtShpCygqiygqnShnixcunvvg5NnnE6nxWIxGo1arValUikUCrlcLgtL0gCJANkiPm4JyeVyhUKhUqm0Wq3RaLRYLEm3ijacy8L8QQhn+I1KHUq69BBgMYEAizoEWCxgDSxG0JlRh5ICANDi8/m8Xq/H43E6nTabzWw2m0wmg8Gg1+t1MD96vd5gMJhMJrPZbLPZnE7nidslG84jwIKwhtEUdSjp0kOAxQQCLOoQYEEEwXx46jA+AACgiM+w3G630+l0OBz2ABvMDymXw+FwOp1ut9vj8ZwsLN2YcVlcaFio5KLyjRnZ4q2wOBhNUYcx/9JDgMUEAizqEGABRDMMuQAAqCMxFkmyFm9goqFkILk4ylrJQHLJYErJYMqeopj1uZ+UDqWGYSsbSh3WNYn/84c3BFgsYDQFzwEEWADRq3FIUtHeJd4KANHhm6s+wf9sSB2qShfqyUJwNOBbHBKBlQymrCtehhaerXQwJbKmNwZ/SgEAEGABRDUMDhg5nF9kd7nEWwHCDKIBFlBVulBPFuj2/l8GWAPJwbkJWpi0koFkj8fj9XojJcai+ykFYARj/qWHAAsgemFwwAj+4oKIgA8qC6gqXagnCxR7f+F68IV9J4JzE7QwaYV9J5xOZ2RlWADhD53U0kOAxQQWbKIOJWWB4hAWhNCZUYeSsoCqsoCq0oV6skCx9/f5fCS9slgst7qPBecmaGHSbnUfs1gsJMNCgBW18BuVOpR06SHAYgJpC3UoKQtYA4sRdGbUoaQAAGHI6/W63W6bzWY0Gq+3HwrOTdDCpF1vP2Q0Gm02m9vt9nq94v+QEB0wmqIOJV16CLCYQNpCHUoKEQTz4anD+AAAIAx5vV6n02k2m7Va7dXm+ODcBC1M2tXmeK1WazabnU5nRARYFJ8TBB5GU9RhzL/0EGAxgbSFOpQUIJphyAUAEG7I/EGHw2EymVQqVXbD3uDcBC1MWnbDXpVKZTKZHA5HRMwiRIDFAkZT8BxAgAUQvTCFECCaYSDLAqpKF+rJAq1ogARYdrvdYDAoFIpL9buDc5MwbNvv/LBJdatkaCHfmbip9LVL7bGpD98XbT/f8keJvulaz77gU+bfKiVnG0avx1V8L3jX4tul+t0KhcJgMNjtdgRYABC5EGABRC8MDhjB48QQERANsICq0oV6skCr9+cDLL1eL5fLL97fFZybPGu72rVTbxvjW+d45cmGd4MPW0w7XLec4zjVVH/wrqe2U40fcBxncRqFG7dWfH/aqZ+0KrZWfD/4lPk3vW2M47i91W8E71p8u3h/l1wu1+v1CLAAKMKYf+khwAKIXhgcMIK/uCAi4IPKAqpKF+rJAq3enwRYNptNp9PJZLKLdTuDc5NnbbXyLI7jjHaNRN+ksyr9d+G8x+p/G3zkgttiAqzdVT/pHK8sGUwRbszp3DYwWX+g5ufBxz9TYxtg1e2UyWQ6nc5ms0VEgAUQEdBJLT0EWExgwSbqanv639gZL94Ki0NrCAsi6MyoQ0lZQFVZQFXpQj1ZoNX7swuwauVZ64qXbSh9VWHyL3RQLbvIH7C98kfnWj7LaP1iz92f8hs3lL6a1rg2p3Pb8QfvCK+2pfz11IfvZ3VsPnr/zfUl3yYbhQHWptLXUh6uSaz9Jdm1teL7KQ/XCK+8vfJH6c2/v9i2cfudH64rXra+5NsnG95NqP3F3LfYUPpqysM1u6t+sqn0tVONH5xv+Xy2iYGby797pvmTcy2fbSp9TRRgxZS8cvT+m9kdcScevLOh9NXgc5+pIcAC/EZlASVdegiwmECARR0CLBawBhYj6MyoQ0kBAMIN6wBrXfGy1rFiYYB1sX2jw/OoL/D6PAX9h8maVpNWBf+q8rr3kIMzWr+wukz89lFTz66qH4sCrJSHaziOk+ibyCk5nds4jmtS3eJ/dHns5HSXx77n7k9FT2/NfYsWVeH49DDZZbRrdlf9RPRm91X/M//KtRaZzWXmA6y4iu8N6hr4K4+bh4NPf6aGAAswmmIBJV16CLCYQIBFHQIsiCCYD08dxgcAAOGGXYA1MFmf07mtYvi0x+tyex1H779Jpu85PFajXXPw3q8O1PxcZ1V6fZ79NT8rGjjOcVyl5OzWiu+fbvqYzDfcVfVjh8fq8bpu9MafbfpEZmgjidL8A6y9d9/weF0eryu/NzGzbb1U37Kv+p+F5z71FhzHKaf6bvUdNNjUHMeVPjnxcF3xsjZ1CcdxI8bOaz37Rk095BQSYNXKL3EcVzF8evudHxYP+t9go/JRrLawFnEB1v7c/P25+eKtsDgYTVGHMf/SQ4DFBAIs6hBgAUQzDLkAAMINuwCLZ3ZMJtW/TXbd6NnPcVy9Indv9Rt7q99oGL3Ocdzljs0kwBoxdp588OVy77f6DvrjpDF/nLSueNnBe7/iOM7mMs8/wLrZ6x928lcgTXjuU29htGs2l393XfGy/N5EjuPa1CWiN0se74oPTEjcXP5di9PIB1gWp4HjuITaX+ytfoNcedKqEJ3+TA0BFmA0Bc8HBFgA0au2p7+2p1+8FQCiwwvLV4k3waKhqnShnizQigbYBVgd4xUXWmPIIu7lw2lk113ZBfEr4LirXTu3Vf6Af3xJOdW3v/pn64qX3Vdc4TiubCiVnLux9DVywJby1+cZYNWN5AivQJrw3Hnegr9st6ZKeKkt5a+T4/kt/BpYm8u/++jtCRjtGuHpz9oQYAHA8wEBFkD0wuCAEVQVIgKiARZQVbpQTxZo9f7sAiyyBtbJB+9yHOfxusjCUmVDqRzH3Ru5TJ7AIo2smx5T8kpG6xcjxk6O4/om7q0rXlYpOes/WH6ZXHZv9Rscxzk9VlEIdbz+bY7jxsyD5LCrXTv5AOuO5BzHcTWPV+MiTXjuPG8xW4C1ofRVUsYt5a+TLWSmIXlTXp/Hx3n31/yMf6fbKn8QXK75NwRYACzgU7r0EGABRC8MDhjBX1wQEfBBZQFVpQv1ZIFW7886wFpXvEw15X9OnDzldL7lc47jNNOSrRXfJ3uP3F+5vuTbR++/SbYIY6OM1i84jptyTJC1z8njVCRCEh62964/dfJ4XSkP16Q+fN/smOQDrEvtmziOm3bqE2t/ua3yB+XDafG1v1jALWYLsNYVLxs3+5d4r5Sc3Vz+XRKH8VMIyRvnF6TfWvH9/TX+J8sW3CIuwAKICOiklh4CLCawYBN1KCkLtIawIILOjDqUlAVUlQVUlS7UkwVavf8SBFjXevaRlbDWl3w7puSVIV0j+UJAvW2MfGffrqof1yty3V6Hwtg17dRzHHe7/yh5JmtY30ReJ1lqyuyYPFDz8+B0iTy3RWgtMj7Aiil5RWHs/vLdctyx+t8Kz53/LWYLsC53bOYv7vY6yDcSkgArrXGtx+tfGXrKPkGmFj4YvRZcrvk3BFiA36gsoKRLDwEWE0hbqENJWcAaWIygM6MOJQUACDcsAqxTjR+UDaWmPFxDftxc/t3SoeSyoVQyz259ybevdG5/MHqtb+Je3UhORusX5CmqSsnZXm1Nk+rWhbYY/lLrS76d172nYfR6u7rsdv9R/rmtbZU/KBtKze3ezf94R3KuTV2S170nruJ7ZUOp51o+I7s2lL6a35v4UHmzXpFLNorOnectEmt/WTaUeqH1y9fGtwutMc2qglr5pUP3fn2m+RP+na4rXnag5l+qpOc7NZVt6pKigePkOa8FNwRYgNEUCyjp0kOAxQTSFupQUoggVP6XbRDC+AAAINywCLDQGLWIC7BoPScIQhhNUYdP6dJDgMUE0hbqUFKAaIYhFwBAuEGAFUENARZgNAXPBwRYANELUwgBohkGsiygqnShnizQigYQYEVQQ4AFAM8HBFgA0QuDA0ZQVYgIiAZYQFXpQj1ZoNX7I8CKoIYAC4AFfEqXHgIsgOiFwQEj+IsLIgI+qCygqnShnizQ6v0RYEVQi7gACyAioJNaegiwmLjd1Lry4HHxVlgElJQFWkNYEEFnRh1KygKqygKqShfqyQKt3h8BVgQ1BFiA36gsoKRLDwEWE0hbqENJWcAaWIygM6MOJQUACDcIsCKoIcACjKZYQEmXHgIsJpC2UIeSQgSh8r9sgxDGBwAA4QYBVgS1iAuwNmZkJxeVi7fC4mA0RR3G/EsPARYTSFuoQ0kBohmGXAAA4WYpA6yK4dNNqlu7qn4cvCvkbWvF9zPb1h+9/2bwrvBpCLAAoyl4PiDAAoheFe1djUMS8VYAiAImi/Wbqz4Rb4XFQVXpQj0ZoRUNLGWApbeNcRx3uG558K6Qt7zuPRzHyQ3twbvCpyHAAoDnAwIsgOiFwQELdpfrcH6ReCtAmEE0wAKqShfqyQit3h8BFmmH7v26R1t9pXNH8K7waQiwAKjDmD8kEGABRC8MDljAX1wQEfBBZQFVpQv1ZIRW788iwFpf8u0j91deao893fTxlvLX+e18gJVU/9al9tj9NT8TnnXw3q+yOjafb/l8c/l3+Y17775xoTXmXMtn2yt/xG88XLf8yP2VG0pfvdAak1T/1v6an6U8XBNX8T2yd0PpqykP1yTW/nJd8bLYsu+kNa7N6dx2tukT/gD+sOP1b+d0bjtSt5IcmfJwzd7qN576Lsjd1xUvS6z95aX2TQm1vxBdNrlhVXZH3NH7b8aUvMJvn/HdPWuLuAALIPyhkwoJBFhMYMEm6rKq69ampIu3wuLQGsKCEDoz6lBSFlBVFlBVulBPRmj1/tQDrN1VPxkxdvLXt7pMF9piyC4SYEn1LY9uzXmv9ewju+6PXOFP4efx3e4/6vV5yEaXx57Ztp6/jsGm7tXWcBwn0TfVjeRwHFcjzyJ7L7Zt5DiuS1N1rP63NpeZv6zNZT5W/1tyTHztL8bNw/yuG73x2R1xHMd1a6rm8y6Mdg25KcdxXp/nYvtGsmvv3TfGzIP8WRJ9E4mrZnx3C2gIsAC/UalDSUMCARYTCLCoQ4DFAtbAYgGdGXUoKQBAGKIeYPVN3OM4rk1dcqrxgzuScyQ52lb5Az7AsrpM+b2JDaPXOY5zeKxbK76/9+4bHMepzYNbK75/qO7X2R1x64qXJdW/xXGccqpvz92fJtW/7fBYLU4DeRKKXMfr81TLLhb0H05rXMtxnM6qJC+gTV3CcVxu1+60xrVt6pL05t8fvPcrEiG1q8vIMcP6Jo7jWseKz7V8dl9xpWjgeE7nNmGA9dR34fBYS4aSuzRVHMdNWhXkrP6JOo7jrnbt3F75o4fKmxzHFQ0cn/HdLawhwAKMpqhDSUMCARYTCLCoQ4AFkQLz4anD+AAAIAzRDbB23vkf5GkpfqKcaqqf47j05t/z0c/ppo/JLr1NxXHcmaZPdlf9T3/P656+0rk9tuw7ZO89+WV/ADR4fG/1G3ur3xicbOA47uSDd/nr3Og5QI5cX/Jti9PAcdyhe7/eUPqqzWX2+jwkbOJbevPvySNR64qXbav8AXmR/L3WFS8TBljzeRfnWz4n311IHiXj/z3t1JMXTO44ONkw47tbWIu4AIvWc4LAw2iKOoz5QwIBFhMIsKhDgAUQtTDkAgAIQ3QDrOP1b3Mcp5mW8Fu6A88o5XbvCl7EnTzllNO5bV3xskrJWR/n5TjO4jRkd/qfUSJ7RU41fhB8nXXFyx6MXuM4rnjw5KnGDziOG5isX1e8bFPpa/fkl+3uaf50EmAdq/+t6EWKAqxnehfkyvxlRWSG1hnf3cIaAizAaAqeDwiwAKIXphACRC0MZFlAVelCPRmhFQ3QDbAO1PycPIXEbyGT9c61/IGPfsgK6OuKlymn+oQPZB2896t6Ra6P83q8rm2VP2gZK+Q4rqD/MHmgiTRyZHCARWYRjpp6yNJUuV271xUvq5Zd5Diuc7zyVOMHZ5v9H0ISYCXU/kL0IkUB1nzeRXCAtb/mZxzHGe0a4QvmV44XvTvhreffEGABwPMBARZA9MLggAU8TgwRAdEAC6gqXagnI7R6f7oB1obSV8lsPn4dK6/PQxa64qMfmaFtX/U/X2iNIWnOjjv/Y1vlD/g8SDPt/9/kDtT8PL8vkeO4Id3DTaWv8d8JSI4JDrDILEIf57U4Dfz8wYHJen6u39WunXyAtan0NfJYVl733tiy75xr+Sy3e7cwwJrPuwgOsPiZjGmNa8mu3VU/2VX14xnfXXDp5tMQYAFQhzF/SCDAAoheGBywgL+4ICLgg8oCqkoX6skIrd6fboBFoiIyXc7lsZP1ofL7EskuvW3M5jKbHZP83etGctYVL0tuWM1x3IRlRB34Cj/lVF9MySuxZd8hcY/dPa23jTk8VpvbzF9HFGDxswj5+YPkSwzJauujph6nx+r2OkiAta542Y2eA1+WgOPuyi6IFnGf+13MGGCtK152pWs7OctgUxvtGo7j8vsSZ3x3wXWbT4u4AAsg/KGTCgkEWExgwSbqUFIWaA1hQQidGXUoKQuoKguoKl2oJyO0en/qAda64mUnG96tll3sGK+4K7uQVP8Wv/1az76bvfF77v70nvxyx3jF1a6dJMpZX/Lt6z0H2tQlHeMVxYMn+Wl3sWXfudkb36y63aOtrpVfSn34Pn+dsqHU7Xd+KLxpfO0vyoZSy4ZSk+rfJltiSl651rOvY7zinvzywXv/+2ZvvPAbANObf39PfrlJdaug//CW8tcTa39ZNpSa2bZ+Pu9CePfiwZOlQ8n83qT6t6plF3u1Nc2qgvzexK0V35/t3S2gIcAC/EalDiUNCQRYTCBtoQ4lZQFrYLGAzow6lBQAIAyxCLDQGDUEWIDRFHUoaUggwGICaQt1KClECsyHpw7jAwCAMIQAK4JaxAVYa1PSs6rrxFthETCaog5j/pBAgMUE0hbqUFKAqIUhFwBAGEKAFUENARZgNAXPBwRYANHrdmNrp1wh3goAUWBkYvJbn24Qb4XFQVXpQj0ZoRUNIMCKoIYACwCeDwiwAKIXBgcsmCxWKovjAjCFaIAFVJUu1JMRWr0/AqwIagiwAKjDmD8kEGABRC8MDljAX1wQEfBBZQFVpQv1ZIRW748AK4JaxAVYAOEPnVRIIMBiAgs2UZdcVL4xI1u8FRaH1hAWhNCZUYeSsoCqsoCq0oV6MkKr90eAFUENARbgNyp1KGlIIMBiAgEWdQiwWMAaWCygM6MOJQUACEOiAKv0Yfapsg1JBZ8duv5xQt7a+KsfzLMd4NuV9w9ceX//40Z+5Bu/PXjv3BuDL/XlHQX3FbU5bjfjxd9M+OmnKb8KPiD4ynO04MvOcJ3Aaw4uY3BLyFt76PrHSQWfnSrbUPowGwFWlMNoijqUNCQQYDGBAIs6BFgQKTAfnjqMDwAAwhAJsOx2u16vl8vlbW1tVVVV+fn5OTk5mZmZGRkZ5+ft3GPpT5ptOzHjrhk3Ci81T3OcLtpF9v7o7dUfbNw84wHCc+cgOisYf6S4fDPJyMjIzMzMycnJz8+vqqpqa2uTy+V6vd5ut0dEgEXrOUHgYTRFHcb8IYEAiwkEWNQhwAKIWhhyAQCEIT7AMhgMCoWio6OjpqamsLAwLy8vOzs7Kyvr0oJcfEy8Y/Zdc2yccdc8zX26aNc/vvv+x3HbRXtnO3c2/FnBxIc+TVZWVnZ2dl5eXmFhYU1NTUdHh0KhMBgMCLCiFkZT8HxAgAUQvTCFECBqYSDLAqpKF+rJCK1ogARYDofDZDKpVKq+vr6GhobKysrCwsL8/PwbN25ch9C5ceNGfn5+YWFhZWVlQ0NDX1+fSqUymUwOhwMBFgBELgRYANELgwMW8DgxRAREAyygqnShnoxQ7P29Xq/T6TSbzVqtViqVdnZ2NjQ01NTUVFVVVUKoVVVV1dTUNDQ0dHZ2SqVSrVZrNpudTqfX6xX/hww/FD+lAIxgzB8SCLAAohcGByzgLy6ICPigsoCq0oV6MkKx9/d6vW6322azGY1GtVotlUr7+vo6Ojra2tpaW1tbIHRaW1vb2to6Ojr6+vqkUqlarTYajTabze12R0SABRD+0EmFBAIsJrBgE3UoKQsUh7DAQ2dGHUrKAqrKAqpKF+rJCMXen8widDqdFovFaDRqtVqVSqVQKORyuSzK/GZ3/NGcPPHWkJLL5QqFQqVSabVao9FosVicTmdEzB8EFvAblTqUNCQQYDGBtIU6lJQFrIHFAjoz6lBSAIDw5PP5vF4vybBsNpvZbDaZTAaDQa/X66LMuweT0m4Vi7eGlF6vNxgMJpPJbDbbbDaSXnm9XgRY0QmjKepQ0pBAgMUE0hbqUFKIFJgPTx3GBwAAYYvPsNxut9PpdDgc9gBblHnvWOr5sjvirSFF/kM4HA6n0+l2uyMrvaL4nCAQGE1RhzF/SCDAYgJpC3UoKUDUwpALACDMkRiLJFnR6YOTZzLv1Ii3hgfynyZSoisCARZ1GE3B8wEBFkD0whRCgKiFgSwLqCpdqCcjTKMBH4Qf8X+kSMD0UwoAkQsBFkD0wuCABTxODBEB0QALqCpdqCcj6P0h/OFTCuEPY/6QQIAFEL0wOGABf3FBRMAHlQVUlS7UkxH0/gAAi4dOKiQQYDGxPzd/f26+eCssAkrKAoawLKAzow4lZQFVZQFVpQv1ZAS9PwsrDx6/3dQq3goQNvAblTqUNCQQYDGBtIU6lJQFrIHFAjoz6lBSAAAIcwiwIMxhNEUdShoSCLCYQNpCHUoKkQLz4anD+AAAAMLcyoPHt1zIOXTtNtriW33vAAJB6jCaog5j/pBAgMUE0hbqUFKAqIUhFwAAhLmVB4//cNPuV979+I0P/4C2mPbKux8funYbARZ1GE3B8wEBFkD0yrv/cFClFm8FgCjQKVe8vnGHeCssDqpKF+rJCKIBRg5du/3Gh3+IjYlBW0x748M/IMACgNkgwAKIXhgcsKAxmtLL74q3AoQZRAMsoKp0oZ6MoPdnBAEWlYYACyIFxvwhgQALIHphcMAC/uKCiIAPKguoKl2oJyPo/RlBgEWlkQBLXFyA8INOKiQQYDGBBZuo25iRjUXyqMMQlgV0ZtShpCygqiygqnShnoyg92eBrIGFAGvxDQEWI/iNSh1KGhIIsJhAgEUdAiwWsAYWC+jMqENJAQAgzC0gwNq9bVvCvn0J+/bF790bvDcM25YNG7IvXdqzfbtoe96VK2azeWdcXPApC2gIsBjBaIo6lDQkEGAxgQCLOgRYECkwH546jA8AACDMLSDAmtBq+dOnpqZysrKCjwmrlrBvH8dxuTk5wo37du6cnp4+dfJk8PELa1gDixGMpqjDmD8kEGAxgQCLOgRYAFELQy4AAAhzCwiwDHp9ZVlZbEzMnu3bHz544PP5jiYmBh8WVu3Anj2b168XbklOSrqQnh585IIbAixGMJqC5wMCLIDohSmEAFELA1kWUFW6UE9GEA0w8qyLuPMBVmxMzM64OJ/PV1RQEBsTc/LYsdQTJxL27SsrKTl/5gw5YNvmzVmZmRWlpZcyMuI2biQbyZE74+Lyr18vKig4cfSo8PqnU1PLSkpKiopOp6byG4MvvnfHjht5eZVlZTfy8nZv2ya8Qsrx48WFhUUFBQf27CFTCK9mZ+/dsYM/IOnw4Vs3bpQUFQkzLHKLXVu35ubkFN66dSQhQXjNpzYEWAAwBwRYANELgwMW8DgxRAREAyygqnShnoyg92dkMQHWts2bvV5vwc2bsTExdbW1kuFhs9ksl8nq6+rIc08TWq1MKq2trtaMj48qFCTDqqutlctkusnJvt5euUzm9XovXbhALvigrk6v0z24f7+9tdXj8ZQWF5PtoovH791rt9n6envv37unGR83m818hnWnvNztdnd1dg729zvs9t3btu3aupXjuDOP47DCW7fcbndvT09XZ6fdZuvv6yMPZ9XV1sqkUq1GI5VIVEql0+F4pifLEGBBpMCYPyQQYAFELwwOWMBfXBAR8EFlAVWlC/VkBL0/IwsOsDavX19z967b7T4cH08CII7jrl29yh/5sKFhaGCAxEM7tmyxWCxkb11trdfrvXzxIjmst6dnXK0m/07cv3/Lhg3k33crKye0WvJv0cXjNm5M2LeP/HtnXJzb7c6+dCk2JuZoYqLP58s8f57sSk5K2hobKwyw4vfu9Xg8/HWOHjzo8/nIKyGvKiszkzy0pZucrKutDX77szUs4g6RAp1USCDAYgILNlGHkrKAISwL6MyoQ0lZQFVZQFXpQj0ZQe/Pwhs743+x++CzBlh2m82g11sslunpaZL4kABoVKEQHmk0GO7fu3cmNZU05ehow4MH5EipRMIfln3pEsdxW2Nj+S17tm9POny4vq7ObrPNdnESMyXs25eWkuJ0OG7n58fGxFzPzXXY7aLlroQBVvABI3J5Y0ND8KvqaGvr7uoS3XGOhgCLEfxGpQ4lDQkEWEwgbaEOJWUBa2CxgM6MOpQUAADC3MICrJampjOpqcePHNm2eTO/XRQAxcbEeL3eCa1WKpHwjX8CS3jk2VOn/N8ltXt3bEzMiaNHVUqlxWIhcwyFAZbwFPLwl81m04yPSyUSr9dLAqyK0lKDXi96wcIAq7KsTK/TCff2BeYSBt+ipampt7tbdKk5GgIsRjCaog4lDQkEWEwgbaEOJYVIgfnw1GF8AAAAYW5hARa/BpawBQdYRoOB5ErBR8qkUv7H3Jwcr9dLZg7qJicf1teTJ6Ru5+fPFmBduXzZ5XIdPHCA/Gi32ciNbl67NvcTWDfy8hx2Oz9LMTYmZkylqq2uDr7FwgKsN3bG1/b0i6sMi4DRFHUY84cEAiwmkLZQh5ICRC0MuQAAIMwxDbCaGxuVo6M74+LIj9s2byZPbNXV1vp8PvI0VtzGjYqRkcH+fnKMy+UiC7dv2bChq6NjtgCruLDQYbeTWYfJSUkej4cEWEcSEnw+3428PHLYlcuX9+7YIQywjiQkeDyeWzdukAMyz53z+Xwpx48H3wIBVpjAaAqeDwiwAKLXpeq6kYlJ8VYAiAK1Pf1v7IwXb4XFQVXpQj0ZQTTAyIIXcRe14ADrwJ49mvHx6enpvp6eoYEBh92efvo0OVI3OambnJzQag16vdlsPnbwIDmlvq7O5XL1dHdPTkxIJZLZAqyDBw7YbTatRtPb0zM5MaHX6fhHve5WVvp8PpVSqdfpzGazKMCKjYkpKijweDwqpVI5Oup2u4sLC2e8BQIsAKAIARZA9MLggIWRiclL1XXirQBhBtEAC6gqXagnI+j9GXnWACvj7NnE/fuDtx9OSEhLSRFtjNu48dzp03k5OdmXLvEz/khUtG3z5uxLl7IyM/ds3y48JS0lJS8n5/iRIzvj4i4+/j7B4Ivv2b49JyvrUkbGzri4tORk/ksJyUJaeTk5WZmZ5IGvzevXZ2Vm7tq6lT8gcf/+yxcvZmVmCs8S3eLE0aPkyax5NgRYECkw5g8JBFgA0QuDAxbwFxdEBHxQWUBV6UI9GUHvz8izBliLb8HPaj0HDYu4Q6RAJxUSCLCYwIJN1K1NSc9Cwk0bhrAsoDOjDiVlAVVlAVWlC/VkBL0/CwtYA2vxDQEWzB9+o1KHkoYEAiwmEGBRhwCLBayBxQI6M+pQUgAACHMhCbD27thxKD4+eHtENwRYjGA0RR1KGhIIsJhAgEUdAiyIFJgPTx3GBwAAEOZCEmA9lw1rYDGC0RR1GPOHBAIsJhBgUYcACyBqYcgFAABhDgEWrYYAixGMpuD5gAALIHphCiFA1MJAlgVUlS7UkxFEA4ws/SLuz2VDgAUAc0CABRC9MDhgAY8TQ0RANMACqkoX6skIen9GEGBRaQiwIFJgzB8SCLAAohcGByzgLy6ICPigsoCq0oV6MoLenxEEWFQaFnGHSIFOKiQQYDGBBZuoQ0lZwBCWBXRm1KGkLKCqLKCqdKGejKD3Z+H1jTt+dyh5aQKsPdu3p6WkJCclxW3cGLx37paclLRt82bhlh1btmRfuiTaGMKGAIsR/EalDiUNCQRYTCBtoQ4lZQFrYLGAzow6lBQAAMLc0gRY506f1ut0HMfZbDaO4+w2W3FhYfBhs7VdW7dyHJeXkyO6JsdxqSdOBB8fkoYAixGMpqhDSUMCARYTSFuoQ0khUmA+PHUYHwAAQJhbggAr+9IljuPq6+oO7NkTGxOzZcOGC+npbS0twUfO1mYMsDavX08uGCaNBFivb9zRKVeIqwyLgNEUdRjzhwQCLCaQtlCHkgJELQy5AAAgzLEOsHZt3Wo2mxvq64N38W1nXNzlixcrSkuv5+bu27kz+IAZA6xdW7fm5eRs27x5x5YteTk5whOTk5LOnzlD/r1727a8nJzS4uKMs2c3r18ffHFaDQEWIxhNwfMBARZA9Eovv6sxmsRbASAK3G5qXXnwuHgrLA6qShfqyQiiAUaYLuJ+6cIF/y3i44N3kZa4f79ucnJCq21palKr1VarNXhW4IwB1vEjRziOS9i3b8uGDRaL5U55Ob9rbGzswf37sTExSYcOmc3m3p6eezU1RoOhu6sr+AXQagiwAGAOCLAAohcGBywMqtR59x+KtwKEGUQDLKCqdKGejKD3Z4RpgFVRWupyuci/d23dWlFaWllWVllWlpWZSTZ2tLWNKhRbY2PJ7ML+vr4RuVx0kbkDrNiYmPq6usmJCbL9ULz/aR2Sgg0NDDxsaCDb4/fu9Xq9Z06dCn6RVBoCLIgUGPOHBAIsgOiFwQEL+IsLIgI+qCygqnShnoyg92eEaYBVXVXlsNvJv/fv3i2VSKQSiclkMuj1ZKPT6byem8sff/niRY7jRN8t+NQAK+W4///jTh47FhsTU1pcrJucjI2Jidu40ev1lhQVnUlNJc1kNBbdvh38Iqk0LOIOkQKdVEggwGICCzZRt/Lg8dtNreKtsDgYwrKAzow6lJQFVJUFVJUu1JMR9P4ssF4D69qVKxzH7d+9W7ixrraWBFgkmco8d47fdSY1leM40ersTw2wYmNidJOTNXfvkvmDlWVl5JErjuPUKhVJzUjj18ai3hBgMYLfqNShpCGBAIsJBFjUIcBiAWtgsYDOjDqUFAAAwhzrAOvQgQMej6e2ulq4kQ+wYmNiXC7Xjbw8fteVy5c9Ho9otfX5BFh3ystNJtPhhASO4w4eOBAbE7M1NlaUjjFtCLAYwWiKOpQ0JBBgMYEAizoEWBApMB+eOowPAAAgzLEOsGJjYmru3vV6vaXFxXws1drczAdYvT09Y2NjO7ZsiY2J2bFli0qlam9tFV1hPgEWWfpq4MkltGRSaX9vb9zGjeTHnXFx/L+pN6yBxQhGU9RhzB8SCLCYQIBFHQIsgKiFIRcAAIS5JQiwtmzYUFpc7PF43G73+Pi4xWLhOK65sZHsPXjggG5y0mw2SyUSi8UyqlDs27lTdIUdW7b4fD6LxWLQ60nLPHdOFGDFxsQoRkY4jrt57Rq/JenQIaPBoNfpujo7ZVKp0+k8FHg4i0VDgMUIRlPwfECABRC9MIUQIGphIMsCqkoX6skIogFGmC7izrc927efTUvLy8nJysyM37tXuGtrbGz66dN5OTmpJ05s2bAh+NzYmJiTx47xa7GfSU3dvW3bji1bLl+8SL6+kLRD8fGXL14ULQC/My4u4+xZcl/R0lp0GwIsAJgDAiyA6IXBAQt4nBgiAqIBFlBVulBPRtD7M7I0AdZz3xBgQaTAmD8kEGABRC8MDljAX1wQEfBBZQFVpQv1ZAS9PyMIsKg0LOIOkQKdVEggwGICCzZRh5KygCEsC+jMqENJWUBVWUBV6UI9GUHvz8K3Pt3wh9QMBFiLbwiwGMFvVOpQ0pBAgMUE0hbqUFIWsAYWC+jMqENJAQAgzCHAotUQYDGC0RR1KGlIIMBiAmkLdSgpRArMh6cO4wMAAAhzJMD68zc/RFt8O3Tt9rc+3TAyMSmuMiwCRlPUYcwfEgiwmEDaQh1KChC1MOQCAIAwh8CFLtSTOoym4PmAAAsgeiUXlZssVvFWAIgCWdV1a1PSxVthcVBVulBPRhANQPjDpxQAZoQACyB6YXDAQqdccbsRTwtCuEM0wAKqShfqyQh6fwh/+JRC+MOYPyQQYAFELwwOWMBfXBAR8EFlAVWlC/VkBL0/AMDioZMKCQRYTLyxM762p1+8FRYBJWUBQ1gW0JlRh5KygKqygKrShXoygt6fBVQVwhx+o1KHkoYEAiwmkLZQh5KygDWwWEBnRh1KCgAAYQ4BFoQ5jKaoQ0lDAgEWE0hbqENJIVJgPjx1GB8AAECYQ4BFF+pJHUZT1GHMHxIIsJhA2kIdSgoQtTDkAgCAMIfAhS7UkzqMpuD5gAALIHphCiFA1MJAlgVUlS7UkxFEAxD+8CkFgBkhwAKIXhgcsIDHiSEiIBpgAVWlC/VkBL0/hD98SiH8YcwfEgiwAKIXBgcs4C8uiAj4oLKAqtKFejKC3h8AYPHQSYUEAiwmsGATda9v3NEpV4i3wuJgCMsCOjPqUFIWUFUWUFW6UE9G0Puz8M1Vn2BZBghn+I1KHUoaEgiwmECARR0CLBawBhYL6MyoQ0kBACDMIcCCMIfRFHUoaUggwGICARZ1CLAgUmA+PHUYHwAAQJhDgEUX6kkdRlPUYcwfEgiwmECARR0CLICohSEXAACEOQQudKGe1GE0Bc8HBFgA0etwfpHd5RJvBYAokFxUvjEjW7wVFgdVpQv1ZATRAIQ/fEoBYEYIsACiFwYHLDQOSSrau8RbAcIMogEWUFW6UE9G0PtD+MOnFMIfxvwhgQALIHphcMAC/uKCiIAPKguoKl2oJyPo/QEAFg+dVEggwGICCzZRh5KygCEsC+jMqENJWUBVWUBV6UI9GUHvzwKqCmEOv1GpQ0lDAgEWE0hbqENJWcAaWCygM6MOJQUAgDCHAAvCHEZT1KGkIYEAiwmkLdShpBApMB+eOowPAAAgzCHAogv1pA6jKeow5g8JBFhMIG2hDiUFiFoYcgEAQJhD4EIX6kkdRlPwfECABRC9MIUQIGphIMsCqkoX6skIogEIf9Q/pZ1yhc5sFm8FgEiDAAsgelEfHAAeJ4ZIgWiABVSVLtSTEfT+EP7ofkpz6xr+7Hcf1fcNincALALG/CGBAAsgetEdHACBv7ggIuCDygKqShfqyQh6fwh/GqOpcVCSe//hycKyw/lF8dduxV+7dbKw7OLdexXtXSMTk+ITZuH2ePfl5X/tt++/uGL1+cpq8W6ARUAnFRIIsJjAgk3UfevTDfPvq2CeMIRlAZ0ZdSgpC6gqC6gqXagnI+j9WXhh+SrxJngWbo+3U65IvH57eULSN1d98uKK1S+vXPPC8lXB7aXArq/95v2/37RzY8bloub22T7P03bHO0dTX1yxmpy49+pN8RHRBL9RqUNJQwIBFhMIsKhDgMUC1sBiAZ0ZdSgpAACEOQRYCyYZ1+zMufbXa7/4ypvvBcdVT20kz3r7SEpRc5vb4+Uvq9Lpfxi3R5iCvXss9YkbRxmMpqhDSUMCARYTCLCoQ4AFkQLz4anD+AAAAMIcAqwFqOnu+/neQ1/9zUJyq+D28ptrVh9PI1duHJL81Yd/FB3wj1v3iV9BNMFoijqM+UMCARYTCLCoQ4AFELUw5AIAgDCHAOuZDKjU/2t34kuzTBJ8Yfmq/2P5qq+/89F31m978+CJj1LTPz517r0Tp39z6ORPd8R/c9UnLyxf9dUnH9d6ccWqNcfTyBNY2bX3/8+3Pwy+5gvLV/3lB5//aMue5QlJH6ee2345L6mgJHr+ZMNoCp4PCLAAotf+3HzxJgCIDvtz8/EbgDpUlS7UkxFELRBCbo83taTi6++sDU6XXlq55hvvfvK7Y6nHb5e+sHyVcD6giM5sru8f3JyZ84PNu/klrvbl+pe4uvWwebbFs0TtxRWr3zx0Yrb1swAgPCHAAoheGMKyUNvTX9vTL94KEGYQDbCAqtKFejKC3h9CRaXT/yr+KB858e3lN9f8Yt/hwqZWPrSa/6dUpdNvzbr6nz74/JNT5zmOq+rsCb5+cPvKm+/tvXpzjowM4Kkw5g8JBFgA0Wv+gwOYP/zFBREBH1QWUFW6UE9G0PtDSDQPy/7j+58FRVfvfZqW0S4bER/9jOwuV+OghOM4jdEUHFeJ2l+8+/HVugbxJQCeETqpkECAxQQWbKIOJWUBQ1gW0JlRh5KygKqygKrShXoygt6fBVR1bkXNbaJ1qV5csfqVzzdXd/eJDxVwe7w683SPQlnfN1jfN9ijUD51xl+HTDH3E1j/9ycxDwaGxKdFAfxGpQ4lDQkEWEwgbaEOJWUBv3NZQGdGHUoKAABhDgHWHBoGhv/0rQ+EKdJX3nzv87OZ03aH+NDAs1TFze0bL2R/d/22l1aueXHF6q+8+R5pXwt8X+FffvD5r+OPpRRXjGjFfxrkP2z+92t+Hxxa8Tf9fuwujdEkOitKYDRFHUoaEgiwmEDaQh1KCpEC8+Gpw/gAAADCHAKs2Qyo1P/hyZmDX/3N++crq8XHBZZm333l+l+t/eM8V2F/aeXqf9oZrzObybNa+/Py/+S3T8RkwvbiitWrkk7ZXS7xXaMGRlPUYcwfEgiwmEDaQh1KChC1MOQCAIAwhwBrRnaX6zsxW4VB0ozpldvjTbhe8G/eXvvSnLP/RO3Pf/dRbmApq2m7492kU6KZg19/Z+2R/KLU4ordOdc/Tj2XXFQmumm0wWgKng8IsACiF7oxgKiFgSwLqCpdqCcjiFpgyWzOzBHmSi+/+V5wetWvHPvHrXtnXLjqK2/65wz+m3fW/uUHn//b1Z/yW15Yvuq/fRbbrxwj30L4w7g9ooe2/uajLx70ixe6MlmsWy5dieaHsACeAwiwAKIXhrAs4HFiiAiIBlhAVelCPRlB7w9LY0ClfvnNL3Oll1au3nLxiuiYur6BP3/3Y1Fu9VIgjdpz9UZd34BonawR7eTlmvuxmTlk5mDjkORvPl4nPPflN9/7+007lTo9OV5jNK1IPP7ZmQv7c/P/+/ptL69cczi/SHhBgAXDmD8kEGABRC8MYVnAX1wQEfBBZQFVpQv1ZAS9PyyNt44kC6Olv/3jFrfHKzzAn1797qMno6vV/7wrobq7V3TkjK7WNXz9nbXC019csfqtI8miZ6z25ea/sOLLY77+zkck/AJYJHRSIYEAi4lvrvrkqV/yCs8EJWUBQ1gW0JlRh5KygKqygKrShXoygt6fOpPF+s1Vn4i3RjfJuEb4+NWLK1bXdPcJD1Dp9GRWIN/+9K0PD+cXzSe6cnu8O7Kv8dMJSfvab95PuF4QfLrb4/3WJ+uFR+67elN0TDTAb1TqUNKQQIDFBNIW6lBSFvA7lwV0ZtShpAAAEM4QYAVbfz5LmBn9bM9B0QG/ij8qPODr73xU1tYpOoYnjKWm7Y63DieL1sz6xrsf8wu6v3M0tVUiF56eXn5XePDffPSFcG+UwGiKOpQ0JBBgMYG0hTqUFCIF5sNTh/EBAACEMwRYwb716ZcPPb24YvWthy3Cvdk194VfOCg6gNTTZLGeLb/7872Hvv7O2pdWrvn6O2v/IXbXgbxbr3weK0qv/Au6qx4v6L5lz4srVv8obo/wdm6P9z998LnwdlWdPcID5tY4JPnVgaPkga///OEfjzxeRauwqfUfYnf5l5l/+8Nfxx/tU6qEZ5ks1q+/s3Zn9jXyo9vj+ca7H69LvzioUr+wfFVKUTl/5PKEpO/H7oo5d4l/hV/9zXtWxxOLfy0eRlPUYcwfEgiwmEDaQh1KChC1MOQCAIBwhgBLpEehFGZMf/bOR6J1qf5pZ4IwTvow5axwr8li/dO3PhBGTrO1l1aueWNXAlnTqnlY9l8+jnm0a8WqxiGJ8JqfnbkgPHFXzqNc6amah6RfefO9D5PPWgLLyUvHtfkNzRzHlbV2vLB81fbLeV6v1zBt+YfNu/7je38w22z8icbAuxAFWJ+dueD1+Zb9YeNPtx8g2w3Tlj/57Qd7rtz4KPXcX334R5fHw1+BLoym4PmAAAsgStldLnwPC0DU2piRnSz4n3+BClSVLtSTBUQtsATOV1YLA6x/TTgm3DugUgv3vrxyjcZoEh5wuvSOcNn12dqLK1b/Pi2Dn134YfJZ4d6PU88Jr5l7v0F4zR/F7RXunY3P5/uXPQe/E7PV6xUvrfUvuw/+5fufudyP8qbK9u4Xlq/KrKrlD5gtwOI4buulqy+vXKPSGTiOu1xT9/LKNcPqcdYBFsDzAQEWQJTCEJaRivYu0f/oBxCGEA2wgKrShXqygN4flsA6wWy4F5avir92S7j30M1C4d63j6QI90rGNX/25FcTztY+P5spPPFOZ48wF/ubj9YJ92qMJuG5X/vN+8K9s7E6HF9/Zy1JnQqbWslDTNfrGz1e71+v/eJ/7z/CH0kmBvJx1dwBVptUzqddyxOSyNNYH6We+7N3Ptpz5cb+3Pzilnb+OhC2MOYPCQRYAFEKQ1hG8BcXRAR8UFlAVelCPVlA7w9L4K3DyXxU9OKK1TcDc+54otl8p0vvCPeuP5/14vInlriarX13wzbhiW6P9+WVX37v4QvLVxmfXH5EtFc0q3FGogBr39Wb/37N79/YGU/SqOAA69DNQn7LHAEWmUX41uGTZP4gWQ8LAVbEQScVEgiwmMCCTdShpNRhCMsIOjPqUFIWUFUWUFW6UE8W0PuzgKqK/HzPIT4nemnlGtGK6f+acIzf+5WVa0paOoR7f7Jtf3BWNWN7aeUa4bcTchz3n9d+ITxApdML9/71nHtn5PP5frx13w827yZTCL0+3yufx76xM55s/9an6/mphQUPW15YvqpEEDzNEWCRWYR//ruPU4vL+bmErKcQ4jcqdShpSCDAYgJpC3UoKXVYA4sRdGbUoaQAABDOEGCJ/M8dB/ic6MUVq+v7BoV7f7L9y4jqxRWrRHu/u357cFY1W9OZp4Xn/tc/bBTuHZmYFO599Ystwr2ScY1w72zIYu3bsnKtDofN6fzrtV+8sTOe47j08rsvLF91qqSSfPvhtz/f/J2YrfySWE8NsMgswr98/zN+NXcEWBEHJQ0JBFhMIG2hDiWFSIH58NRhfAAAAOEMAZbIyoPH+ZzopZWrbze1Cvd+cuo8v/fFFasv3b0n3Pv+yTPBQdWM7a8+/KPwRI7jvvbb9wX3XSOaJPhvV38qPF0Ufs2hsKn1n3c9+trEv9uw/WLgBft8vrTSyr/94+YXlq/6i3c/XpuSLlqKnkw/5G9X1dnzjXc/Xpd+kewlswj9MyjLHs2gjBEsHPbV37xndfi/9JAijKaow5g/JBBgMYG0hTqUFCBqYcgFAADhDAGWiGiVq7PlVcK9+3JvCvd+8TjTIcrbO4V7Z2svr1yzIztPeGKPQvmCYBH3v177hXDvtN0hXAMrON567mE0Bc8HBFgAUQpTCAGiGQayLKCqdKGeLCBqgSVwrKBEGDbx8+aImu4+4dcF/of3/iDKkt5NOhWcWAnbiytWfydm67T9iWeU1p/PEh6zKumUcG/joER409ditgr3AkCkQIAFEKUwhGUEjxNDREA0wAKqShfqyQJ6f1gC9f2Dwizpbz5aJzrgv/5hk/CAtMBKUjydefrllWteEuRNwvbSytU/3LJHNF9PpdP/uzW/5495ccXqmu4+4QGix77eO3FauBdgATDmDwkEWABRCkNYRvAXF0QEfFBZQFXpQj1ZQO8PS8Dt8f7Jbz8QxkmdcoXwgIRrBS+u+DJO+pPffhD8nYClrR0/3+v/NsOv/sa/stXLK9e8vHLN323Yfqa8SvTlgxzHrUj8ctWtF5av+q9/2Cg65h827/4yAluxOreuQbgXYAHQSYUEAiwmXli+SrwJFgclpQ5DWEbQmVGHkrKAqrKAqtKFerKA3p+FkYnJb326Qbw1ur134rQwUfrD6SdmEdpdrm99sl54wLf/uFn0UBVhslgbByW3m1pre/pnPMDt8a7PuCycHvjiitW3HrYIj7nfNyg84OWVa2a81PMNv1GpQ0lDAgEWE0hbqENJqcMaWIygM6MOJQUAgHCGACtYcXO7MJ96+c01omesRKFS4LGpTYMqtfCYp5q2Oz5IPitKr94/eUZ02MqDJ4Q3WhOV8wcxmqIOJQ0JBFhMIG2hDiWFSIH58NRhfAAAAOEMAdaM/m7DdmFstPLgCdEBCdcKhAf4Zwu++d7h/KIBlXo+9azp7vv2HzcL06uXVqz+3qadOrNZeFhRc5so4brfNyg8IEpgNEUdxvwhgQCLCaQt1KGkAFELQy4AAAhnCLBmVNDYIsqngleeEq2tTtpfvPvJv1v9+1aJTHQwoTGaLt2t+2HcnpdXrhGe9eJM6ZXObP5/Pt0gPOxX8UeFB0QPjKbg+YAACyBKmSxWdGMAUWttSnpWdZ14KywOqkoX6skCohZYSr/cd1gYHn1z1aei1dw5jksrqRSu+C4MpL6x6tOf7z205kTaunOXPjl1fuXBE8v+sOnllWtEcw/9bcXqXx04Jkqv3B7v8sQk4cF/+taHknGN8BgAiCwIsACiFIawjNxubA0enAGEG0QDLKCqdKGeLKD3h6UkGdd+Y9UnwqTpG6s+CR4mSca1/7ht3wyx1PzaN1Z9crHqnuiabo93bUq6aPIgln8FijDmDwkEWABRCkNYRvAXF0QEfFBZQFXpQj1ZQO8PSyx4IuGMGRbHcdfqG//fdXHB+dRs7cUV/ke64q/dGtFOii7l9nh/c+ikKL36//Yddnu8oiMBFgydVEggwGICCzbRha98ZgFDWEbQmVGHkrKAqrKAqtKFerKA3p8FVHVuh28WirKnf7v60+KWdvFxAfX9g+vOXfrbP26Z7YGsl1au/sa7n/zuWOrp0jvTdof4fI5T6fT/a3ei6PS/D1oeK9rgNyp1KGlIIMBiAgEWXQiwWMAaWIygM6MOJQUAgHCGAOuptly8EhxFfXYmc8YEitCZzRXtXecrqw/euL39ct7eqzeTi8ry7j/sUSjneJAqt67hP77/mehGr34RpzGaxIdGGYymqENJQwIBFhMIsOhCgAURBPPhqcP4AAAAwhkCrPmY8QsH/8vH664/aBQdubB6do8of3csVfTg1YsrVuPZKwKjKeow5g8JBFhMIMCiCwEWQDTDkAsAAMLZwgKXKFTQ2PJXH/5RlGG9tHL1f/k4Jrmo3O5ykcOetZ5VnT3/mnDsq795T3Tlr7z53h/PXuQvG+UwmoLnAwIsgCiFKYQA0QwDWRZQVbpQTxaeNRoAoEul0684eDz4UawXlq/68999vObE6YzKmnu9A0/9lE7bHcXN7RsvZL+2Lu7lN9eILvXiitV/89G6wqY28WkAEOEQYAFEKQxhGcHjxBAREA2wgKrShXqygN4fwsHZ8rtff+ej4AyLtJffXPO137y/5kTa9st5p0oqL92tu1bfmFVdd6asKuF6wdqU9J/uOPCV37z31TfFj1zx6dX7J89g2iCwhjF/SCDAAohSGMIygr+4ICLgg8oCqkoX6skCen8IEzqzOTYz52u/fT84gVpwe3HFqn/Zc/B+36D4ZgAMoJMKCQRY9GHBJupQUhYwhGUEnRl1KCkLqCoLqCpdqCcL6P1Z6JQrXt+4Q7wV5kFnNqeX331tXdxLK8XTAOffXl655i/e/eTTtPPtshHxDeAx/EalDiUNCQRY9CFtoQ4lZQFrYDGCzow6lBQAAMIZAqzF65QrEq/f/sm2/S+tXDOfMOulFatfenPN//VxzGdnLtxsaJq228VXhCd9mHz20l2MpmjCADUkEGDRh7SFOpQUIgjmw1OH8QEAAIQzBFgUuT3evPsN/3ntF9uzct8/edoSvwkNLSTNea9C/Ol8Esb8IYEAiz6kLdShpADRDAEWAACEMwRYdPnruWG7z+fzer3BsQIa2tI0R2251+v1+XziDyiEFAIsgCilMZrSy++KtwJAdFh58PjtplbxVlgcVJUu1JMFRC0Q/jpkI3+3YbvH43G5XMGxAhra0jR7Tanb7UaGFW4QYAFEKQxhGcm7/3BQpRZvBQgziAZYQFXpQj1ZQO8P4a9DJv+79ducTqfVag2OFdDQlqhVFdnt9jkyLIz5QwIBFkCUwhCWEfzFBREBH1QWUFW6UE8W0PtDmCMzB10ul9VqNRgM4kwBDW2pmqm8YGpqimRYMwZY6KRCAgEWfViwiTp85TMLGMIygs6MOpSUBVSVBVSVLtSTBfT+LKCqFPl8Po/HY7fbTSbT+Ph4cKyAhrY0TVd8Q6fTWSwWl8vl9XrFn1R0UiGCAIs+BFjUIcBiAWtgMYLOjDqUFAAAwhkCLIp8Pp/b7bZarTqdbmRkJDhWQAvnZjt3zFVXYb+YHLxrYc2avN9+KcWSECvabr+U4u5ssueeDz6FVtMU5KrV6qmpKYfD4fF4gh/CwgA1JBBg0YcAizoEWBBBMB+eOowPAAAgnCHAosjr9bYOS/77HzdrtdqhoaHgWGEhLXGzs7LAO6bwmQwepdxRmCs+IKzawS2egS6vQupVSD3SAdfDWtv5JPExi29s7uKqq+A4ztVUF7xrYc07ruQ4znH7qnCj9ch2n8ngM+qtx3cHn0Krjd3MGR0dNRqNdrt9xgALY/6QQIBFHwIs6hBgAUQzBFgAABDOEGBR5A+whiT//Y+x4+PjAwMDwbHCApqrpd7/bJfd6lVIfQ4b57AHH8Oo+Qw6zuWyntgbvGu2ZktN8BfC5/OZDJzHQ4riuHEx+MinNsftK/44qfFe8C6KdxE26gGWu6fVqx0ThWuuexU+67Qt/Wjw8RSb6sblkZERg8EwW4AFIYEACyBKYQohQDRDLMgCqkoX6skCohYIc48CrM9j1Wp1X19fcKzwzC1xM+d0chxnO3fM/+PBLeJ5Z4mbbelHrSf3CTdaD2+zHttJHvbxByWH4oIvO8dZtrSD1pT9lvhNnMPuv3Vqguh026lE26lE8TXJLhItkZTt4BZ3Z5O/LBNPLAdmPb7bf/fD20TnWlMO2DKOk9dgid/krLzNcZy7q+VZ7/LofR2Ks104YUnc/NT7+o88e8SSuFkUYPmvc3DLl6enHBCdaDtz2JZ2cK6Nh+KC478ZXwb/38KavN+a7C/+IpvyepZMJtPr9TabDQFW+ECABRClMIRlBI8TQ0RANMACqkoX6skCen8Ic8IAq7e3NzhWeOZ2KI4LRA+O4jzRLuvhba6mukfPH3Gcb8pov5xGdnlGJD671VF6nXO5/PvcbsftK/M8y1Vb5n8j+gly30fcbnKMPeesz2z68tzsM6JX9US0FDje/6PL9ejHS6e8uokvr9r+kIRr1mM7vUr5o61erz3nrKuhhj+M4zhndck872K/nOb/Z0ON/+EsjnNcuzDHff0xWcl1LrDGuc867ZEN8gGWPS+D4zjPYPejw2pK/bse1j66Y16Gz2ImV/Nqx6xHts+40SMf5jjOnnVq7rf/6DXfryQvwH9f+ZAwO1tAIwGWTqebLcDCmD8kEGABRCkMYRnBX1wQEfBBZQFVpQv1ZAG9P4Q5r9frcrnMZjO1ACt+05ehhnTAfvlRFOKfifbAPxfBO6FxVt5293b4IxibhSQpXoXUHz/5fO6uZo98yH+y221N2jWvszjOq1F5+jvdHY0k5/L0d5F5fNaTezmn02eddty67CjK5Vwu/ly+iaIlZ8Ut/wXHVeTJI//TZD6fu6XeeaeQZD0kmXLdr/QnOM337dmnnTWl9ivpjuuZXvWo/+UZdO6uFj4Deupd7Nmn/bt8Pv+kS9WI/fLpOe5rO3OYvGV3RyMJm/gAy3E90//eh3oeVVvwcJY15cCjC7Y+cD2467NO+x+bmmmjv6QcZ88+Pffbf/SaOc43PeUvu9vtf3NF4sjymdpTAyx0UiGBAIs+LNhEHUrKAoawjKAzow4lZQFVZQFVpQv1ZAG9PwuoKkUsAizr8d0eST9/C3frA//2hFgSc9hOHyKHedWB9cLzsx5FURznrCoiR/qXsiK75nHWo+sHmmgKIXkKyVlbRn5097b705mcs8JX+yha8njcXS3uvk7ycJOj0L+KOTnd3dtOjiSPOHknNf5LBdb5cnc0Wo/u4C/19CmEM93lURjkcNjSHk1ynOO+rnvlwl0k0XtqgPXorMcvjEwGnHGjMMCa42WQ1+wzm6wn/fMNScjoaqgOfuPzbwiwwhMCLPqQtlCHkrKANbAYQWdGHUoKAADhDAEWRSwCLNJsF5M90gFyF3tehjU13h95OGz8Ae62Bv6JHmFu4t/V589lnBW3nums4ADL3dUsfsMc5yjIeeJ1kmjpMe/EOP+1ieR0Z2UB+dF6Yq//iMDkRFv6UZ/d6v/R5XI13yfpz9MDrJnuQsIgr0L65Xuc/b7+x538u26TXcKUao4A69EFS28IX9KMG4UlneNliF4zeeOLXEseAVZ4QoBFH9IW6lBSiCCYD08dxgcAABDOEGBRRH8NLGFLiCUPTDlrSq3J+/33czr4ve6eNj5AEUVR5AEuR1HeM501Q4AViHvcPa2OotxHrSBb+MzUl9GS0+E/KyFWuOtRWnSn8NGRaQf9aZrFTH60ntzrqr9DYixX8/15BVgz3WWGAGv2+z7K7+4Wk11PBFjXLjxaiypoF1kznj/r0V1m2vhEgDX7ywhJgIUxf0ggwKIPaQt1KClANEOABQAA4QwBFkXUAyzbqURnZQEJiaxHdzyaDFiQ458M6HCQp7ECj/Ps8dks/rAp4zifm3ikA9bD22yp8WQpd/ul1PmcJQywfFNG4RrkzsoC/2UHuvnMiP/GwC9f8JOrUwmbs6rIX6IxBflmQLLulWfIXyX+O/js2Wf8GwNRjqMoLxAhDQdfao67BAdYc9zXeccfFXnVo5bEzdYTe7wTGj45sl9M9gdMdqv12E5rygGy+DrZ5bxb7D9rXEmWYHcU5lqP755x4xNTCGd/GSEJsCAkEGABRClMIQSIZogFWUBV6UI9WUDUAmGOeoBlv5RCruv/Tr1A9uTVqsm66SQQ4dxu75iCPLjk7m4lZ5HcxL88udNJFr3yqkbIrqeeJQywPMN95GCfddofMx3ZTpYe905q3P2d/kXWvV7RC54jWuJP95kMXo3Kf5jLZTt3zP90Un+nd2Lc3dXinQxESIFltmwXTpCq+qzTc38LobAFB1hz3NeavM9fosC0Sv/69IE471FydHCLzzpNDvbXf3qK3+Vfjj3w38Jnt5Ir284emXHjE4u4z/4yEGBFDwRYAFEKQ1hG8DgxRAREAyygqnShniyg94cwRz3AsiTEOstuekZl/tRDNeJ6cJd8mSBpjoIcj6Tfp5/0SAf8iys9fjDq0SLupTc80gF/MNTRKHxUarazXPV3PPJhfn33wDS3RM9Qr89kcPc8CrmsJ/e62xq86lGfyeAZGRblSiTc8UgHPH0dou1PnD6u9GpU7p422+mDZLs9K80jGyTv0b/2/OOX5Lxb7NWOebVqe/aZed7FduawRz7sul85n/v6j8886Rns8WrVrpZ6Ejk5iq892nXhBCmgq/Ge7fQhj3zYUfRopS1bWqK7t907Me4dV/pnBQZecPBGUUlnexmi12y/kh54GWy/hRBj/pBAgAUQpTCEZQR/cUFEwAeVBVSVLtSTBfT+EObYLeL+TC34WSq0aGtPDbDQSYUEAiz6MDKgDiVlAVVlBJ0ZdSgpC6gqC6gqXagnC+j9Wajt6X9jp//L6WDxEGChhUlDgBWeEGDRh5EBdSgpC1gDixF0ZtShpAAAEM4QYFEUJgGWszzfP20w5UDwLrQoaQiwwhMCLPqQtlCHkkIEwXx46jA+AACAcIYAiyKv11vV0fWTzbtCG2ChoT01wMKYPyQQYNGHtIU6lBQgmiHAAgCAcIYAiyIEWGhh0p4aYEFIIMACiFIjE5OXquvEWwEgOryxM762p1+8FRYHVaUL9WQBUQuEOQRYaGHSEGCFJwRYAFEKQ1hGLlXXjUxMircChBlEAyygqnShniyg94cwJwyw+vr6JNnnes6ntKUda0o+/PDEwYcnEufZGo6TlvAgKb7+WPz9owf4Vn/sQP0x/0bR9vtH99cd2X/v8L7aQ3trDu6uTvS32kN77h3eW3dkf+DEGc964oIPkp5ogY3kgC+b6MQHSfENxxP4Jjz98Ub/G3nqewm+suDu5LXxt3jKXQTt0Y/zvO+Te4Ub/QUU7gp6tU9sCbrUzPcK2kve5hOv//FbE39CZmyNJw+1pB7pPHti4OLpgTtlcwdYGPOHBAIsgCiFISwj+IsLIgI+qCygqnShniyg94cwRxZxn56eVqvV/f399fX1xcXFeXl5WVlZFy5cOD9v5wLS09PPBpw5c+b0Y2fOnCEbRdtPnz6dlpaWmpp68uTJEydOJCUlnThx4uTJk6mpqWlpabOdJdzOSw8g/z7zGP+j6FxyMP+CyYnkH/x24a7gK/B34TeKtgtf1XzuIjLbKw/eLto7z118iUTHC1988FmzFZ9HXjx5X+LPx0wyMjIyMzNzcnLy8/Orqqra2trkcrler7fZbG632+v1ij6r/+TvpPpEG4E1BFj0YcEm6lBSFjCEZQR/cVGHkrKAqrKAqtKFerKA3p8FVJUiPsDSaDSDg4MPHz4sLy+/efPmlStXLl++nJWVdelZXHwsU4DfGLyLZGTnzp3jQ5Bz585lZGRcuHBBdKLwLOH2+ZjxXNELFm2fz3uZcSPvv/1q5db4RPHWx4LvEmy2+4p2zfaq5tg148bgXcEHiPfNgn93c8vKysrOzs7LyyssLKypqeno6AieV4i2NC34eTceAiz6kLZQh5KygDWwGMFfXNShpAAAEM4QYFHk8/lcLpfVap2YmJBKpW1tbbW1taWlpQUFBTdv3ry+INeeNMeua9eu5ebmXhXIzc3Ny8vj9854lvCCwURHCn/kNz6TGU+fcaNw+9+ufHtv0okvr/LsnrjBTLcQmm3X3GfNiD9lxrOEexfpxo0b+fn5hYWFFRUVDx486O7uDg5W0Jameb1eX4D4FwQCLBaQtlCHkkIEwXx46hBgAQBAOEOARZHP57vb2fM/4/YYDAalUtnf39/S0lJXV3f37t07d+5UslTxWHl5eVlAeQC/XXxCRPnO794/mn5evBWeVFVVVVNTU19f397ePjAwQMKU6czkqYrb5srC6TtobJvlYgqpucvl8ng8JMYS/YpAgEUf0hbqUFKAaIYACwAAwhkCLIp8Pl91V89Pt+0zm80TExMKhWJwcLC7u7u9vb01oIW95ieJd0em7639w9m86+KtINDa2trW1tbe3t7d3T0wMCCVSkmYoi+5qdFotMCesewWqbnVanU6nTOunY8ACyBKYQohQDRDLMgCqkoX6skCohYIfzXdvT/dvt9ut09NTel0OrVaPTo6OjIyIpfLZQDsyR8jYYqm4KpEIpFKpeLjgB5SXu3tPFJzo9FotVpdLlfwQ1gIsACiFIawjGAKIUQERAMsoKp0oZ4soPeH8FfT3fdPOw643W673W6xWKampoxGoz5AB8DY5OSkVqsdGxsbGRkhYYry+uWurq7u7u7egL7HDmZm3blfz/8IC0Oq2h2gunH5UWio0UxNTdnt9uCHsBBgAUQpDGEZwV9cEBHwQWUBVaUL9WQBvT9EBJ/P5/V63W63y+VyOBz2ABsAY1ar1Ww2GwyG8fFx/gmskdyLra2tHR0dnZ2d3d3dPY99/9MvMm/d5n+Ehenu7u7s7Ozo6GhtbVXkXXwUGiqVer3earW63W4EWMxhZEAdSsoCqsoI/uKiDiVlAVVlAVWlC/VkAb0/C7ebWlcePC7eCotDvoPM6/V6gIZ/2r7/bmePeCsIkMCUzF3VaDT8GlgjuZmtra1dXV29vb0DAwODj/3DH9ZfLirlf6RuqL9ffr9muKtTvIO9kbpqdX6OtK1FvIOBgYGB3t7erq6u1tbWkdxMUnO5XD45OWmxWMgsQuFvBgRY9GFkQB1KygLWwGIEf3FRh5ICAEA4Q4DFFEmyYJH+aceBmu5e8VYQIA/9OZ1Os9ms1Wr5AEuRd6m7u3twcFAmkykUCqVSqQr40bot16tqyL8XQ6lUqtuadLkXTKcPmU/u018+M9beolQqJ8oLLPGbDJdP83dcAsoAQ26GJX6TtqaC/Cg+iB6lUqlQKGQyGfmuBkXeJVJz/3pYWu309DQCrKWAtIU6lBQiCNbAog4BFgAAhDMEWHShnixgNDUfXq/X5XJNT08LAyzVjcuDg4MKhUKj0eh0Or1ebzAYjEbjmcLSrmGJcREMBoNerzc23rMkxPrvlbjZcnSHJX7TdGqCTqcztjdZUuOnqorJAnDkpkyR16PT6aau+6fyGR/UCN8vdfztNBoN+b5Rfg0sqVSKAGvpIG2hDiUFiGYYcgEAQDhD4EIX6skCRlPzIQywZDIZCVPU+TkymUyj0RiNxunpaavVShZlWySy5JZlcsKStMsSv8l8+6pxcsJoNE4N9pmL8kwm09TU1NSY0jw1NT09bbFYrFar/xSlwjaheeI6JoNtyuTfNSq36Sb9S3lNaPz/12S0yYaFRwafy3v0YgyG6VG52Wyevpnlf0mNdWazeY5bL57Vap2enjYajRqNRiaTqfNz8AQWAMxsUKXOu/9QvBUAosPrG3d0yhXirbA4qCpdqCcLiAYg/OFTCqEyY4A1fuuKQqEgSzI5HA6Xy+V2u8ULaD0jst6W0+m01pT575K83xh40Il/1slkMpnrq/y7CnIeRWbtjdaj28lLsp4+5FQryUWsx3dbzx2zBSIn27VMR1OdJX6TvbrEcmSbJX6Tc2zU/00InU3Cc13jKuFb8F/H6bSX3yIHWE4lWi6c8D8I1lRnsVhsNpvo1qLTF4z/lgaLxTI5OalQKMZvXUGABQAzw+CAkfTyuxqjSbwVIMwgGmABVaUL9WQBvT+EP3xKIVRmDLA0BVfJl+LZbDaSp5A1s86WVan1BvFKWvNAvprA7Xb7s5vc85b4TaZrFzWPabXayclJnU5nCmRb0zez/I99yYYsCbHWs0ccA932QLBlPXvEHYjSrEd3+GcgJsRas8/YKgvsD6r9Lzsh1pq835Z92jmpcY7KBOfeJed6AgmUN8Dj8Tj7O/1nHYqbLsydPnOEvHFTQ83U1JRFOjjj6eRc8Xt7RqTgNptNr9crlUpNwVUEWAAwMwwOGMFfXBAR8EFlAVWlC/VkAb0/AMBs5giwDAaD3W53u90+n48cvOBOig9u/BPoLqZY4jfpbueOjo4qFIrR0dGxsTG1Wq3RaAxVJZb4TVM3LvmnLgYesLJ2t/nnBtps1vSjlvhNDt2Ew+HwB1jxm6z1VVbifuC5rdR4m0Fvt9v9B9zK9j+c1d32aNZe+jFL/CaXQUcSKBJg2fL9i0+ZKwv1er12bGzqrD/D0t+v0ul00zf8C6tbu1v9j2I9eTpfigXz+Xxut9tutxsMBgRYIYMFm6jDYIsFVJWRBXdmMBuUlAVUlQVUlS7UkwX0/iygqhD+8Bt1PmYLsFQqldFotNvtHo+HSoBFUhv/QldX/U9gTV45L5FIpFKpXC4fHR0lX/w3WVnoX0n9WubExIT5XNKj+X2CZpYN+9eoCgRYBoWMrPVOntsyB2IvspCWJeN48Ll25YjL5SIPgvlnMmae9CdW7U1jY2NyuXwyJ93/xqvL1Gr1jLe2K0fcgYewFplh+Xw+j8djt9uNRqNKpUKAFRoIsKjDsIAFrIHFyII7M5gNSgoAAOEMI1UIfxhNzcfSBFjkLhaLxf8df0XX/I9ZHd8zNNAvkUhGRkZIeqVUKifKb/tDpdwMpVJpOu8PofS3rmhrKiZqKybvVeoaaie0fpYj/tWp1AN9qgASexlyM8bGxsbHxzUazVSGf0ErfcGViVr/ubq6KmNzvXlqijyfRZagms5M9q/2VV8jkUj6+vo0Waf9X79YWSSTyUzn/QGW7vGtyenTZjN5Hk2ULj0rBFhhAQEWdRgWQATBGljULXh8AAAAsAQwUqUL9WQBo6n5eKYAa2FjfhLZOBwOs9ms1WqVXR3TiZst8ZsmrpwfGexXqVTarjZDfrZSqdSWFfgfzspJl0gkE7kXLPGbtDcuDwX4o66hAYVCMTIyMh0IsGSdbcMB6uKb5CzyPNfIyMhkXqb/3Jv+c0lGNj4i1+v15BsVLRaL/1mtwDzByUtpPT09ffdrpwLXHCktGBgY0F7N4G8tPN1isfArgonf5LwhwAoLCLCoQzcGEM0w5AIAgHCGkSpdqCcLGE3NxzMFWAvDB1gmk0mtVkulUlVBrn8VdsEEPXNqvH9BqDL/1wJqL5/p7e0daGyYTtzifxIq7aA2M8WYEj91Yu/g4ODAwMD0Yf+3DQ40P+wNGL2d53/Nl8/09/eTtGu4tZmcq087NJGZYkxNMJ/cp9FojEaj2Ww2mUwTExPjbc2WQI42dXTHdOJmEmBJi252dXX1P3wQfLpWqzWbzQ6HY5EFQYAFAPOFKYQA0QwDWRZQVbpQTxYQDUD4w6cUQmXJAiyyAJZarSZT9qT3qydzzk2dOWI+e3TqxqWJ/h6lUjlaX6s7e3Tk9rWOjo62trau2mrVhVRdcrwxabc2PUlecqsnQHMxbSI9qaeluTtg+G755JkjisLrvb29/QHd3d299++NZZ4i506eOz52p2RsbMz/RYcmk8FgGB8fl8lkI1VlE2eP6VISZLkXuypLJ9IO91WWtgV03asey3x0a3K6Wq02mUyiVe0XAAEWAMwXBgeMLOxxYoAlhmiABVSVLtSTBfT+EP7wKYVQeaYAa2FjflGAJZVK+/r6+vv7h4eHR0dHx8fHtVrt+Pi4QqEYGhrq6enp6OhobW1tbm5ubGx8+PBhY2NjS0tLe3t7V1cXSay6AvwpVUBPT093d3dPT09/f//g4CAJsMgVmpubW1tbu7u7JRIJCbCMRqNOpxsbG5NIJL29vfy9mpqampubW1paWltbW1pampqaGhsbm5qa+NPVajUpCAIsAFgiGBwwgr+4ICLgg8oCqkoX6skCen8AgNk8U4C1sE5KuAaWRqORy+UDAwMkbJLL5UqlcmxsTKlUyuXywcFBEmC1tbXxKRIJoTo7O/2LVfX1kcSKPGw1GDAwMNDX1zcwMDA8PCyRSIaGhnp7e9vb21sC2tvb+/r6ZDLZ+Pi4/ysLTSa9Xj82NiaVSkmA1dbWRkKrlpYW8viVMNLiT/evDT81hSmEzwmMDKhDSVlAVRlZWGcGc0BJWUBVWUBV6UI9WUDvz0JWdd3alHTxVoBwgt+o87EEAZboWwiVSuXw8PBAgEQikcvlo6OjCoVCJpMNDw/39/f39PR0dXWRaKmtrY08e9Xb2zs4OEiWuCL/kEgksgCpVCqRSKRS6cjIyOjo6MjICP8kV0dHR3d399DQkEKhmJiYMJlMZrPZaDTyOVp3d3dHR0d7QEdHB3mwq7Ozk2xpb28np4+Ojk5MTExPTyPAek5gZEAdSsoC1sBiZMGdGcwGJQUAgHCGAAvCH0ZT87E0AZbP53O73WQWoVarVSgUEomEPDAlk8kUCgXJsORyuVQqHR4eHhoaIs9V9fb2kqeryJEjjykUCvLoFnl6a3R0VKVSqdVqjUajVqvJ9clzXkNDQ3K5XK1Wk28htFgsZrNZp9OpVCqpVDowMEDmIfKPdJGArL+/n2zhTzcYDPgWwucH0hbqUFKIIAubDw9zWPD4AAAAYAkgwKIL9WQBo6n5eKYAa8FjfpLaOJ1Oq9VqNBq1Wq1KpVIE8NmTWq0mgZRKpSKZ1MjIiDxgZGREqVSq1erxxzQazcTExGTAxMSEVqudnJzU6/VGo1Gv15Pr81GXWq2enJycmpqyWq12u91qtU5NTU1MTIyNjY2MjEgDSDpGXoxSqSRpmlwu5083m81kASxRuvSsEGCFBaQt1KGkANEMQy4AAAhnCFzoQj1ZwGhqPp4pwFoMYYZlMpl0Oh0Jnkj2pNPp9E8SHiDMpwiTyTQ1NWUOmAowm83kAavp6empqSm9Xk9On5iY0Ov1JL1yOp0ul4u8BnKMVqvVaDR8IkZehk6nm5ycJPcVnu5yuRZfDQRYADBfnXLF7cZW8VYAiA7f+nTDyMSkeCssDqpKF+rJAqIBCH/4lEKoLGWA5fV6SYZlt9vJVD5R9mQVIFEUfwx/gO0xu93uCLA/5nA4nAHk+iTJMpvNFovFZrM5nU632+0JcLlcotcgvIXw1qLTFzl/EAEWADwDDA4YSS4qN1ms4q0AYQbRAAuoKl2oJwvo/SH84VMKofJMAdYix/x8huV2u10uF4mfCPJslIjT6ZzjGHcAuRr/b4Jcnz+dnOjxeEj8NJ/XILy16HTxu3pGCLAAYL4wOGAEf3FBRMAHlQVUlS7UkwX0/gAAs3mmAGvxnZQvwBvA500E2SgyxwHkUrMJPpdsF70M0TFCol3C0xcDAVZYuN3UipEBXRhssYCqMrL4zgxEUFIWUFUWUFW6UE8W0PuzgKpC+MNv1PlY4gCLJDiOilu2y2mk2Yty3ZJ+YSAlPDLYE9ea01NPFB1AzLZLfPJCIcAKCwiwqMOwgAWsgcUIlc4MhFBSAAAIZxipQvjDaGo+ljjAIs89kbtYk/dbj+8h/3bWVdDNiebJ5/PZr12wJG72jCmW5u4IsMICAizqMCyACLLI+fAQbPHjAwAAAHYwUqUL9WQBo6n5eKYAa5FjfpJeud1uchf7xLjD4bDVlvt/PLjF43T4Z+5Zpn0et8/r8YyNci7Xl+farB6t2uewf7nFYfNNT/E/cl6vz2Tg+BDK4/FOjPtsli8PeMw7ZfTverwelu1ymiV+k1s+/ESC5vN5JzVeg0507uIhwAoLCLCoQzcGEM0w5AIAgHCGkSpdqCcLGE3NxzMFWItB0qJHX/8XuItJOWIymcxq1aOHsPSTLqPeH2zdzLJlnuQfy/JMjNsyTpBj/HuvZ/pDLp/PlpboD55kQyR4ct4ptMRvcj2s9Xm9znvllsTNj47PPu21mMkxHvWoNXCW//mvlAPuCY31xF7+yv6rmQxej8dZX2U5uOXRYUm73H0d4jezCAiwAGC+MIUQIJphIMsCqkoX6skCogEIf/iUQqgsWYBFnr2y2+1ms/nRXYYH1Gq1rvWh/8dDWy3T0zat2v/vhFjLwS22q+edLfVup8N6KsESv8l2M8vRdM967pg/k7p91ePxOO7cDvz7CllznRzmHlc5Oxr9x2efcUoG7BUF/mNuZfsXZXc6rCkH/LtuZdvrKq1pifaBbuudQguZxph9xnr7qtNqcbQ+8OdWJ/Y6HtbYK26RF+PRaakUAQEWADwDDA4YWeTjxABLA9EAC6gqXagnC+j9IfzhUwqh8kwB1oLH/CS1cTqd09PTOp2O3EWflaa7cm768DZL/CZD4TWdTjelVJAAyzrYY7fbHQ6HvafdvyXjuI0YH/P/mLjZYbPZVf6DrUe3O21Wh2rU/+8zhx0OhzXwuJZtTOk/3mqxHNxiTdrldDodvR3+cy+c9G+2WqenTFMmo9FoNGcmW+I3GXs6pqamLBaLNf2o/1K9HeSG1vzLlvhNjtoyWkEeAiwAmC8MDhjBX1wQEfBBZQFVpQv1ZAG9PwDAbJ4pwFpwJ+Xz+cjjV0ajUa0OPGb1uJmO7xm7nSeXSlUq1YRkyL/xyHaDwWAymaampqarSy3xm8wFVwyPWY5st8RvmhpT+p/kOp/kP7690XK32BK/afpOoT+EOrpDeH2SiE1PT1sCi22ZC64YjUaDwaDT6bRarVqtNp33B17a1katVusP1w7G+fOsMaXBYPDHW4GzrLevulwuKhkWAqywgJEBdSgpC6gqIwvuzGA2KCkLqCoLqCpdqCcL6P1ZSC4q35iRLd4KEE7wG3U+lizAcrlcVqtVp9ONjvqflrLEb+qqv9fa2tre3t7V1dXf3y+RSEZ7u/w51JHtY2Nj4+PjWq3WcKfIHyflXhgjVCpLon91Ku2owr+3tsKfSeWcNZ89YonfNDHUr9Fopo/t9P+7olBbUzFRWzF5746urXFyctJU5Q+5jNcyx8fH1Wq1SqVSKBRSqdSQ7k/BRh/cGxkZUalU04e3WuI3jQ/2kxsaym75X1LxdZvNRqKlRWZYCLDCAkYG1KGkLGANLEYW3JnBbFBSAAAIZwiwIPxhNDUfSxNgkbtYLJbJycmRkRFyl/Z71U1NTS0tLe3t7d3d3f4Mq73FnxYd3iaVSuVyuUKhUD+o9UdUSbtkfb3Dw8OqKv8DWVMn98vl8pGRkdHhIf9q64FIy5R2UCaTSaVSYyDMUt4pGRwcHB4elslko8NDSqVS87COXEox0C+Xy8ce1I60NPb390+SAKvo+sDAgEQiMZ4+7K9A0TWJRCIbHJw65V/03dhQazab7Xa72+1GgPU8QNpCHUoKEWTB8+FhNgseHwAAACwBBFh0oZ4sYDQ1H88UYC14zM/fZWJigr9Le+2XAVZXV1dPT89gs3/99enD2/r7+4eGhoaHh4eHhoxpB/3B05HthlMHLQmbLQmb5dUVA49NXEojV1MV5Pb29vb09Eju+EMuS8LmyfSkiYyTphN7dZkpjy6V6l/offrQ1qnju/2hVXVFT0+P6koGmWZoPrJjqLVZftc/Z9CSEGtMTTQHHuYynj06plIZDAar1RqcLj0rBFhhAWkLdSgpQDTDkAsAAMIZAhe6UE8WMJqaj2cKsBZMFGBNXEjWnj3W9qCef/yqt7e3r6+vr7198txxzcVTvb29AwMDg4OD/f39fV2dqutZujNHDCnxmszUwXvVXV1d3QFdXV2D1ZXkNXc/uN8W0NLS0ltRoj53Qp98wHBir+b8SUl1RW9AX0eH+uoFw6lEU2qC5tbV4f7+3t7erpamsUunDckHtOeO97a3dXd3D9Xc0V5INiQfmExPUt3MGRroVygUExMT09PTTqcTARYALJHGIUlFe5d4KwBEh2+u+mRh/7MhzAFVpQv1ZAHRAIQ/fEohVEISYPX09LS3t7e1tXV2dvb19ZGHrYaGhvr7+3sC+vv7BwcHh4aGBgYGenp6urq6OgW6Hmtvbx8uvGGJ3zSZktDU1NQc0NTU9DCgsbGRf7yLBF7d3d09PT1kqqBUKpVIJP39/d3d3e0B5MqiG5HjR0ZGtFqt2Wx2Op0ej0f89p4FAiwAmC8MDhg5nF9kd7nEWwHCDKIBFlBVulBPFtD7Q/jDpxRC5ZkCrAWP+YVrYCkUioGBAT5L8q9RNTqqVCpHRkYkEsng4ODAwMDw8LA0YGhoqK+vjzxsxevp6SGzBTs6OibSDlniNw1fyyKzEVtbW1taWpqamhobG5ubm0lGxh9PkABLLpfLZLKhoSH/Q1iPdXd3BwdYg4ODIyMjeAILAJYaBgeM4C8uiAj4oLKAqtKFerKA3h8AYDbPFGAtuJPiv4VQr9erVCqpVDo4OCiRSPzLtKvVEwHj4+Ojo6NkIXb/Au0BMplscHCwr6+Pj5/6+voGBgYePZzV3T12+azicnpr/f3W1taOjg7yCBV5oopMThQe75+l2NdHbi0PIK+EXJ9MM+zp6RE+rkW+HlGpVOp0OovFEpwuPSsEWGEBIwPqUFIWUFVGFtyZwWxQUhZQVRZQVbpQTxbQ+7OAqkL4w2/U+ViyAMvtdtvtdpPJpNVqlUqlQqFQqVRardZgMExNTZlMJr1er9FoVAFqtVoToFKp5HL58PAweTKLZE8ymWxkZEQmkw0MDHR1dbW2tra1tXV1dZGl3x+tnNXXR+YhkqxqZGRELpdLJJLh4WGyRaFQjI6OKhQKmUxGJjCSmYzkRv39/fztFAqFRqMxmUw2mw3fQvicQB9GHUrKAtbAYmTBnRnMBiUFAIBwhpEqhD+MpuZjtgBLqVQaDAa73S6MbBZcUpLaOJ1Oi8ViNBonJycnJiZ0Op3JZLJYLDabzWq1ms1mg8EwGaDX641GI/lRrVaPjo6SBIrEXmq1enx8fGxsTC6Xk0WsyEQ/uVyuDFAoFOQBK+Hx4+PjKpWKPNjFZ2TkOkqlkmwnkRa5F4m9lEqlRqMxGAwWi4UsgLX4AItkeQaDwX9xBFghgT6MOpQUIsiC58PDbBY8PgAAAFgCGKnShXqygNHUfMwYYBnSk3TF16cqCqx3i+01Zc575c57Fc57FfHrv5iqKib/fsZW7qgtt9eUWu+WTN8pMlfenqq4ba4stFQVWe+W2KpLbdUl1rvF03cKzZW3A61w+k4R+dFUfstQelNfciPQbhrL8k3ltwIb8yeLrmsKrqrzc8ZvXdHeztMV3zCU5gfaTX0JOeWmoTTfWHbLVF5gKr9lLPPvCjSy0d8CG7/czp+rK/bf0VCabyovmL5TaL1bYq8pddSW89VYaCu315RZ7xZPVRToiq8b0pMQYIUAfudSh5ICRDMMuQAAIJz1K8eah6XirbBQGPmzgNHUfMwYYKEtfUOABQBimEIIEM0wkGUBVaUL9WQB0QCEP3xKIVQQYIVJQ4AFAGIYHDCCKYQQERANsICq0oV6soDeH8IfnmiDUBEGWFKptLu7u729vaura3BwkCxertPp9Hq9wWAwGo37LueOT0wYF8oQoBcgW3jCXTxdELJOlkajUavVZFkrfk2ryclJ8dEBs11qPsi5pAKLRN6jTqfTaDQKhWJwcLCrq4t8W6JUKkWABQBPwBCWEfzFBREBH1QWUFW6UE8W0PsDAMxG9ARWd3d3a0B3d/fg4KBMJlMoFEqlknw54J+veLdvaJj8e8HIOuvEU3cJt/CES63LZDKpVCqTyfgvFhwdHeUP4//9rILPFb3UBSNrzMtkssHBQWG18QTWksLIgDqUlIWLVffi826Jt8Ki4S8u6lBSFq7WNTjdbvFWWBxUlS7UkwU82wIQnTCamg8SYFkslsnJSblc3tPT09ra2tzc3Nra2tXV1dvbOzAwMPjYn/3qrZaOTv7HEBoYGOgP6Husv79/IEB8aPgZGBjo7e3t6uriS93T0yOXyycnJy0WS3CA9f8D7PomAy0T3CMAAAAASUVORK5CYII=";

/* ---------------------------------------------------------------------
   GANTT INTERACTIVO EMBEBIDO — adaptado del export de ClickUp que Jorge
   adjuntó (306 tareas, jerarquía fase→subtarea). Reutilizable: se monta
   en Cronograma (Comité) después del roadmap, y en Cronograma (Equipo
   Técnico). idPrefix mantiene los ids únicos por instancia.
--------------------------------------------------------------------- */
const TREE_TECNICO = [{"id": "86e337efy", "name": "Comunicación oficial en Planificación Estratégica", "tipo": "Tarea", "status": "complete", "start": "2026-06-01", "due": "2026-06-30", "pct": 100, "resp": "Hercilia Vargas", "mile": false, "est": false, "children": []}, {"id": "86e337egp", "name": "Planificación", "tipo": "Tarea", "status": "complete", "start": "2026-07-01", "due": "2026-07-15", "pct": 100, "resp": "Felipe Rioja\nHercilia Vargas", "mile": false, "est": false, "children": []}, {"id": "86e337ehk", "name": "Contratos", "tipo": "Tarea", "status": "in progress", "start": "2026-07-15", "due": "2026-07-31", "pct": 0, "resp": "Hercilia Vargas", "mile": false, "est": false, "children": []}, {"id": "86e337ejz", "name": "1er Upgrade técnico", "tipo": "Tarea", "status": "to do", "start": "2026-07-27", "due": "2026-09-30", "pct": 78.94736842105263, "resp": null, "mile": false, "est": false, "children": [{"id": "86e337fwy", "name": "Definición de ambientes consolidados de EBS", "tipo": "Subtarea", "status": "complete", "start": "2026-07-27", "due": "2026-07-31", "pct": 100, "resp": "Felipe Rioja", "mile": false, "est": false, "children": []}, {"id": "86e337g1p", "name": "Liberación de recursos para TOBOROCHI DESA", "tipo": "Subtarea", "status": "complete", "start": "2026-07-31", "due": "2026-07-31", "pct": 100, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337g39", "name": "Asignación de recursos de los ambientes Oracle KVM EBS-C", "tipo": "Subtarea", "status": "complete", "start": "2026-08-03", "due": "2026-08-03", "pct": 100, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337g0y", "name": "Clonación de servidor PROD -> TOROCHIDESA", "tipo": "Subtarea", "status": "complete", "start": "2026-08-03", "due": "2026-08-03", "pct": 100, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337g52", "name": "Soporte de Infra y Base de Datos", "tipo": "Subtarea", "status": "in progress", "start": "2026-08-03", "due": "2026-09-30", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337fxt", "name": "Evaluación de aplicación de upgrade de base de datos 19.28", "tipo": "Subtarea", "status": "complete", "start": "2026-08-10", "due": "2026-08-12", "pct": 100, "resp": "Felipe Rioja\nBernardo Cuellar\nEdmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e337g2e", "name": "Tareas de Preinstalación", "tipo": "Subtarea", "status": "complete", "start": "2026-08-10", "due": "2026-08-14", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337fyp", "name": "Aplicación de upgrade de base de datos 19.28", "tipo": "Subtarea", "status": "complete", "start": "2026-08-13", "due": "2026-08-13", "pct": 100, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337fzd", "name": "Acceso VPN a consultores", "tipo": "Subtarea", "status": "complete", "start": "2026-08-14", "due": "2026-08-14", "pct": 100, "resp": "Jorge Torres", "mile": false, "est": false, "children": []}, {"id": "86e337fzx", "name": "Upgrade a 12.2.0", "tipo": "Subtarea", "status": "complete", "start": "2026-08-25", "due": "2026-08-31", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": [{"id": "86e34mprj", "name": "rapidwiz binarios R12.2.0", "tipo": "Subtarea", "status": "complete", "start": "2026-08-25", "due": "2026-08-25", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e34mq8u", "name": "preparation CUP14", "tipo": "Subtarea", "status": "complete", "start": "2026-08-26", "due": "2026-08-26", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e34mqhu", "name": "ejecucion de Maintenance Pack", "tipo": "Subtarea", "status": "complete", "start": "2026-08-27", "due": "2026-08-27", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e34mqwh", "name": "rapidwiz de configuración", "tipo": "Subtarea", "status": "complete", "start": "2026-08-28", "due": "2026-08-28", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e34mr1b", "name": "online patching", "tipo": "Subtarea", "status": "complete", "start": "2026-08-31", "due": "2026-08-31", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}]}, {"id": "86e337g5h", "name": "Habilitación de dashboard de accesos VPN", "tipo": "Subtarea", "status": "complete", "start": "2026-09-01", "due": "2026-09-01", "pct": 100, "resp": "Martin Clementi", "mile": false, "est": false, "children": []}, {"id": "86e337g44", "name": "Patcheo tecnológico (AD, TXK, ATG_PF)", "tipo": "Subtarea", "status": "complete", "start": "2026-09-01", "due": "2026-09-01", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337guh", "name": "Upgrade a 12.2.15", "tipo": "Subtarea", "status": "complete", "start": "2026-09-02", "due": "2026-09-09", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337g3n", "name": "Preparación del Stage", "tipo": "Subtarea", "status": "complete", "start": "2026-09-04", "due": "2026-09-23", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": [{"id": "86e337gr0", "name": "Descarga de instaladores del Upgrade", "tipo": "Subtarea", "status": "complete", "start": "2026-08-04", "due": "2026-08-05", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337gra", "name": "Preparación Stage RapidInstall", "tipo": "Subtarea", "status": "complete", "start": "2026-08-17", "due": "2026-08-18", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337grz", "name": "Creación de directorio patcheo y descarga de parches", "tipo": "Subtarea", "status": "complete", "start": "2026-08-19", "due": "2026-08-21", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337gtf", "name": "Patcheo RapidInstall", "tipo": "Subtarea", "status": "complete", "start": "2026-08-24", "due": "2026-08-24", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}]}, {"id": "86e37fycq", "name": "Actualización de Java", "tipo": "Subtarea", "status": "complete", "start": "2026-09-10", "due": "2026-09-17", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337gux", "name": "Patcheo post upgrade", "tipo": "Subtarea", "status": "complete", "start": "2026-09-10", "due": "2026-09-17", "pct": 100, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e337gvx", "name": "Certificación de upgrade", "tipo": "Subtarea", "status": "in progress", "start": "2026-09-18", "due": "2026-09-21", "pct": 0, "resp": "Leonardo Rateni\nGabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337g63", "name": "Actualización sobre cambios en el sistema (capacitación)", "tipo": "Subtarea", "status": "to do", "start": "2026-09-22", "due": "2026-09-30", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e33f68p", "name": "Completar manual de la instalación", "tipo": "Subtarea", "status": "to do", "start": "2026-09-22", "due": "2026-09-30", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}]}, {"id": "86e337ejb", "name": "Kick Off del proyecto", "tipo": "Tarea", "status": "complete", "start": "2026-08-19", "due": "2026-08-19", "pct": 100, "resp": "Hercilia Vargas", "mile": false, "est": false, "children": []}, {"id": "86e337em1", "name": "Análisis de CEMLI's", "tipo": "Tarea", "status": "to do", "start": "2026-09-01", "due": "2026-09-30", "pct": 50, "resp": null, "mile": false, "est": false, "children": [{"id": "86e337g6t", "name": "Inventario actualizado de CEMLI's", "tipo": "Subtarea", "status": "complete", "start": "2026-08-31", "due": "2026-09-04", "pct": 100, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e337g7g", "name": "Asignacion de responsables para CEMLI's", "tipo": "Subtarea", "status": "to do", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e337gz0", "name": "Asignación de Objetos 4CE", "tipo": "Subtarea", "status": "to do", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": "Erick Nava", "mile": false, "est": false, "children": []}, {"id": "86e337gwm", "name": "Asignación de Objetos ARG", "tipo": "Subtarea", "status": "in progress", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e337gwf", "name": "Asignación de Objetos BOL", "tipo": "Subtarea", "status": "in progress", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e337gyg", "name": "Asignación de Objetos EDA", "tipo": "Subtarea", "status": "in progress", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e337gy4", "name": "Asignación de Objetos INT", "tipo": "Subtarea", "status": "to do", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": "Nando Cardenas", "mile": false, "est": false, "children": []}, {"id": "86e337gxd", "name": "Asignación de Objetos MITONE", "tipo": "Subtarea", "status": "to do", "start": "2026-09-07", "due": "2026-09-18", "pct": 0, "resp": "Romel Soliz", "mile": false, "est": false, "children": []}]}]}, {"id": "86e337emu", "name": "Fase de Pruebas Técnicas", "tipo": "Tarea", "status": "to do", "start": "2026-09-21", "due": "2026-12-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e337g81", "name": "Construcción de Script de Pruebas Técnicas", "tipo": "Subtarea", "status": "to do", "start": "2026-09-21", "due": "2026-09-29", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33vtye", "name": "Script de pruebas tecnicas ARG", "tipo": "Subtarea", "status": "to do", "start": "2026-09-21", "due": "2026-09-29", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e33vtc7", "name": "Script de pruebas tecnicas OTC", "tipo": "Subtarea", "status": "to do", "start": "2026-09-21", "due": "2026-09-29", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e33vtpt", "name": "Script de pruebas tecnicas PTP", "tipo": "Subtarea", "status": "to do", "start": "2026-09-21", "due": "2026-09-29", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}]}, {"id": "86e39h74j", "name": "Acompañamiento de Base de Datos", "tipo": "Subtarea", "status": "to do", "start": "2026-10-01", "due": "2026-12-21", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337g9b", "name": "Acompañamiento de Pruebas Técnicas", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e337g8u", "name": "Ejecución de Pruebas Técnicas", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e337gz7", "name": "Flujo Order To Cash BOL", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e337gzp", "name": "Flujo Order to Cash ARG", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e337h09", "name": "Flujo Procure to Pay ARG", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e337gzf", "name": "Flujo Procure to Pay BOL", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}]}, {"id": "86e337g9n", "name": "Registro de Observaciones", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-11-16", "pct": 0, "resp": "Alvaro Andrade", "mile": false, "est": false, "children": []}, {"id": "86e337ep6", "name": "Remediación de las Customs Prioridad 1,2", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34r8qk", "name": "Remediación de Consultas BI", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Jhonny Echeverria", "mile": false, "est": false, "children": []}, {"id": "86e337gd6", "name": "Remediación de Objetos 4CE", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Erick Nava", "mile": false, "est": false, "children": []}, {"id": "86e337gdm", "name": "Remediación de Objetos AGRO", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Victor Diaz", "mile": false, "est": false, "children": []}, {"id": "86e337gbk", "name": "Remediación de Objetos ARG", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e337gap", "name": "Remediación de Objetos COM", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Ronny Villarroel", "mile": false, "est": false, "children": []}, {"id": "86e337gcp", "name": "Remediación de Objetos EDA", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e337gdz", "name": "Remediación de Objetos LOG", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Waly Vargas", "mile": false, "est": false, "children": []}, {"id": "86e337gc6", "name": "Remediación de Objetos MITONE", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Nando Cardenas", "mile": false, "est": false, "children": []}, {"id": "86e337gba", "name": "Remediación de Objetos OTC", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e337gay", "name": "Remediación de Objetos PTP", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}]}, {"id": "86e337ga2", "name": "Resolución de Observaciones Estandar", "tipo": "Subtarea", "status": "to do", "start": "2026-10-05", "due": "2026-12-21", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e342dyr", "name": "Re testeo de Pruebas Técnicas", "tipo": "Subtarea", "status": "to do", "start": "2026-11-16", "due": "2026-12-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e342dz2", "name": "Flujo Order To Cash BOL", "tipo": "Subtarea", "status": "to do", "start": "2026-11-16", "due": "2026-12-21", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e342dzb", "name": "Flujo Order to Cash ARG", "tipo": "Subtarea", "status": "to do", "start": "2026-11-16", "due": "2026-12-21", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e342dzg", "name": "Flujo Procure to Pay ARG", "tipo": "Subtarea", "status": "to do", "start": "2026-11-16", "due": "2026-12-21", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e342dz3", "name": "Flujo Procure to Pay BOL", "tipo": "Subtarea", "status": "to do", "start": "2026-11-16", "due": "2026-12-21", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}]}]}, {"id": "86e37dny4", "name": "Hito - Planificacion completada y Entrega de Upgrade Tecnico R12.2.15", "tipo": "Tarea", "status": "to do", "start": "2026-09-30", "due": "2026-09-30", "pct": 0, "resp": "Edmundo Rigazzi", "mile": true, "est": false, "children": []}, {"id": "86e37v5e1", "name": "Hito - Entrega de Pruebas Técnicas", "tipo": "Tarea", "status": "to do", "start": "2026-12-21", "due": "2026-12-21", "pct": 0, "resp": null, "mile": true, "est": false, "children": []}, {"id": "86e337et6", "name": "CRP1 / Pruebas de flujo", "tipo": "Tarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33fndw", "name": "Acompañamiento Funcional EDA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e33fnuj", "name": "Acompañamiento Funcional MMY", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34t4yf", "name": "Flujo ARG", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": true, "children": []}, {"id": "86e34t4uq", "name": "Flujo OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": true, "children": []}, {"id": "86e34t4v1", "name": "Flujo PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Said Martinez", "mile": false, "est": true, "children": []}]}, {"id": "86e33fm1h", "name": "Pruebas de Unitarias", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33fqd7", "name": "Argentina", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33wjur", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33wk2u", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33wu7m", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33wk0q", "name": "OM", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33wuj4", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33wu87", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}, {"id": "86e33wjwx", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33wumd", "name": "AP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33wuqd", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33x8j0", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33wun5", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33x8nd", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e33x8mz", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}]}, {"id": "86e33fq6t", "name": "Bolivia", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33ftdb", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33ftju", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Grover Arias/Janeth Paredes", "mile": false, "est": false, "children": []}, {"id": "86e33ftp8", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Carlos Rios", "mile": false, "est": false, "children": []}, {"id": "86e33ftj1", "name": "OM Distribución", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}, {"id": "86e33x9k2", "name": "OM Pedido", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e33ftu3", "name": "PO-INV-OPM FAE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Maribel Moron", "mile": false, "est": false, "children": []}, {"id": "86e33ftvm", "name": "PO-INV-OPM FC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Roxana Ajaye", "mile": false, "est": false, "children": []}, {"id": "86e33ftxf", "name": "PO-INV-OPM ULT", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Marco Lizondo", "mile": false, "est": false, "children": []}, {"id": "86e33x97g", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e33fvhn", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Goering Keitel", "mile": false, "est": false, "children": []}, {"id": "86e33fver", "name": "WMS", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}]}, {"id": "86e33ftfr", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e33fzc8", "name": "AP Facturas", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Giovana Caballero", "mile": false, "est": false, "children": []}, {"id": "86e33g1bx", "name": "AP Pagos", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Gisela Cáceres", "mile": false, "est": false, "children": []}, {"id": "86e33fzdq", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Sandra Castedo", "mile": false, "est": false, "children": []}, {"id": "86e33fzhj", "name": "EAM", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Elio Villalobos\nJuan Ayala", "mile": false, "est": false, "children": []}, {"id": "86e33fzfn", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Remberto Dorado", "mile": false, "est": false, "children": []}, {"id": "86e33fzd1", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Harold Cayalo", "mile": false, "est": false, "children": []}, {"id": "86e33fzpr", "name": "IE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Gisela Caceres", "mile": false, "est": false, "children": []}, {"id": "86e33fzb2", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Eusebio Carata", "mile": false, "est": false, "children": []}, {"id": "86e33fza9", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Emilia Laveran", "mile": false, "est": false, "children": []}, {"id": "86e33fzkq", "name": "TR", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-01-08", "pct": 0, "resp": "Viviana Murguia", "mile": false, "est": false, "children": []}]}]}]}, {"id": "86e33fmmj", "name": "Resolución de Observaciones CEMLIs", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34rc3g", "name": "Resolucion de observaciones objetos ARG", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e34rdcy", "name": "Resolución de observaciones Objetos 4CE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Erick Nava", "mile": false, "est": false, "children": []}, {"id": "86e34rc6k", "name": "Resolución de observaciones Objetos AGRO", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Victor Diaz", "mile": false, "est": false, "children": []}, {"id": "86e34rc11", "name": "Resolución de observaciones Objetos COM", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Ronny Villarroel", "mile": false, "est": false, "children": []}, {"id": "86e34rc7r", "name": "Resolución de observaciones Objetos LOG", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Waly Vargas", "mile": false, "est": false, "children": []}, {"id": "86e34rc29", "name": "Resolución de observaciones Objetos OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e34rc1w", "name": "Resolución de observaciones Objetos PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}, {"id": "86e34rc8b", "name": "Resolución de observaciones objetos BI", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Jhonny Echeverria", "mile": false, "est": false, "children": []}, {"id": "86e34rc4g", "name": "Resolución de observaciones objetos EDA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e34rc3x", "name": "Resolución de observaciones objetos MITONE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Nando Cardenas", "mile": false, "est": true, "children": []}]}, {"id": "86e33fmbc", "name": "Resolución de Observaciones Estándar", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e34t557", "name": "Soporte de Base de Datos", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-02-12", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e33fm3w", "name": "Pruebas de Flujo", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34tahx", "name": "Argentina", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34tahz", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34taj2", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taj7", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taj3", "name": "OM", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34tajc", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taj8", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}, {"id": "86e34tahy", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34taj1", "name": "AP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taj6", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taja", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taj0", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34taje", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e34tajd", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}]}, {"id": "86e34t5m7", "name": "Bolivia", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34t5m8", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34t5mp", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Grover Arias/Janeth Paredes", "mile": false, "est": false, "children": []}, {"id": "86e34t5mq", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Carlos Rios", "mile": false, "est": false, "children": []}, {"id": "86e34t5me", "name": "OM Distribución", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}, {"id": "86e34t5mf", "name": "OM Pedido", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e34t5n4", "name": "PO-INV-OPM FAE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Maribel Moron", "mile": false, "est": false, "children": []}, {"id": "86e34t5n5", "name": "PO-INV-OPM FC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Roxana Ajaye", "mile": false, "est": false, "children": []}, {"id": "86e34t5nb", "name": "PO-INV-OPM ULT", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Marco Lizondo", "mile": false, "est": false, "children": []}, {"id": "86e34t5nf", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e34t5ng", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Goering Keitel", "mile": false, "est": false, "children": []}, {"id": "86e34t5nc", "name": "WMS", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}]}, {"id": "86e34t5m9", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34t5mn", "name": "AP Facturas", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Giovana Caballero", "mile": false, "est": false, "children": []}, {"id": "86e34t5md", "name": "AP Pagos", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Gisela Cáceres", "mile": false, "est": false, "children": []}, {"id": "86e34t5n3", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Sandra Castedo", "mile": false, "est": false, "children": []}, {"id": "86e34t5n9", "name": "EAM", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Elio Villalobos\nJuan Ayala", "mile": false, "est": false, "children": []}, {"id": "86e34t5n8", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Remberto Dorado", "mile": false, "est": false, "children": []}, {"id": "86e34t5n1", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Harold Cayalo", "mile": false, "est": false, "children": []}, {"id": "86e34t5ne", "name": "IE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Gisela Caceres", "mile": false, "est": false, "children": []}, {"id": "86e34t5mm", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Eusebio Carata", "mile": false, "est": false, "children": []}, {"id": "86e34t5mc", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Emilia Laveran", "mile": false, "est": false, "children": []}, {"id": "86e34t5nd", "name": "TR", "tipo": "Subtarea", "status": "to do", "start": "2027-01-11", "due": "2027-02-12", "pct": 0, "resp": "Viviana Murguia", "mile": false, "est": false, "children": []}]}]}]}]}, {"id": "86e337eub", "name": "Remediación de las Customs Prioridad 3,4", "tipo": "Tarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e34twwk", "name": "Remediación de Objetos 4CE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Erick Nava", "mile": false, "est": false, "children": []}, {"id": "86e34twu9", "name": "Remediación de Objetos AGRO", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Victor Diaz", "mile": false, "est": false, "children": []}, {"id": "86e34twte", "name": "Remediación de Objetos ARG", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e34twu3", "name": "Remediación de Objetos BI", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Jhonny Echeverria", "mile": false, "est": false, "children": []}, {"id": "86e34twr7", "name": "Remediación de Objetos COM", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Ronny Villarroel", "mile": false, "est": false, "children": []}, {"id": "86e34tww5", "name": "Remediación de Objetos EDA", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e34twvk", "name": "Remediación de Objetos LOG", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Waly Vargas", "mile": false, "est": false, "children": []}, {"id": "86e34twtu", "name": "Remediación de Objetos MITONE", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Nando Cardenas", "mile": false, "est": false, "children": []}, {"id": "86e34twt3", "name": "Remediación de Objetos OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e34twrp", "name": "Remediación de Objetos PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}, {"id": "86e34u119", "name": "Soporte de Infra y Base de Datos", "tipo": "Subtarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-31", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}]}, {"id": "86e34bx1q", "name": "Resolucion de observaciones (2)", "tipo": "Tarea", "status": "to do", "start": "2027-01-04", "due": "2027-03-09", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e337eqy", "name": "2do Upgrade técnico", "tipo": "Tarea", "status": "to do", "start": "2027-02-15", "due": "2027-03-09", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e337gej", "name": "Clonación de Toborochi Desa", "tipo": "Subtarea", "status": "to do", "start": "2027-02-15", "due": "2027-02-15", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e33f5ek", "name": "Soporte de Infra y Base de Datos", "tipo": "Subtarea", "status": "to do", "start": "2027-02-15", "due": "2027-03-09", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337gf2", "name": "Trasladar Toborochi DESA a PANDSOFIATEST", "tipo": "Subtarea", "status": "to do", "start": "2027-02-16", "due": "2027-02-16", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337gfj", "name": "Clonar PROD en el server Toborochi TEST", "tipo": "Subtarea", "status": "to do", "start": "2027-02-17", "due": "2027-02-17", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e337gg0", "name": "Upgrade Tecnico", "tipo": "Subtarea", "status": "to do", "start": "2027-02-18", "due": "2027-03-03", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": [{"id": "86e33f1k4", "name": "Tareas de Preinstalación", "tipo": "Subtarea", "status": "to do", "start": "2027-02-18", "due": "2027-02-19", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f1we", "name": "Preparación del Stage", "tipo": "Subtarea", "status": "to do", "start": "2027-02-22", "due": "2027-02-22", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": [{"id": "86e33f3bz", "name": "Descarga de instaladores del Upgrade", "tipo": "Subtarea", "status": "to do", "start": "2027-02-22", "due": "2027-02-22", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f3hh", "name": "Preparación de Stage RapidInstall", "tipo": "Subtarea", "status": "to do", "start": "2027-02-23", "due": "2027-02-23", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f3rk", "name": "Creación de directorio patcheo y descarga de parches", "tipo": "Subtarea", "status": "to do", "start": "2027-02-24", "due": "2027-02-24", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f3xm", "name": "Patcheo RapidInstall", "tipo": "Subtarea", "status": "to do", "start": "2027-02-25", "due": "2027-02-25", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}]}, {"id": "86e34bjcu", "name": "Upgrade a 12.2.0", "tipo": "Subtarea", "status": "to do", "start": "2027-02-23", "due": "2027-02-25", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f4dx", "name": "Patcheo tecnológico (AD, TXK, ATG_PF)", "tipo": "Subtarea", "status": "to do", "start": "2027-02-26", "due": "2027-02-26", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f4ke", "name": "Upgrade a 12.2.15", "tipo": "Subtarea", "status": "to do", "start": "2027-02-26", "due": "2027-03-02", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f4q4", "name": "Patcheo post upgrade", "tipo": "Subtarea", "status": "to do", "start": "2027-03-03", "due": "2027-03-05", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f527", "name": "Certificación de Upgrade", "tipo": "Subtarea", "status": "to do", "start": "2027-03-08", "due": "2027-03-08", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}, {"id": "86e33f5uq", "name": "Completar manual de la instalación", "tipo": "Subtarea", "status": "to do", "start": "2027-03-09", "due": "2027-03-09", "pct": 0, "resp": "Leonardo Rateni", "mile": false, "est": false, "children": []}]}]}, {"id": "86e37vcyb", "name": "Hito - Entrega CRP1", "tipo": "Tarea", "status": "to do", "start": "2027-03-09", "due": "2027-03-09", "pct": 0, "resp": null, "mile": true, "est": false, "children": []}, {"id": "86e37x0f0", "name": "Hito - Segundo Upgrade Técnico", "tipo": "Tarea", "status": "to do", "start": "2027-03-09", "due": "2027-03-09", "pct": 0, "resp": null, "mile": true, "est": false, "children": []}, {"id": "86e337exg", "name": "Resolución de observaciones (3)", "tipo": "Tarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awg6", "name": "UAT/ Pruebas de flujo", "tipo": "Tarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-12", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awp7", "name": "Acompañamiento Funcional EDA", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e35awpp", "name": "Acompañamiento Funcional MMY", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awqc", "name": "Flujo ARG", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": true, "children": []}, {"id": "86e35awpt", "name": "Flujo OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": true, "children": []}, {"id": "86e35awpu", "name": "Flujo PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Said Martinez", "mile": false, "est": true, "children": []}]}, {"id": "86e35awgb", "name": "Pruebas de Unitarias", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awgk", "name": "Argentina", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awgy", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awhg", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awjf", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awhm", "name": "OM", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awkq", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awjg", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}, {"id": "86e35awgz", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awhv", "name": "AP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awjt", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awjx", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awhx", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awky", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awku", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}]}, {"id": "86e35awgm", "name": "Bolivia", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awh0", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awjj", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Grover Arias/Janeth Paredes", "mile": false, "est": false, "children": []}, {"id": "86e35awjk", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Carlos Rios", "mile": false, "est": false, "children": []}, {"id": "86e35awht", "name": "OM Distribución", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}, {"id": "86e35awhr", "name": "OM Pedido", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e35awkn", "name": "PO-INV-OPM FAE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Maribel Moron", "mile": false, "est": false, "children": []}, {"id": "86e35awkt", "name": "PO-INV-OPM FC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Roxana Ajaye", "mile": false, "est": false, "children": []}, {"id": "86e35awmn", "name": "PO-INV-OPM ULT", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Marco Lizondo", "mile": false, "est": false, "children": []}, {"id": "86e35awnj", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e35awna", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Goering Keitel", "mile": false, "est": false, "children": []}, {"id": "86e35awmv", "name": "WMS", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}]}, {"id": "86e35awh1", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awjr", "name": "AP Facturas", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Giovana Caballero", "mile": false, "est": false, "children": []}, {"id": "86e35awhp", "name": "AP Pagos", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Gisela Cáceres", "mile": false, "est": false, "children": []}, {"id": "86e35awkw", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Sandra Castedo", "mile": false, "est": false, "children": []}, {"id": "86e35awmz", "name": "EAM", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Elio Villalobos\nJuan Ayala", "mile": false, "est": false, "children": []}, {"id": "86e35awmx", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Remberto Dorado", "mile": false, "est": false, "children": []}, {"id": "86e35awkv", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Harold Cayalo", "mile": false, "est": false, "children": []}, {"id": "86e35awnn", "name": "IE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Gisela Caceres", "mile": false, "est": false, "children": []}, {"id": "86e35awjq", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Eusebio Carata", "mile": false, "est": false, "children": []}, {"id": "86e35awhq", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Emilia Laveran", "mile": false, "est": false, "children": []}, {"id": "86e35awnk", "name": "TR", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-03-17", "pct": 0, "resp": "Viviana Murguia", "mile": false, "est": false, "children": []}]}]}]}, {"id": "86e35awp3", "name": "Resolución de Observaciones CEMLIs", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awpk", "name": "Resolucion de observaciones objetos ARG", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Jorge Alanoca", "mile": false, "est": false, "children": []}, {"id": "86e35awqr", "name": "Resolución de observaciones Objetos 4CE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Erick Nava", "mile": false, "est": false, "children": []}, {"id": "86e35awq8", "name": "Resolución de observaciones Objetos AGRO", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Victor Diaz", "mile": false, "est": false, "children": []}, {"id": "86e35awp6", "name": "Resolución de observaciones Objetos COM", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Ronny Villarroel", "mile": false, "est": false, "children": []}, {"id": "86e35awqb", "name": "Resolución de observaciones Objetos LOG", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Waly Vargas", "mile": false, "est": false, "children": []}, {"id": "86e35awpd", "name": "Resolución de observaciones Objetos OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Heymar Arancibia", "mile": false, "est": false, "children": []}, {"id": "86e35awp5", "name": "Resolución de observaciones Objetos PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Said Martinez", "mile": false, "est": false, "children": []}, {"id": "86e35awqp", "name": "Resolución de observaciones objetos BI", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Jhonny Echeverria", "mile": false, "est": false, "children": []}, {"id": "86e35awpv", "name": "Resolución de observaciones objetos EDA", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e35awpr", "name": "Resolución de observaciones objetos MITONE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Nando Cardenas", "mile": false, "est": false, "children": []}]}, {"id": "86e35awp2", "name": "Resolución de Observaciones Estándar", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Edmundo Rigazzi", "mile": false, "est": false, "children": []}, {"id": "86e35awqt", "name": "Soporte de Base de Datos", "tipo": "Subtarea", "status": "to do", "start": "2027-03-11", "due": "2027-04-21", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e35awgc", "name": "Pruebas de Flujo", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awgj", "name": "Argentina", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awgv", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awhk", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awjm", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awhj", "name": "OM", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awkr", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awju", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}, {"id": "86e35awgu", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awhf", "name": "AP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awj8", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awjc", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awhb", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awkb", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}, {"id": "86e35awk9", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": []}]}]}, {"id": "86e35awgh", "name": "Bolivia", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awgw", "name": "OTC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awje", "name": "AR", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Grover Arias/Janeth Paredes", "mile": false, "est": false, "children": []}, {"id": "86e35awjd", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Carlos Rios", "mile": false, "est": false, "children": []}, {"id": "86e35awhh", "name": "OM Distribución", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}, {"id": "86e35awhe", "name": "OM Pedido", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e35awkk", "name": "PO-INV-OPM FAE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Maribel Moron", "mile": false, "est": false, "children": []}, {"id": "86e35awkj", "name": "PO-INV-OPM FC", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Roxana Ajaye", "mile": false, "est": false, "children": []}, {"id": "86e35awmq", "name": "PO-INV-OPM ULT", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Marco Lizondo", "mile": false, "est": false, "children": []}, {"id": "86e35awne", "name": "PV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Evelyn Merida", "mile": false, "est": false, "children": []}, {"id": "86e35awnb", "name": "QP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Goering Keitel", "mile": false, "est": false, "children": []}, {"id": "86e35awmr", "name": "WMS", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Jhonny Espejo", "mile": false, "est": false, "children": []}]}, {"id": "86e35awgx", "name": "PTP", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e35awjw", "name": "AP Facturas", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Giovana Caballero", "mile": false, "est": false, "children": []}, {"id": "86e35awhy", "name": "AP Pagos", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Gisela Cáceres", "mile": false, "est": false, "children": []}, {"id": "86e35awkz", "name": "CE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Sandra Castedo", "mile": false, "est": false, "children": []}, {"id": "86e35awmy", "name": "EAM", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Elio Villalobos\nJuan Ayala", "mile": false, "est": false, "children": []}, {"id": "86e35awmu", "name": "FA", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Remberto Dorado", "mile": false, "est": false, "children": []}, {"id": "86e35awkp", "name": "GL", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Harold Cayalo", "mile": false, "est": false, "children": []}, {"id": "86e35awnm", "name": "IE", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Gisela Caceres", "mile": false, "est": false, "children": []}, {"id": "86e35awjp", "name": "INV", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Eusebio Carata", "mile": false, "est": false, "children": []}, {"id": "86e35awhw", "name": "PO", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Emilia Laveran", "mile": false, "est": false, "children": []}, {"id": "86e35awnh", "name": "TR", "tipo": "Subtarea", "status": "to do", "start": "2027-03-18", "due": "2027-04-21", "pct": 0, "resp": "Viviana Murguia", "mile": false, "est": false, "children": []}]}]}]}]}, {"id": "86e37wuzx", "name": "Hito - Entrega UAT", "tipo": "Tarea", "status": "to do", "start": "2027-04-12", "due": "2027-04-12", "pct": 0, "resp": null, "mile": true, "est": false, "children": []}, {"id": "86e337eyb", "name": "Preparación Go Live", "tipo": "Tarea", "status": "to do", "start": "2027-04-15", "due": "2027-04-30", "pct": 0, "resp": null, "mile": false, "est": false, "children": [{"id": "86e37vuct", "name": "Preparación del Entorno", "tipo": "Subtarea", "status": "to do", "start": "2027-04-15", "due": "2027-04-30", "pct": 0, "resp": "Leonardo Rateni\nGabriela Espinoza", "mile": false, "est": false, "children": []}, {"id": "86e39t99q", "name": "Pase a PROD", "tipo": "Subtarea", "status": "to do", "start": "2027-04-30", "due": "2027-05-01", "pct": 0, "resp": "Leonardo Rateni\nGabriela Espinoza", "mile": false, "est": false, "children": []}]}, {"id": "86e337ezk", "name": "Hito - GO LIVE", "tipo": "Tarea", "status": "to do", "start": "2027-05-01", "due": "2027-05-01", "pct": 0, "resp": null, "mile": true, "est": false, "children": []}, {"id": "86e337f0k", "name": "Hito - Soporte Post Implementación", "tipo": "Tarea", "status": "to do", "start": "2027-05-02", "due": "2027-07-02", "pct": 0, "resp": null, "mile": true, "est": false, "children": [{"id": "86e39tqzb", "name": "Soporte de Base de Datos", "tipo": "Subtarea", "status": "to do", "start": "2027-05-02", "due": "2027-07-02", "pct": 0, "resp": "Gabriela Espinoza", "mile": false, "est": false, "children": []}]}, {"id": "86e37wwhm", "name": "Hito - Cierre de Proyecto", "tipo": "Tarea", "status": "to do", "start": "2027-07-02", "due": "2027-07-02", "pct": 0, "resp": null, "mile": true, "est": false, "children": []}];

function tecStatusVar(n){
  const overdue = n.due && n.status!=="complete" && new Date(n.due+"T00:00:00") < new Date(todayISO()+"T00:00:00");
  if(overdue) return "--rag-red";
  if(n.status==="complete") return "--rag-green";
  if(n.status==="in progress") return "--rag-amber";
  return "--rag-gray";
}
function edtNodeHTML(n, level){
  level = level||0;
  const pct = Math.max(0, Math.min(100, Math.round(n.pct||0)));
  if(!n.children || !n.children.length){
    return `<div class="edttree-task"><span class="tname"><span class="tdot" style="background:var(${tecStatusVar(n)})"></span>${n.name}${n.mile?' ◆':''}</span><span style="color:var(--text-faint);">${fmtDate(n.start)} – ${fmtDate(n.due)}</span><span>${pct}%</span></div>`;
  }
  return `<details class="edttree-phase"${level<1?' open':''}>
    <summary><svg class="arrow" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 6 15 12 9 18"/></svg>
      <span class="edttree-phase-name">${n.name}</span>
      <span class="edttree-phase-meta">${n.children.length} tarea${n.children.length===1?'':'s'} · ${pct}%</span>
    </summary>
    <div class="edttree-body">${n.children.map(c=>edtNodeHTML(c, level+1)).join('')}</div>
  </details>`;
}

function interactiveGanttHTML(id){
  return `
  <div class="ig-wrap" id="${id}-wrap">
    <div class="ig-stats" id="${id}-stats"></div>
    <div class="ig-controls">
      <div class="ig-search">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input id="${id}-search" type="text" placeholder="Buscar tarea o responsable…" autocomplete="off">
      </div>
      <div class="ig-chips" id="${id}-statusChips" role="group" aria-label="Filtrar por estado"></div>
      <div class="ig-btns">
        <button class="ig-btn" id="${id}-expandAll" type="button">Expandir todo</button>
        <button class="ig-btn" id="${id}-collapseAll" type="button">Colapsar todo</button>
      </div>
    </div>
    <div class="ig-legend">
      <span><i class="ig-sw" style="background:var(--rag-gray)"></i>Por hacer</span>
      <span><i class="ig-sw" style="background:var(--rag-amber)"></i>En progreso</span>
      <span><i class="ig-sw" style="background:var(--rag-green)"></i>Completada</span>
      <span><i class="ig-sw" style="background:var(--rag-red)"></i>Atrasada</span>
      <span><i class="ig-sw diamond" style="background:var(--primary)"></i>Hito</span>
      <span><span class="ig-est-flag">~</span>Fecha estimada</span>
    </div>
    <div class="ig-gantt-wrap">
      <div class="ig-gantt-scroll" id="${id}-scrollArea">
        <div class="ig-grid" id="${id}-grid"></div>
      </div>
    </div>
    <div class="hint" style="margin-top:8px;">Datos: exportación de ClickUp (306 tareas). Clic en una fase para expandir sus subtareas, clic en una fila para ver el detalle. <span class="ig-est-flag">~</span> = fecha estimada a partir del rango de la fase (no venía en el export original).</div>
  </div>

  <div class="ig-tooltip" id="${id}-tooltip"></div>

  <div class="ig-modal-backdrop" id="${id}-modalBackdrop">
    <div class="ig-modal-card" id="${id}-modalCard" role="dialog" aria-modal="true">
      <button class="ig-modal-close" id="${id}-modalClose" type="button" aria-label="Cerrar">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg>
      </button>
      <div class="ig-modal-breadcrumb" id="${id}-modalBreadcrumb"></div>
      <h2 class="ig-modal-title" id="${id}-modalTitle"></h2>
      <div class="ig-modal-badges" id="${id}-modalBadges"></div>
      <div class="ig-modal-progress-track"><div class="ig-modal-progress-fill" id="${id}-modalProgressFill"></div></div>
      <div class="ig-modal-progress-label" id="${id}-modalProgressLabel"></div>
      <div class="ig-modal-meta" id="${id}-modalMeta"></div>
      <div class="ig-modal-section-title" id="${id}-modalPeopleTitle">Asignado a</div>
      <div class="ig-modal-people" id="${id}-modalPeople"></div>
    </div>
  </div>`;
}

function mountInteractiveGantt(id){
  const root = document.getElementById(id+"-wrap");
  if(!root) return; // la vista actual no incluye este Gantt

  const PX_PER_DAY = 3.4, LABEL_W = 230, ROW_H = 30;
  const MONTHS_ES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
  const TODAY = todayISO();
  const $ = (suffix)=>document.getElementById(id+"-"+suffix);

  function toDate(s){ return new Date(s+'T00:00:00Z'); }
  function dayNum(s){ return Math.floor(toDate(s).getTime()/86400000); }
  function fmtD(s){ if(!s) return '—'; const d=toDate(s); return String(d.getUTCDate()).padStart(2,'0')+'/'+String(d.getUTCMonth()+1).padStart(2,'0')+'/'+d.getUTCFullYear(); }

  let minDay=Infinity, maxDay=-Infinity;
  (function walk(nodes){ nodes.forEach(n=>{ if(n.start) minDay=Math.min(minDay,dayNum(n.start)); if(n.due) maxDay=Math.max(maxDay,dayNum(n.due)); walk(n.children); }); })(TREE_TECNICO);
  minDay-=5; maxDay+=5;
  const totalDays = maxDay-minDay;
  const TIMELINE_W = Math.max(600, Math.round(totalDays*PX_PER_DAY));
  const todayDay = dayNum(TODAY);
  const todayX = (todayDay-minDay)*PX_PER_DAY;
  function xFor(s){ return (dayNum(s)-minDay)*PX_PER_DAY; }

  root.style.setProperty('--ig-label-w', LABEL_W+'px');
  root.style.setProperty('--ig-timeline-w', TIMELINE_W+'px');

  let leafTotal=0, leafDone=0, leafProg=0, leafTodo=0, phases=0, milestones=0;
  (function walk(nodes){ nodes.forEach(n=>{
    if(n.children.length===0){ leafTotal++; if(n.status==='complete') leafDone++; else if(n.status==='in progress') leafProg++; else leafTodo++; }
    if(n.tipo==='Tarea'){ if(n.mile) milestones++; else phases++; }
    walk(n.children);
  }); })(TREE_TECNICO);
  const pctOverall = leafTotal? Math.round(leafDone/leafTotal*100) : 0;
  $("stats").innerHTML = `<div class="ig-stat"><div class="n">${pctOverall}%</div><div class="l">Avance</div></div>
   <div class="ig-stat"><div class="n">${leafDone}</div><div class="l">Completadas</div></div>
   <div class="ig-stat"><div class="n">${leafProg}</div><div class="l">En progreso</div></div>
   <div class="ig-stat"><div class="n">${leafTodo}</div><div class="l">Por hacer</div></div>`;

  const CHIP_DEFS = [['all','Todas'],['todo','Por hacer'],['progress','En progreso'],['complete','Completadas'],['overdue','Atrasadas']];
  let statusFilter='all';
  const chipsEl = $("statusChips");
  chipsEl.innerHTML='';
  CHIP_DEFS.forEach(([key,label])=>{
    const b=document.createElement('button');
    b.className='ig-chip'; b.type='button'; b.textContent=label; b.setAttribute('aria-pressed', key==='all'?'true':'false');
    b.addEventListener('click', ()=>{
      statusFilter=key;
      matchCache.clear(); // los resultados cacheados eran de otro filtro — si no se limpia, los chips no cambian nada
      [...chipsEl.children].forEach(c=>c.setAttribute('aria-pressed','false'));
      b.setAttribute('aria-pressed','true');
      renderGrid();
    });
    chipsEl.appendChild(b);
  });

  function isOverdue(n){ return n.due && n.status!=='complete' && dayNum(n.due)<todayDay; }
  function matchesStatus(n){
    if(statusFilter==='all') return true;
    if(statusFilter==='overdue') return isOverdue(n);
    if(statusFilter==='todo') return n.status==='to do';
    if(statusFilter==='progress') return n.status==='in progress';
    if(statusFilter==='complete') return n.status==='complete';
    return true;
  }
  let searchQ='';
  function matchesSearch(n){ if(!searchQ) return true; const q=searchQ.toLowerCase(); return n.name.toLowerCase().includes(q) || (n.resp && n.resp.toLowerCase().includes(q)); }
  function nodeMatches(n){ return matchesStatus(n) && matchesSearch(n); }
  const matchCache = new Map();
  function subtreeHasMatch(n){
    if(matchCache.has(n.id)) return matchCache.get(n.id);
    const r = nodeMatches(n) || n.children.some(subtreeHasMatch);
    matchCache.set(n.id, r);
    return r;
  }
  function statusVar(n){ if(isOverdue(n)) return '--rag-red'; if(n.status==='complete') return '--rag-green'; if(n.status==='in progress') return '--rag-amber'; return '--rag-gray'; }
  function statusFillVar(n){ return statusVar(n)+'-tint'; }
  const STATUS_LABEL = {'to do':'Por hacer','in progress':'En progreso','complete':'Completada'};

  const expanded = new Set();
  const parentIds = [];
  (function walk(nodes){ nodes.forEach(n=>{ if(n.children.length) parentIds.push(n.id); walk(n.children); }); })(TREE_TECNICO);

  $("expandAll").onclick = ()=>{ parentIds.forEach(pid=>expanded.add(pid)); renderGrid(); };
  $("collapseAll").onclick = ()=>{ expanded.clear(); renderGrid(); };
  $("search").oninput = (e)=>{ searchQ=e.target.value.trim(); matchCache.clear(); renderGrid(); };

  const tooltip = $("tooltip");
  function showTip(evt, html){ tooltip.innerHTML=html; tooltip.classList.add('show'); moveTip(evt); }
  function moveTip(evt){
    const pad=14; let x=evt.clientX+pad, y=evt.clientY+pad; const tw=260, th=90;
    if(x+tw>window.innerWidth) x=evt.clientX-tw-pad;
    if(y+th>window.innerHeight) y=evt.clientY-th-pad;
    tooltip.style.left=x+'px'; tooltip.style.top=y+'px';
  }
  function hideTip(){ tooltip.classList.remove('show'); }
  function tipHTML(n){
    const dur=(n.start&&n.due)?(dayNum(n.due)-dayNum(n.start)+1):null;
    let rows = `<div class="ig-tt-row">${STATUS_LABEL[n.status]||n.status}${isOverdue(n)?' · Atrasada':''}</div>`;
    rows += `<div class="ig-tt-row">${fmtD(n.start)} – ${fmtD(n.due)}${dur?' · '+dur+' día'+(dur===1?'':'s'):''}</div>`;
    rows += `<div class="ig-tt-row">Avance: ${Math.max(0,Math.min(100,Math.round(n.pct||0)))}%</div>`;
    if(n.resp) rows += `<div class="ig-tt-row">${n.resp.replace(/\n/g, ', ')}</div>`;
    if(n.est) rows += `<div class="ig-tt-row" style="color:var(--rag-amber)">⚠ Fecha estimada — calculada a partir de la fase</div>`;
    return `<b>${n.name}</b>${rows}`;
  }

  const modalBackdrop = $("modalBackdrop");
  const modalCard = $("modalCard");
  let lastFocused=null;
  function parsePeople(resp){ if(!resp) return []; return resp.split(/[\n\/]+/).map(s=>s.trim()).filter(Boolean); }
  function initials(name){ const parts=name.split(/\s+/).filter(Boolean); if(parts.length===1) return parts[0].slice(0,2).toUpperCase(); return (parts[0][0]+parts[parts.length-1][0]).toUpperCase(); }
  function aggregatePeople(node){
    const counts=new Map();
    (function walk(n){ parsePeople(n.resp).forEach(p=>counts.set(p,(counts.get(p)||0)+1)); n.children.forEach(walk); })(node);
    return [...counts.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
  }
  function openModal(n, path){
    lastFocused=document.activeElement;
    const nPct=Math.max(0,Math.min(100,Math.round(n.pct||0)));
    $("modalBreadcrumb").textContent = path && path.length ? path.join(' › ') : (n.tipo==='Tarea' && !path.length ? 'Fase de nivel superior' : '');
    $("modalTitle").textContent = n.name;
    const badges=[];
    badges.push(`<span class="ig-badge"><span class="ig-dot" style="background:var(${statusVar(n)})"></span>${STATUS_LABEL[n.status]||n.status}</span>`);
    if(isOverdue(n)) badges.push(`<span class="ig-badge" style="color:var(--rag-red);border-color:var(--rag-red)">Atrasada</span>`);
    if(n.mile) badges.push(`<span class="ig-badge">◆ Hito</span>`);
    if(n.children.length) badges.push(`<span class="ig-badge">${n.children.length} subtarea${n.children.length===1?'':'s'}</span>`);
    if(n.est) badges.push(`<span class="ig-badge est">~ Fecha estimada</span>`);
    $("modalBadges").innerHTML = badges.join('');
    $("modalProgressFill").style.width = nPct+'%';
    $("modalProgressFill").style.background = `var(${statusVar(n)})`;
    $("modalProgressLabel").textContent = 'Avance: '+nPct+'%';
    const dur=(n.start&&n.due)?(dayNum(n.due)-dayNum(n.start)+1):null;
    const metaItems=[['Inicio',fmtD(n.start)],['Fin',fmtD(n.due)],['Duración', dur?(dur+' día'+(dur===1?'':'s')):'—'],['Fase', path&&path.length?path[path.length-1]:'—']];
    $("modalMeta").innerHTML = metaItems.map(([l,v])=>`<div><div class="ig-mi-l">${l}</div><div class="ig-mi-v">${v}</div></div>`).join('');
    const peopleEl=$("modalPeople"), titleEl=$("modalPeopleTitle");
    const direct=parsePeople(n.resp);
    if(direct.length){
      titleEl.textContent='Asignado a';
      peopleEl.innerHTML = direct.map(p=>`<div class="ig-person"><span class="ig-av">${initials(p)}</span><span class="ig-pname">${p}</span></div>`).join('');
    } else if(n.children.length){
      const agg=aggregatePeople(n);
      if(agg.length){
        titleEl.textContent = `Equipo involucrado (${agg.length}, agregado de las subtareas)`;
        peopleEl.innerHTML = agg.map(([p,c])=>`<div class="ig-person"><span class="ig-av">${initials(p)}</span><span class="ig-pname">${p}</span><span class="ig-pcount">${c} tarea${c===1?'':'s'}</span></div>`).join('');
      } else { titleEl.textContent='Asignado a'; peopleEl.innerHTML=`<div class="ig-none">Sin responsables asignados en esta fase</div>`; }
    } else { titleEl.textContent='Asignado a'; peopleEl.innerHTML=`<div class="ig-none">Sin responsable asignado</div>`; }
    modalBackdrop.classList.add('show');
    $("modalClose").focus();
    document.addEventListener('keydown', onModalKeydown);
  }
  function closeModal(){ modalBackdrop.classList.remove('show'); document.removeEventListener('keydown', onModalKeydown); if(lastFocused && lastFocused.focus) lastFocused.focus(); }
  function onModalKeydown(e){ if(e.key==='Escape') closeModal(); }
  $("modalClose").onclick = closeModal;
  modalBackdrop.onclick = (e)=>{ if(e.target===modalBackdrop) closeModal(); };
  modalCard.onclick = (e)=>e.stopPropagation();

  function buildMonthHeader(){
    const wrap=document.createElement('div');
    wrap.className='ig-head-timeline';
    wrap.style.width=TIMELINE_W+'px';
    let d=new Date(minDay*86400000); d.setUTCDate(1);
    while(dayNum(d.toISOString().slice(0,10))<=maxDay){
      const monthStartDay=Math.max(minDay, dayNum(d.toISOString().slice(0,10)));
      const nextMonth=new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth()+1, 1));
      const monthEndDay=Math.min(maxDay, dayNum(nextMonth.toISOString().slice(0,10)));
      const left=(monthStartDay-minDay)*PX_PER_DAY;
      const width=(monthEndDay-monthStartDay)*PX_PER_DAY;
      const cell=document.createElement('div');
      cell.className='ig-month'; cell.style.left=left+'px'; cell.style.width=Math.max(0,width)+'px';
      const label=MONTHS_ES[d.getUTCMonth()]+' '+d.getUTCFullYear();
      cell.title=label;
      if(width>=44) cell.textContent=label;
      wrap.appendChild(cell);
      d=nextMonth;
    }
    const flag=document.createElement('div');
    flag.className='ig-today-flag'; flag.style.left=todayX+'px'; flag.textContent='Hoy';
    wrap.appendChild(flag);
    return wrap;
  }
  function trackBackground(){
    const stops=[];
    let d=new Date(minDay*86400000); d.setUTCDate(1);
    while(dayNum(d.toISOString().slice(0,10))<=maxDay){
      const day=dayNum(d.toISOString().slice(0,10));
      if(day>=minDay){ const x=(day-minDay)*PX_PER_DAY; stops.push(`transparent ${x}px`,`var(--border-soft) ${x}px`,`var(--border-soft) ${x+1}px`,`transparent ${x+1}px`); }
      d=new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth()+1, 1));
    }
    stops.push(`transparent ${todayX}px`,`var(--rag-red) ${todayX}px`,`var(--rag-red) ${todayX+1.2}px`,`transparent ${todayX+1.2}px`);
    return `background-image: linear-gradient(to right, ${stops.join(',')}); background-repeat:no-repeat;`;
  }
  const trackBgCss = trackBackground();

  function makeRow(n, level, dim, path){
    const row=document.createElement('div');
    row.className='ig-row'+(dim?' dim':'');
    row.style.display='contents';
    const nPct=Math.max(0,Math.min(100,Math.round(n.pct||0)));
    path=path||[];
    const label=document.createElement('div');
    label.className='ig-cell ig-label'+(n.children.length?' parent':'');
    label.innerHTML = `<div class="ig-label-inner" style="padding-left:${10+level*14}px">
      <svg class="ig-chev ${n.children.length?(expanded.has(n.id)?'open':''):'leaf'}" viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="3"><polyline points="9 6 15 12 9 18"/></svg>
      <span class="ig-dot" style="background:var(${statusVar(n)})"></span>
      <span class="ig-name ${n.tipo==='Tarea'?'tarea':''}" title="${n.name.replace(/"/g,'&quot;')}">${n.name}${n.est?' <span class="ig-est-flag" title="Fecha estimada">~</span>':''}</span>
      <span class="ig-pct">${nPct}%</span>
    </div>`;
    const chevEl=label.querySelector('.ig-chev');
    if(n.children.length){
      chevEl.addEventListener('click',(e)=>{ e.stopPropagation(); if(expanded.has(n.id)) expanded.delete(n.id); else expanded.add(n.id); renderGrid(); });
    }
    label.addEventListener('click',(e)=>{ if(e.target===chevEl || chevEl.contains(e.target)) return; openModal(n, path); });

    const track=document.createElement('div');
    track.className='ig-cell ig-track';
    track.style.width=TIMELINE_W+'px';
    track.style.cssText += trackBgCss;

    if(n.start && n.due){
      if(n.mile){
        const dia=document.createElement('div');
        dia.className='ig-milestone'; dia.style.left=xFor(n.due)+'px'; dia.style.background=`var(${statusVar(n)})`;
        dia.addEventListener('mouseenter', e=>showTip(e, tipHTML(n)));
        dia.addEventListener('mousemove', moveTip);
        dia.addEventListener('mouseleave', hideTip);
        dia.addEventListener('click', e=>{ e.stopPropagation(); openModal(n, path); });
        track.appendChild(dia);
      } else {
        const left=xFor(n.start);
        const width=Math.max(6, xFor(n.due)-xFor(n.start)+PX_PER_DAY*0.9);
        const bar=document.createElement('div');
        bar.className='ig-bar'; bar.style.left=left+'px'; bar.style.width=width+'px';
        bar.style.background = `var(${statusFillVar(n)})`;
        bar.style.border = `1px ${n.est?'dashed':'solid'} var(${statusVar(n)})`;
        if(n.est) bar.title='Fecha estimada';
        const fill=document.createElement('div');
        fill.className='ig-fill'; fill.style.width=nPct+'%'; fill.style.background=`var(${statusVar(n)})`;
        bar.appendChild(fill);
        bar.addEventListener('mouseenter', e=>showTip(e, tipHTML(n)));
        bar.addEventListener('mousemove', moveTip);
        bar.addEventListener('mouseleave', hideTip);
        bar.addEventListener('click', e=>{ e.stopPropagation(); openModal(n, path); });
        track.appendChild(bar);
        if(level===0 && width<160){
          const lbl=document.createElement('div');
          lbl.className='ig-bar-label'; lbl.textContent = n.name.length>34? n.name.slice(0,34)+'…' : n.name;
          bar.appendChild(lbl);
        }
      }
    } else {
      const nd=document.createElement('div');
      nd.className='ig-no-dates'; nd.textContent='sin fechas';
      track.appendChild(nd);
    }
    row.appendChild(label); row.appendChild(track);
    return row;
  }

  const gridEl = $("grid");
  function renderGrid(){
    gridEl.innerHTML='';
    gridEl.style.setProperty('--ig-label-w', LABEL_W+'px');
    gridEl.style.setProperty('--ig-timeline-w', TIMELINE_W+'px');
    const headRow=document.createElement('div');
    headRow.className='ig-row ig-head-row'; headRow.style.display='contents';
    const headLabel=document.createElement('div');
    headLabel.className='ig-cell ig-head-label'; headLabel.style.height='38px'; headLabel.textContent='Tarea';
    headRow.appendChild(headLabel); headRow.appendChild(buildMonthHeader());
    gridEl.appendChild(headRow);

    const filterActive = statusFilter!=='all' || !!searchQ;
    let count=0;
    function walk(nodes, level, path){
      nodes.forEach(n=>{
        if(filterActive){
          if(!subtreeHasMatch(n)) return;
          gridEl.appendChild(makeRow(n, level, !nodeMatches(n), path));
          count++;
          walk(n.children, level+1, path.concat(n.name));
        } else {
          gridEl.appendChild(makeRow(n, level, false, path));
          count++;
          if(expanded.has(n.id)) walk(n.children, level+1, path.concat(n.name));
        }
      });
    }
    walk(TREE_TECNICO, 0, []);
    if(count===0){
      const empty=document.createElement('div');
      empty.className='ig-empty-msg'; empty.style.gridColumn='1 / -1'; empty.textContent='No hay tareas que coincidan con el filtro.';
      gridEl.appendChild(empty);
    }
    // Línea vertical de "hoy": una sola línea continua superpuesta a todo
    // el grid (encabezado + filas), para que sea inconfundible dónde
    // estamos parados, se filtre lo que se filtre.
    const todayLine=document.createElement('div');
    todayLine.className='ig-today-line';
    todayLine.style.left = `calc(${LABEL_W}px + ${todayX}px)`;
    todayLine.title = 'Hoy: ' + fmtD(TODAY);
    gridEl.appendChild(todayLine);
  }
  renderGrid();
}

/* ---------------------------------------------------------------------
   7.3.1) GANTT POR PERSONA — mismo dataset de ClickUp (TREE_TECNICO), pero
   aplanado: el usuario elige una persona y ve solo las tareas (hojas del
   árbol) que tiene asignadas, ordenadas por fecha de inicio, con la misma
   línea de "hoy" que el Gantt general.
--------------------------------------------------------------------- */
function pgAllPeople(){
  const set = new Set();
  (function walk(nodes){ nodes.forEach(n=>{
    (n.resp||'').split(/[\n\/]+/).map(s=>s.trim()).filter(Boolean).forEach(p=>set.add(p));
    walk(n.children);
  }); })(TREE_TECNICO);
  return [...set].sort((a,b)=>a.localeCompare(b,'es'));
}
function pgTasksFor(person){
  const out = [];
  (function walk(nodes, path){
    nodes.forEach(n=>{
      if(n.children.length===0){
        const people = (n.resp||'').split(/[\n\/]+/).map(s=>s.trim()).filter(Boolean);
        if(people.includes(person)) out.push({node:n, path:path.slice()});
      }
      walk(n.children, path.concat(n.name));
    });
  })(TREE_TECNICO, []);
  out.sort((a,b)=>{
    const as=a.node.start||'9999', bs=b.node.start||'9999';
    return as<bs?-1:as>bs?1:0;
  });
  return out;
}

function personGanttHTML(id){
  return `
  <div class="ig-wrap" id="${id}-wrap">
    <div class="ig-controls">
      <div class="field" style="min-width:260px;">
        <label style="font-size:11px;color:var(--text-faint);text-transform:uppercase;letter-spacing:.04em;">Persona</label>
        <select id="${id}-personSelect" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid var(--border);background:var(--surface-2);color:var(--text);font-size:13px;margin-top:4px;"></select>
      </div>
    </div>
    <div class="ig-stats" id="${id}-stats"></div>
    <div class="ig-legend">
      <span><i class="ig-sw" style="background:var(--rag-gray)"></i>Por hacer</span>
      <span><i class="ig-sw" style="background:var(--rag-amber)"></i>En progreso</span>
      <span><i class="ig-sw" style="background:var(--rag-green)"></i>Completada</span>
      <span><i class="ig-sw" style="background:var(--rag-red)"></i>Atrasada</span>
    </div>
    <div class="ig-gantt-wrap">
      <div class="ig-gantt-scroll" id="${id}-scrollArea">
        <div class="ig-grid" id="${id}-grid"></div>
      </div>
    </div>
    <div class="hint" style="margin-top:8px;">Mismas 306 tareas del export de ClickUp, filtradas por responsable asignado. Una tarea con varios responsables aparece en el Gantt de cada uno.</div>
  </div>
  <div class="ig-tooltip" id="${id}-tooltip"></div>
  `;
}

function mountPersonGantt(id){
  const root = document.getElementById(id+"-wrap");
  if(!root) return;

  const PX_PER_DAY = 5, LABEL_W = 230;
  const $ = (suffix)=>document.getElementById(id+"-"+suffix);
  function toDate(s){ return new Date(s+'T00:00:00Z'); }
  function dayNum(s){ return Math.floor(toDate(s).getTime()/86400000); }
  function fmtD(s){ if(!s) return '—'; const d=toDate(s); return String(d.getUTCDate()).padStart(2,'0')+'/'+String(d.getUTCMonth()+1).padStart(2,'0')+'/'+d.getUTCFullYear(); }
  const TODAY = todayISO();
  const todayDay = dayNum(TODAY);
  const STATUS_LABEL = {'to do':'Por hacer','in progress':'En progreso','complete':'Completada'};
  function isOverdue(n){ return n.due && n.status!=='complete' && dayNum(n.due)<todayDay; }
  function statusVar(n){ if(isOverdue(n)) return '--rag-red'; if(n.status==='complete') return '--rag-green'; if(n.status==='in progress') return '--rag-amber'; return '--rag-gray'; }

  const people = pgAllPeople();
  const sel = $("personSelect");
  sel.innerHTML = people.map(p=>`<option value="${p.replace(/"/g,'&quot;')}">${p}</option>`).join("");
  if(!people.length){
    $("stats").innerHTML = `<div class="ig-empty-msg">No hay responsables cargados en el export de ClickUp.</div>`;
    return;
  }
  sel.value = people[0];
  sel.addEventListener('change', renderPerson);

  const tooltip = $("tooltip");
  function showTip(evt, html){ tooltip.innerHTML=html; tooltip.classList.add('show'); moveTip(evt); }
  function moveTip(evt){
    const pad=14; let x=evt.clientX+pad, y=evt.clientY+pad; const tw=260, th=90;
    if(x+tw>window.innerWidth) x=evt.clientX-tw-pad;
    if(y+th>window.innerHeight) y=evt.clientY-th-pad;
    tooltip.style.left=x+'px'; tooltip.style.top=y+'px';
  }
  function hideTip(){ tooltip.classList.remove('show'); }

  function renderPerson(){
    const person = sel.value;
    const items = pgTasksFor(person);
    const done = items.filter(it=>it.node.status==='complete').length;
    const prog = items.filter(it=>it.node.status==='in progress').length;
    const late = items.filter(it=>isOverdue(it.node)).length;
    $("stats").innerHTML = `<div class="ig-stat"><div class="n">${items.length}</div><div class="l">Tareas asignadas</div></div>
     <div class="ig-stat"><div class="n">${done}</div><div class="l">Completadas</div></div>
     <div class="ig-stat"><div class="n">${prog}</div><div class="l">En progreso</div></div>
     <div class="ig-stat"><div class="n">${late}</div><div class="l">Atrasadas</div></div>`;

    const gridEl = $("grid");
    gridEl.innerHTML = '';
    if(!items.length){
      gridEl.style.gridTemplateColumns = '1fr';
      gridEl.innerHTML = `<div class="ig-empty-msg">${person} no tiene tareas asignadas en el export de ClickUp.</div>`;
      return;
    }
    let minDay=Infinity, maxDay=-Infinity;
    items.forEach(({node:n})=>{ if(n.start) minDay=Math.min(minDay,dayNum(n.start)); if(n.due) maxDay=Math.max(maxDay,dayNum(n.due)); });
    if(!isFinite(minDay)){ minDay=todayDay-5; maxDay=todayDay+5; }
    minDay-=5; maxDay+=5;
    const TIMELINE_W = Math.max(500, Math.round((maxDay-minDay)*PX_PER_DAY));
    const todayX = (todayDay-minDay)*PX_PER_DAY;
    function xFor(s){ return (dayNum(s)-minDay)*PX_PER_DAY; }

    gridEl.style.gridTemplateColumns = LABEL_W+'px '+TIMELINE_W+'px';
    const headRow=document.createElement('div');
    headRow.className='ig-row ig-head-row'; headRow.style.display='contents';
    const headLabel=document.createElement('div');
    headLabel.className='ig-cell ig-head-label'; headLabel.style.height='34px'; headLabel.textContent='Tarea';
    const headTrack=document.createElement('div');
    headTrack.className='ig-cell'; headTrack.style.height='34px'; headTrack.style.color='var(--text-faint)'; headTrack.style.fontSize='10.5px';
    headTrack.textContent = fmtD(new Date(minDay*86400000).toISOString().slice(0,10))+' — '+fmtD(new Date(maxDay*86400000).toISOString().slice(0,10));
    headRow.appendChild(headLabel); headRow.appendChild(headTrack);
    gridEl.appendChild(headRow);

    items.forEach(({node:n, path})=>{
      const row=document.createElement('div');
      row.style.display='contents';
      const nPct=Math.max(0,Math.min(100,Math.round(n.pct||0)));
      const label=document.createElement('div');
      label.className='ig-cell ig-label';
      label.style.cursor='default';
      label.innerHTML = `<div class="ig-label-inner" style="padding-left:10px;">
        <span class="ig-dot" style="background:var(${statusVar(n)})"></span>
        <span class="ig-name" title="${(path.join(' › ')+' — '+n.name).replace(/"/g,'&quot;')}">${n.name}</span>
        <span class="ig-pct">${nPct}%</span>
      </div>`;
      const track=document.createElement('div');
      track.className='ig-cell ig-track';
      track.style.width=TIMELINE_W+'px';
      if(n.start && n.due){
        const left=xFor(n.start);
        const width=Math.max(6, xFor(n.due)-xFor(n.start)+PX_PER_DAY*0.9);
        const bar=document.createElement('div');
        bar.className='ig-bar'; bar.style.left=left+'px'; bar.style.width=width+'px';
        bar.style.background = `var(${statusVar(n)}-tint)`;
        bar.style.border = `1px ${n.est?'dashed':'solid'} var(${statusVar(n)})`;
        const fill=document.createElement('div');
        fill.className='ig-fill'; fill.style.width=nPct+'%'; fill.style.background=`var(${statusVar(n)})`;
        bar.appendChild(fill);
        bar.addEventListener('mouseenter', e=>showTip(e, `<b>${n.name}</b><div class="ig-tt-row">${path.join(' › ')||'—'}</div><div class="ig-tt-row">${STATUS_LABEL[n.status]||n.status}${isOverdue(n)?' · Atrasada':''}</div><div class="ig-tt-row">${fmtD(n.start)} – ${fmtD(n.due)}</div><div class="ig-tt-row">Avance: ${nPct}%</div>`));
        bar.addEventListener('mousemove', moveTip);
        bar.addEventListener('mouseleave', hideTip);
        track.appendChild(bar);
      } else {
        const nd=document.createElement('div');
        nd.className='ig-no-dates'; nd.textContent='sin fechas';
        track.appendChild(nd);
      }
      row.appendChild(label); row.appendChild(track);
      gridEl.appendChild(row);
    });

    const todayLine=document.createElement('div');
    todayLine.className='ig-today-line';
    todayLine.style.top='34px';
    todayLine.style.left = `calc(${LABEL_W}px + ${todayX}px)`;
    todayLine.title = 'Hoy: '+fmtD(TODAY);
    gridEl.appendChild(todayLine);
  }

  renderPerson();
}

/* ---------------------------------------------------------------------
   7.4) GANTT OPERATIVO (dataset curado del PM) — barras de fecha
   planificada vs. real, línea de "hoy", banderas de atraso por
   porcentaje de la duración planificada, botón para ver el riesgo
   asociado a una tarea atrasada y flechas de dependencia. Las fechas
   reales, dependencias y riesgo asociado sólo se dibujan cuando existen
   en los datos — nunca se inventan (quedan vacías hasta que el PM las
   carga en Backoffice → Cronograma).
--------------------------------------------------------------------- */
const PMG_PX_PER_DAY = 7;
const PMG_LABEL_W = 220;
const PMG_ROW_H = 40;
const PMG_MONTHS_ES = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];

function pmgDayNum(s){ if(!s) return null; const d = new Date(s+"T00:00:00Z"); if(isNaN(d)) return null; return Math.floor(d.getTime()/86400000); }

/* Bandera de atraso: >0.1% hasta 10% de la duración planificada de la
   tarea → amarilla; más de 10% → roja/crítica. El atraso se mide contra
   la fecha real de fin (tareas completadas) o contra hoy (tareas en
   curso/pendientes vencidas). */
function pmgDelayInfo(t){
  const ps = pmgDayNum(t.inicioPlan), pe = pmgDayNum(t.finPlan);
  if(ps===null || pe===null) return null;
  const totalDur = Math.max(1, pe-ps+1);
  let delayDays = 0;
  if(t.estado==="completado"){
    const fr = pmgDayNum(t.finReal);
    if(fr!==null) delayDays = fr-pe;
  } else {
    const td = pmgDayNum(todayISO());
    if(td>pe) delayDays = td-pe;
  }
  if(delayDays<=0) return null;
  const pct = (delayDays/totalDur)*100;
  if(pct<=0.1) return null;
  return { delayDays, pct, level: pct>10 ? "rojo" : "amarillo" };
}
function pmgFlagBadge(info){
  if(!info) return "";
  const label = info.level==="rojo" ? "⚑ Crítico" : "⚑ Atención";
  return `<span class="pmg-flag ${info.level}" title="${info.delayDays} día${info.delayDays===1?"":"s"} de atraso · ${info.pct.toFixed(1)}% de la duración planificada">${label}</span>`;
}
function riskDetailHTML(t){
  const r = STATE.collections.riesgos.find(rk=>rk.codigo===t.riesgoId);
  if(!r) return `<div class="hint">La tarea tiene un código de riesgo asignado (${t.riesgoId}) que no se encuentra en el registro de riesgos.</div>`;
  const lvl = riskLevel(r.probabilidad, r.impacto);
  return `
    <div class="hint" style="margin-bottom:4px;"><span class="code">${r.codigo}</span> ${riskBadge(lvl.tier)} — <b>${r.descripcion}</b></div>
    <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 2px;">JUSTIFICACIÓN DEL ATRASO — PLAN DE MITIGACIÓN</div>
    <div style="font-size:13px;">${r.plan||"Sin plan de mitigación registrado."}</div>
    ${r.impactoNegocio?`<div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 2px;">IMPACTO EN EL NEGOCIO</div><div style="font-size:13px;">${r.impactoNegocio}</div>`:""}
  `;
}

function renderPMGantt(tasks, opts){
  opts = opts || {};
  const withDates = (tasks||[]).filter(t=>t.inicioPlan && t.finPlan);
  if(!withDates.length) return `<div class="hint">Sin tareas con fechas planificadas para graficar.</div>`;
  const todayNum = pmgDayNum(todayISO());
  let minDay = Math.min(todayNum, ...withDates.map(t=>pmgDayNum(t.inicioPlan)));
  let maxDay = Math.max(todayNum, ...withDates.map(t=>pmgDayNum(t.finReal)||pmgDayNum(t.finPlan)));
  minDay -= 5; maxDay += 5;
  const totalW = (maxDay-minDay)*PMG_PX_PER_DAY;
  const critical = computeCriticalPath(withDates);

  let monthsHtml = "";
  let d = new Date(minDay*86400000); d.setUTCDate(1);
  while(Math.floor(d.getTime()/86400000) <= maxDay){
    const cellStart = Math.max(minDay, Math.floor(d.getTime()/86400000));
    const next = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth()+1, 1));
    const cellEnd = Math.min(maxDay, Math.floor(next.getTime()/86400000));
    const left = (cellStart-minDay)*PMG_PX_PER_DAY;
    const width = Math.max(0,(cellEnd-cellStart)*PMG_PX_PER_DAY);
    monthsHtml += `<span class="pmg-month" style="left:${left}px; width:${width}px;">${PMG_MONTHS_ES[d.getUTCMonth()]} ${d.getUTCFullYear()}</span>`;
    d = next;
  }

  const idxByName = new Map(withDates.map((t,i)=>[t.nombre, i]));
  const rowsHtml = withDates.map((t,i)=>{
    const ps = pmgDayNum(t.inicioPlan), pe = pmgDayNum(t.finPlan);
    const planLeft = (ps-minDay)*PMG_PX_PER_DAY, planW = Math.max(6,(pe-ps+1)*PMG_PX_PER_DAY);
    const info = pmgDelayInfo(t);
    let realHtml = "";
    if(t.inicioReal || t.finReal){
      const rs = t.inicioReal ? pmgDayNum(t.inicioReal) : ps;
      const re = t.finReal ? pmgDayNum(t.finReal) : (t.estado!=="completado" ? todayNum : pe);
      const realLeft = (rs-minDay)*PMG_PX_PER_DAY, realW = Math.max(6,(re-rs+1)*PMG_PX_PER_DAY);
      const realColor = info ? (info.level==="rojo"?"var(--rag-red)":"var(--rag-amber)") : "var(--primary)";
      realHtml = `<div class="gantt-real" style="left:${realLeft}px; width:${realW}px; background:${realColor};" title="Real: ${fmtDate(t.inicioReal)} – ${t.finReal?fmtDate(t.finReal):'en curso'}"></div>`;
    }
    let riskBtn = "";
    if(info){
      riskBtn = t.riesgoId
        ? `<button type="button" class="pmg-riskbtn" data-pmgrisk="${t.id}">Ver riesgo asociado</button>`
        : `<span class="pmg-riskbtn muted">Riesgo por asignar</span>`;
    }
    return `<div class="gantt-row${critical.has(t)?' gantt-row--critical':''}${opts.editable?' pmg-editrow':''}" data-pmgtask="${t.id}" style="min-height:${PMG_ROW_H}px;">
      <div class="gantt-label" style="width:${PMG_LABEL_W}px;flex:0 0 ${PMG_LABEL_W}px;">
        <b>${t.nombre}${pmgFlagBadge(info)}</b>
        <span>${t.fase||""}${t.frenteCodigo?' · '+t.frenteCodigo:''}</span>
        ${riskBtn}
      </div>
      <div class="gantt-track" style="width:${totalW}px;">
        <div class="gantt-plan" style="left:${planLeft}px; width:${planW}px;" title="Plan: ${fmtDate(t.inicioPlan)} – ${fmtDate(t.finPlan)}"></div>
        ${realHtml}
      </div>
    </div>`;
  }).join("");

  let arrows = "";
  withDates.forEach((t,i)=>{
    (t.dependencias||[]).forEach(depName=>{
      const j = idxByName.get(depName);
      if(j===undefined || j===i) return;
      const pred = withDates[j];
      const pe2 = pmgDayNum(pred.finPlan);
      const ps2 = pmgDayNum(t.inicioPlan);
      if(pe2===null || ps2===null) return;
      const x1 = PMG_LABEL_W + (pe2-minDay+1)*PMG_PX_PER_DAY;
      const y1 = j*PMG_ROW_H + PMG_ROW_H/2;
      const x2 = PMG_LABEL_W + (ps2-minDay)*PMG_PX_PER_DAY;
      const y2 = i*PMG_ROW_H + PMG_ROW_H/2;
      const midX = (x1+x2)/2;
      arrows += `<path d="M${x1},${y1} C${midX},${y1} ${midX},${y2} ${x2},${y2}" />`;
    });
  });

  const totalHeight = withDates.length*PMG_ROW_H;
  const panelId = opts.panelId || "pmgRiskPanel";
  return `
    <div class="gantt-wrap">
      <div class="gantt" style="min-width:${PMG_LABEL_W+totalW}px;">
        <div class="gantt-months" style="position:relative; height:24px; margin-left:${PMG_LABEL_W}px; width:${totalW}px; padding-left:0;">${monthsHtml}</div>
        <div style="position:relative;">
          ${rowsHtml}
          <div class="gantt-today" style="left:${PMG_LABEL_W+(todayNum-minDay)*PMG_PX_PER_DAY}px; height:${totalHeight}px;" title="Hoy: ${fmtDate(todayISO())}"></div>
          ${arrows ? `<svg style="position:absolute; top:0; left:0; width:${PMG_LABEL_W+totalW}px; height:${totalHeight}px; pointer-events:none;"><defs><marker id="pmgArrow" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L8,4 L0,8 z" fill="var(--text-faint)"/></marker></defs><g fill="none" stroke="var(--text-faint)" stroke-width="1.5" marker-end="url(#pmgArrow)">${arrows}</g></svg>` : ""}
        </div>
      </div>
    </div>
    <div class="legend">
      <span><i style="border:1.5px dashed var(--text-faint); background:none;"></i>Fecha planificada</span>
      <span><i style="background:var(--primary);"></i>Fecha real</span>
      <span><i style="background:var(--rag-amber);"></i>Atraso 0,1%–10% de la duración</span>
      <span><i style="background:var(--rag-red);"></i>Atraso mayor a 10%</span>
      <span><i style="background:var(--accent);width:2px;"></i>Hoy</span>
    </div>
    <div class="pmg-riskpanel" id="${panelId}" hidden></div>
  `;
}

function bindPMGantt(opts){
  opts = opts || {};
  const panelId = opts.panelId || "pmgRiskPanel";
  const panel = document.getElementById(panelId);
  document.querySelectorAll("[data-pmgrisk]").forEach(b=>b.addEventListener("click", (e)=>{
    e.stopPropagation();
    const t = STATE.collections.gantt.find(x=>x.id===b.dataset.pmgrisk);
    if(!panel || !t) return;
    if(!panel.hidden && panel.dataset.task===t.id){ panel.hidden = true; return; }
    panel.innerHTML = riskDetailHTML(t);
    panel.dataset.task = t.id;
    panel.hidden = false;
  }));
  if(opts.editable){
    document.querySelectorAll("[data-pmgtask]").forEach(row=>row.addEventListener("click", (e)=>{
      if(e.target.closest("[data-pmgrisk]")) return;
      editingId = row.dataset.pmgtask;
      renderAdminBody();
      const form = document.getElementById("genForm");
      if(form){ try{ form.scrollIntoView({behavior:"smooth", block:"start"}); }catch(e){} }
    }));
  }
}

function viewCronograma(){
  // Orden secuencial: actividades e hitos entremezclados por fecha, en una sola línea de tiempo.
  const tasks = [...STATE.collections.gantt].sort((a,b)=>new Date(a.inicioPlan||0)-new Date(b.inicioPlan||0));
  const critical = computeCriticalPath(tasks);

  return `
    <div class="section-head">
      <div class="eyebrow">Línea base aprobada</div>
      <h2>Cronograma integrado</h2>
      <p>Roadmap oficial del proyecto, tal como fue aprobado y comunicado. Se reemplaza como imagen cuando cambia la línea base; el detalle operativo día a día (tareas, avance, ruta crítica) se sigue más abajo y en ClickUp.</p>
    </div>
    <div class="card panel">
      <div style="overflow-x:auto;">
        <img src="data:image/png;base64,${ROADMAP_IMG_B64}" alt="Cronograma integrado del proyecto — roadmap oficial" style="display:block; width:100%; min-width:900px; border-radius:10px; border:1px solid var(--border);">
      </div>
    </div>

    <div class="card panel">
      <h3>Gantt operativo — plan vs. real</h3>
      <div class="hint">Barra punteada: fecha planificada. Barra sólida debajo: fecha real (cuando está cargada). Línea vertical: hoy. Las tareas con atraso muestran una bandera (amarilla de 0,1% a 10% de la duración planificada; roja por encima de 10%) y, si tienen un riesgo asociado, un botón para ver su detalle y justificar el atraso.</div>
      ${renderPMGantt(STATE.collections.gantt, {editable:false})}
    </div>

    <div class="card panel">
      <h3>Cronograma detallado (export ClickUp)</h3>
      <div class="hint">Vista interactiva de las 306 tareas del export de ClickUp: buscar, filtrar por estado, expandir/colapsar fases y ver el detalle de cada tarea (fechas, avance, responsables).</div>
      ${interactiveGanttHTML("igc")}
    </div>

    <div class="card panel">
      <h3>Detalle de tareas</h3>
      <div class="hint">Orden secuencial por fecha de inicio. Las filas en rojo están en la ruta crítica.</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Tarea</th><th>Fase</th><th>Inicio plan</th><th>Fin plan</th><th>Avance</th><th>Estado</th><th>Responsable</th><th>Ruta crítica</th></tr></thead>
        <tbody>${tasks.map(t=>`<tr${critical.has(t)?' style="background:var(--flag-red-tint);"':''}>
          <td>${t.nombre}</td><td>${t.fase||""}</td><td>${fmtDate(t.inicioPlan)}</td><td>${fmtDate(t.finPlan)}</td>
          <td>${t.avance||0}%</td><td>${chip(t.estado==='completado'?'verde':t.estado==='en_riesgo'?'rojo':t.estado==='en_curso'?'amarillo':'gris', t.estado?t.estado.replace('_',' '):'')}</td>
          <td>${t.responsable||""}</td>
          <td>${critical.has(t)?'<span class="cp-tag">SÍ</span>':'—'}</td>
        </tr>`).join("")}</tbody>
      </table></div>
    </div>

    <div class="card panel">
      <h3>Riesgos identificados y estrategia de gestión</h3>
      <div class="hint">Riesgos vinculados a la etapa que está en progreso hoy (semáforo verde: ${STATE.collections.frentes.filter(f=>f.semaforo==="verde").map(f=>f.nombre).join(", ")||"ninguna etapa en progreso"}), ordenados por criticidad. El registro completo de riesgos de todos los frentes vive en el Mapa de riesgos.</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Código</th><th>Riesgo</th><th>Nivel</th><th>Estrategia</th><th>Responsable</th><th>Estado</th></tr></thead>
        <tbody>${(()=>{
          const codigosEnProgreso = STATE.collections.frentes.filter(f=>f.semaforo==="verde").map(f=>"F"+f.orden);
          return [...STATE.collections.riesgos].filter(r=>r.frenteCodigo && codigosEnProgreso.includes(r.frenteCodigo));
        })().sort((a,b)=>riskLevel(b.probabilidad,b.impacto).score-riskLevel(a.probabilidad,a.impacto).score).map(r=>{
          const lvl = riskLevel(r.probabilidad,r.impacto);
          return `<tr>
            <td><span class="code">${r.codigo}</span>${r.esTop?' <span class="chip amarillo" style="margin-left:4px;">TOP</span>':''}</td>
            <td style="max-width:300px;">${r.descripcion}</td>
            <td>${riskBadge(lvl.tier)}</td>
            <td>${r.estrategia||""}</td>
            <td>${r.responsable||""}</td>
            <td>${chip(riskEstadoRag(r.estado), riskEstadoLabel(r.estado))}</td>
          </tr>`;
        }).join("") || `<tr><td colspan="6" class="hint">Sin riesgos registrados.</td></tr>`}</tbody>
      </table></div>
    </div>
  `;
}

function viewPresupuesto(){
  const c = STATE.config;
  const contratos = STATE.collections.contratos;
  const totalContratadoContratos = contratos.reduce((s,c2)=>s+(Number(c2.monto)||0),0);
  const totalEjecutadoContratos = contratos.reduce((s,c2)=>s+(Number(c2.montoEjecutado)||0),0);
  // El monto contratado/ejecutado puede fijarse como cifra global en Config
  // (por ahora, antes de tener el desglose por proveedor) — si está definido
  // ahí, tiene prioridad sobre la suma por contrato.
  const contratadoDefinido = c.montoContratado!=null || contratos.some(c2=>c2.monto!=null);
  const ejecutadoDefinido = c.montoEjecutado!=null || contratos.some(c2=>c2.montoEjecutado!=null);
  const totalContratado = c.montoContratado!=null ? c.montoContratado : totalContratadoContratos;
  const totalEjecutado = c.montoEjecutado!=null ? c.montoEjecutado : totalEjecutadoContratos;

  return `
    <div class="section-head">
      <div class="eyebrow">Situación contractual y financiera</div>
      <h2>Presupuesto y contratos</h2>
      <p>El monto contratado y el ejecutado se muestran como cifra global, por ahora, mientras se consolida el desglose por proveedor con Administración (ver supuestos).</p>
    </div>

    <div class="grid kpirow">
      <div class="card kpi"><div class="label">Presupuesto total</div><div class="value" style="font-size:20px;">${c.presupuestoTotal?fmtMoney(c.presupuestoTotal,c.monedaBase):"Por consolidar"}</div><div class="foot">Moneda base: ${c.monedaBase}</div></div>
      <div class="card kpi"><div class="label">Contratado</div><div class="value" style="font-size:20px;">${contratadoDefinido?fmtMoney(totalContratado,c.monedaBase):"Por definir"}</div><div class="foot">Cifra global, por ahora</div></div>
      <div class="card kpi"><div class="label">Ejecutado</div><div class="value" style="font-size:20px;">${ejecutadoDefinido?fmtMoney(totalEjecutado,c.monedaBase):"Por definir"}</div><div class="foot">Avance financiero</div></div>
    </div>

    <div class="card panel">
      <h3>Contratos y proveedores</h3>
      <div class="hint">Alcance por proveedor técnico (según organigrama del Kick Off).</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Proveedor</th><th>Alcance</th><th>Monto</th><th>Modalidad de pago</th><th>Estado</th></tr></thead>
        <tbody>${contratos.map(c2=>`<tr>
          <td><b>${c2.proveedor}</b></td><td style="max-width:340px;">${c2.alcance||""}</td>
          <td>${c2.monto?fmtMoney(c2.monto,STATE.config.monedaBase):"Por definir"}</td>
          <td>${c2.modalidadPago||""}</td>
          <td>${chip(c2.estado==='activo'?'verde':c2.estado==='pendiente_firma'?'rojo':'gris', c2.estado==='pendiente_firma'?'Pendiente de firma':c2.estado==='activo'?'Activo':'Cerrado')}</td>
        </tr>`).join("")}</tbody>
      </table></div>
    </div>
  `;
}

function viewRiesgos(){
  const riesgos = STATE.collections.riesgos;
  const counts = {};
  for(let p=1;p<=3;p++) for(let i=1;i<=3;i++) counts[p+"-"+i]=0;
  riesgos.forEach(r=>{ const k=r.probabilidad+"-"+r.impacto; if(counts[k]!==undefined) counts[k]++; });
  const cellColor = (p,i)=>{ const lvl=riskLevel(p,i); return `background:${riskVar(lvl.tier)};`; };
  const rowsHtml = (r, idPrefix)=>{
    idPrefix = idPrefix || "risk";
    return `<tr class="decisionrow" data-toggle="${idPrefix}-${r.id}">
      <td><span class="code">${r.codigo}</span>${r.esTop?' <span class="chip amarillo" style="margin-left:4px;">TOP</span>':''}</td>
      <td style="max-width:320px;">${r.descripcion}<div class="fcomment" style="font-size:11.5px;color:var(--text-faint);margin-top:3px;"><b>Causa:</b> ${r.disparador||"—"}</div></td>
      <td>${r.categoria||""}</td>
      <td>${r.probabilidad}×${r.impacto}</td>
      <td>${r.estrategia||""}</td>
      <td>${r.responsable||""}</td>
      <td>${chip(riskEstadoRag(r.estado), riskEstadoLabel(r.estado))}</td>
    </tr>
    <tr class="decisiondetail" id="${idPrefix}-${r.id}" hidden>
      <td colspan="7">
        <div class="hint" style="margin-bottom:6px;"><b>Impacto en el negocio:</b> ${r.impactoNegocio||"—"}</div>
        <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 4px;">PLAN DE MITIGACIÓN</div>
        <div style="font-size:13px;">${r.plan||"Sin plan registrado."}</div>
        <div style="display:flex;flex-wrap:wrap;gap:18px;margin-top:10px;font-size:12.5px;color:var(--text-muted);">
          ${r.equipoResponsable?`<div><b>Equipo responsable:</b> ${r.equipoResponsable}</div>`:""}
          ${r.proveedores?`<div><b>Proveedores:</b> ${r.proveedores}</div>`:""}
          ${r.identificadoPor?`<div><b>Identificado por:</b> ${r.identificadoPor}</div>`:""}
          ${r.etapa?`<div><b>Etapa:</b> ${r.etapa}</div>`:""}
          ${r.fechaLimite?`<div><b>Fecha límite:</b> ${fmtDate(r.fechaLimite)}</div>`:""}
        </div>
        ${r.observacionesGSE?`<div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:10px 0 4px;">OBSERVACIONES GSE</div><div style="font-size:13px;">${r.observacionesGSE}</div>`:""}
        ${r.accionObservacion?`<div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:10px 0 4px;">ACCIÓN A LA OBSERVACIÓN</div><div style="font-size:13px;">${r.accionObservacion}</div>`:""}
      </td>
    </tr>`;
  };

  return `
    <div class="section-head">
      <div class="eyebrow">PMBOK · Gestión de riesgos</div>
      <h2>Mapa de riesgos</h2>
      <p>Matriz de calor probabilidad × impacto (escala 1–3) y registro de riesgos agrupado por criticidad: Crítico, Alto, Medio y Bajo. Clic en una fila para ver impacto en el negocio, plan de mitigación completo y observaciones.</p>
    </div>

    <div class="card panel">
      <h3>Matriz de calor (3×3)</h3>
      <div class="hint">Cantidad de riesgos registrados por combinación de probabilidad e impacto.</div>
      <div class="matrix">
        <div class="axis-y">Probabilidad</div>
        ${[3,2,1].map(p=>[1,2,3].map(i=>`<div class="cell" style="${cellColor(p,i)}">${counts[p+"-"+i]}</div>`).join("")).join("")}
        <div></div><div class="axis-x">Bajo</div><div class="axis-x">Medio</div><div class="axis-x">Alto</div>
      </div>
      <div class="legend">
        ${RISK_TIERS.slice().reverse().map(t=>`<span><i style="background:var(--risk-${t.key});"></i>${t.label} (score ≥${t.min})</span>`).join("")}
      </div>
    </div>

    ${(()=>{
      const frentesActivos = STATE.collections.frentes.filter(f=>f.semaforo && f.semaforo!=="gris").map(f=>"F"+f.orden);
      const top10 = riesgos.filter(r=>r.frenteCodigo && frentesActivos.includes(r.frenteCodigo))
        .sort((a,b)=>riskLevel(b.probabilidad,b.impacto).score-riskLevel(a.probabilidad,a.impacto).score)
        .slice(0,10);
      return `
      <div class="card panel">
        <h3>Top 10 — riesgos de los frentes activos</h3>
        <div class="hint">Los 10 riesgos de mayor severidad (probabilidad × impacto) entre los vinculados a frentes con actividad en curso hoy (semáforo distinto de gris: ${frentesActivos.join(", ")||"ninguno"}). Frentes sin riesgo vinculado en la matriz quedan fuera de este listado.</div>
        <div class="tablewrap"><table>
          <thead><tr><th>Código</th><th>Riesgo</th><th>Categoría</th><th>P×I</th><th>Estrategia</th><th>Responsable</th><th>Estado</th></tr></thead>
          <tbody>${top10.map(r=>rowsHtml(r,"risktop")).join("") || `<tr><td colspan="7" class="hint">Ningún riesgo de la matriz está vinculado hoy a un frente activo.</td></tr>`}</tbody>
        </table></div>
      </div>`;
    })()}

    ${RISK_TIERS.map(tier=>{
      const items = riesgos.filter(r=>riskLevel(r.probabilidad,r.impacto).tier===tier.key).sort((a,b)=>riskLevel(b.probabilidad,b.impacto).score-riskLevel(a.probabilidad,a.impacto).score);
      if(!items.length) return "";
      return `
      <div class="card panel">
        <h3 class="risktier-head">${riskBadge(tier.key)} <span>${items.length} riesgo${items.length===1?"":"s"}</span></h3>
        <div class="tablewrap"><table>
          <thead><tr><th>Código</th><th>Riesgo</th><th>Categoría</th><th>P×I</th><th>Estrategia</th><th>Responsable</th><th>Estado</th></tr></thead>
          <tbody>${items.map(rowsHtml).join("")}</tbody>
        </table></div>
      </div>`;
    }).join("") || `<div class="card panel"><div class="hint">Sin riesgos registrados.</div></div>`}
  `;
}

function flagBadge(active){
  return active ? `<span class="flagbadge on" title="Alerta activa — requiere escalación">🚩 Alerta</span>` : `<span class="flagbadge off">Sin alerta</span>`;
}
function updatesLog(arr){
  if(!Array.isArray(arr) || !arr.length) return `<div class="hint">Sin actualizaciones registradas.</div>`;
  const sorted = [...arr].sort((a,b)=>new Date(b.fecha||0)-new Date(a.fecha||0));
  return `<ul class="updateslog">${sorted.map(u=>`<li><span class="ulog-date">${fmtDate(u.fecha)}</span><span class="ulog-autor">${u.autor||"—"}</span><span class="ulog-nota">${u.nota||""}</span></li>`).join("")}</ul>`;
}

function viewProblemas(){
  const items = [...STATE.collections.problemas].sort((a,b)=>{
    const fa = a.alertaRoja?0:1, fb = b.alertaRoja?0:1;
    if(fa!==fb) return fa-fb;
    const order = {abierto:0, en_curso:1, resuelto:2};
    return (order[a.estado]??1) - (order[b.estado]??1);
  });
  const alertCount = items.filter(p=>p.alertaRoja).length;
  return `
    <div class="section-head">
      <div class="eyebrow">Issue log</div>
      <h2>Problemas y bloqueos</h2>
      <p>Situaciones activas que impiden el avance normal y requieren intervención o escalamiento. ${alertCount>0?`<b style="color:var(--flag-red);">${alertCount} con bandera roja activa.</b>`:"Sin alertas de bandera roja activas."} Clic en una fila para ver resolución e historial de actualizaciones.</p>
    </div>
    <div class="card panel">
      <div class="tablewrap"><table>
        <thead><tr><th></th><th>Código</th><th>Descripción</th><th>Responsable</th><th>Escalamiento</th><th>Estado</th></tr></thead>
        <tbody>
          ${items.map(p=>`
            <tr class="decisionrow" data-toggle="prob-${p.id}">
              <td>${flagBadge(p.alertaRoja)}</td>
              <td><span class="code">${p.codigo}</span></td>
              <td style="max-width:280px;">${p.descripcion}</td>
              <td>${p.responsable||""}</td>
              <td>${p.escalamiento||""}</td>
              <td>${chip(p.estado==='resuelto'?'verde':p.estado==='en_curso'?'amarillo':'rojo', p.estado?p.estado.replace('_',' '):'')}</td>
            </tr>
            <tr class="decisiondetail" id="prob-${p.id}" hidden>
              <td colspan="6">
                <div class="hint" style="margin-bottom:6px;"><b>Impacto si no se resuelve:</b> ${p.impacto||"—"}</div>
                <div class="hint" style="margin-bottom:6px;"><b>Decisión / acción requerida:</b> ${p.decisionRequerida||"—"}</div>
                <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 4px;">RESOLUCIÓN</div>
                <div style="font-size:13px;margin-bottom:8px;">${p.resolucion||"Aún sin resolución registrada."}</div>
                <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 4px;">HISTORIAL DE ACTUALIZACIONES</div>
                ${updatesLog(p.actualizaciones)}
              </td>
            </tr>
          `).join("") || `<tr><td colspan="6" class="hint">Sin problemas registrados.</td></tr>`}
        </tbody>
      </table></div>
    </div>
  `;
}

function viewCambios(){
  const items = STATE.collections.cambios;
  return `
    <div class="section-head">
      <div class="eyebrow">Control integrado de cambios (PMBOK)</div>
      <h2>Cambios de alcance, costo o cronograma</h2>
      <p>Toda solicitud de cambio y su impacto evaluado antes de aprobarse.</p>
    </div>
    <div class="card panel">
      <div class="tablewrap"><table>
        <thead><tr><th>Código</th><th>Descripción</th><th>Impacta a</th><th>Análisis de impacto</th><th>Solicitante</th><th>Fecha</th><th>Estado</th></tr></thead>
        <tbody>${items.map(cch=>`<tr>
          <td><span class="code">${cch.codigo}</span></td>
          <td style="max-width:220px;">${cch.descripcion}</td>
          <td>${(cch.tipoImpacto||[]).map(t=>`<span class="chip gris" style="margin:1px;">${t}</span>`).join(" ")}</td>
          <td style="max-width:320px;">${cch.analisis||""}</td>
          <td>${cch.solicitante||""}</td>
          <td>${fmtDate(cch.fechaSolicitud)}</td>
          <td>${chip(cch.estado==='aprobado'?'verde':cch.estado==='rechazado'?'rojo':'amarillo', cch.estado?cch.estado.replace('_',' '):'')}</td>
        </tr>`).join("") || `<tr><td colspan="7" class="hint">Sin cambios registrados.</td></tr>`}</tbody>
      </table></div>
    </div>
  `;
}

function viewDecisiones(){
  const items = [...STATE.collections.decisiones].sort((a,b)=> (a.estado==='pendiente'?0:1) - (b.estado==='pendiente'?0:1));
  return `
    <div class="section-head">
      <div class="eyebrow">Decision log</div>
      <h2>Decisiones requeridas del Comité Ejecutivo</h2>
      <p>Acción a decidir, responsable de la decisión, resultado esperado y estado. Expandir una fila muestra contexto, opciones y recomendación del equipo del proyecto.</p>
    </div>
    <div class="card panel">
      <div class="tablewrap"><table class="decisiontable">
        <thead><tr><th>Código</th><th class="actioncol">Acción</th><th>Responsable</th><th class="expected">Resultado esperado</th><th>Estado</th><th>Límite</th></tr></thead>
        <tbody>
          ${items.map(d=>`
            <tr class="decisionrow" data-toggle="dec-${d.id}">
              <td><span class="code">${d.codigo}</span></td>
              <td class="actioncol">${d.tema}</td>
              <td>${d.responsableDecision||"Comité Ejecutivo"}</td>
              <td class="expected">${d.resultadoEsperado||'<span class="hint">Sin registrar</span>'}</td>
              <td>${chip(d.estado==='tomada'?'verde':'amarillo', d.estado)}</td>
              <td>${fmtDate(d.fechaLimite)}</td>
            </tr>
            <tr class="decisiondetail" id="dec-${d.id}" hidden>
              <td colspan="6">
                <div class="hint" style="margin-bottom:6px;"><b>Contexto:</b> ${d.contexto||"—"}</div>
                ${(d.opciones&&d.opciones.length)?`<div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 4px;">OPCIONES EVALUADAS</div><ul style="margin:0 0 8px;padding-left:18px;font-size:13px;">${d.opciones.map(o=>`<li>${o}</li>`).join("")}</ul>`:""}
                <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 4px;">RECOMENDACIÓN DEL EQUIPO</div>
                <div style="font-size:13px;">${d.recomendacion||"Sin recomendación registrada."}</div>
              </td>
            </tr>
          `).join("") || `<tr><td colspan="6" class="hint">Sin decisiones registradas.</td></tr>`}
        </tbody>
      </table></div>
    </div>
  `;
}

/* Propuesta de pago por hitos a Consultores 4CE (en revisión interna, aún no
   presentada formalmente al Comité — ver Decisión D-03 / contratos.4CE).
   hitoNombre enlaza, cuando corresponde, a un hito real de la colección
   `hitos` para mostrar su fecha; si no hay un hito equivalente todavía
   (los dos primeros entregables no tienen hito propio en el plan), se
   muestra "Por definir" en vez de inventar una fecha. */
const PAGOS_4CE = [
  {entregable:"Inventario de CEMLI's y estimación de tiempos detallados", pct:10, monto:14440, hitoNombre:null},
  {entregable:"Entregables CEMLI'S", pct:30, monto:43320, hitoNombre:null},
  {entregable:"Conclusión UAT", pct:30, monto:43320, hitoNombre:"Cierre UAT"},
  {entregable:"Go Live", pct:20, monto:28880, hitoNombre:"Go-Live"},
  {entregable:"Cierre proyecto", pct:10, monto:14440, hitoNombre:"Cierre de Proyecto"},
];

/* Cronograma de pagos por fase con Consultores EDA — sin montos/porcentajes
   confirmados todavía (contrato con modalidadPago "por definir"), sólo la
   secuencia de fases que dio Jorge. Cada fase se vincula, cuando hay un
   hito equivalente en la colección `hitos`, a su fecha y estado reales;
   si no hay hito equivalente (p.ej. "Soporte Post Implementación", que
   todavía no está en el plan de hitos), se muestra "Por definir" en vez
   de inventar una fecha. */
const PAGOS_EDA = [
  {fase:"Planificación y Primer Upgrade Técnico", hitoNombre:"Cierre 1er Upgrade Técnico"},
  {fase:"Pruebas Técnicas", hitoNombre:"Cierre Ejecución de Pruebas Técnicas"},
  {fase:"CRP1", hitoNombre:"Cierre CRP1 / Pruebas de Flujo"},
  {fase:"Segundo Upgrade Técnico", hitoNombre:"2do Upgrade Técnico"},
  {fase:"UAT", hitoNombre:"Cierre UAT"},
  {fase:"Go Live", hitoNombre:"Go-Live"},
  {fase:"Soporte Post Implementación", hitoNombre:null},
  {fase:"Cierre del proyecto", hitoNombre:"Cierre de Proyecto"},
];

function viewHitos(){
  const items = [...STATE.collections.hitos].sort((a,b)=>new Date(a.fecha)-new Date(b.fecha));
  const today = todayISO();
  return `
    <div class="section-head">
      <div class="eyebrow">Milestone plan</div>
      <h2>Próximos hitos</h2>
      <p>Fechas clave del proyecto, ordenadas cronológicamente.</p>
    </div>
    <div class="card panel">
      <div class="milestonelist">
        ${items.map(h=>{
          const cls = h.estado==='completado' ? 'done' : h.estado==='en_riesgo' ? 'risk' : h.estado==='en_curso' ? 'prog' : '';
          const d = daysBetween(today, h.fecha);
          return `<div class="mrow ${cls}">
            <div class="date">${fmtDate(h.fecha)}</div>
            <div>
              <div style="font-weight:600;font-size:13.5px;">${h.nombre}</div>
              <div style="font-size:12px;color:var(--text-faint);margin-top:2px;">
                ${chip(h.estado==='completado'?'verde':h.estado==='en_riesgo'?'rojo':h.estado==='en_curso'?'celeste':'gris', h.estado==='en_curso'?'en progreso':(h.estado?h.estado.replace('_',' '):''))}
                ${h.estado!=='completado' ? (d>=0?` · en ${d} día(s)`:` · vencido hace ${-d} día(s)`) : ""}
              </div>
            </div>
          </div>`;
        }).join("")}
      </div>
    </div>

    <div class="card panel">
      <h3>Hitos de pago — Consultores 4CE</h3>
      <div class="hint">Propuesta de esquema de pago por hitos, en revisión interna del equipo del proyecto — aún no presentada formalmente al Comité (ver Decisión D-03). Las fechas marcadas "Por definir" corresponden a entregables sin un hito propio todavía en el plan.</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Entregable</th><th>%</th><th>Monto (USD)</th><th>Fecha estimada</th></tr></thead>
        <tbody>${PAGOS_4CE.map(p=>{
          const hito = p.hitoNombre ? STATE.collections.hitos.find(h=>h.nombre===p.hitoNombre) : null;
          const fecha = hito ? fmtDate(hito.fecha) : "Por definir";
          return `<tr>
            <td>${p.entregable}</td>
            <td>${p.pct}%</td>
            <td>${p.monto.toLocaleString('es-BO')}</td>
            <td>${fecha}</td>
          </tr>`;
        }).join("")}
        <tr style="font-weight:600;">
          <td>Total</td>
          <td>100%</td>
          <td>${PAGOS_4CE.reduce((s,p)=>s+p.monto,0).toLocaleString('es-BO')}</td>
          <td></td>
        </tr>
        </tbody>
      </table></div>
    </div>

    <div class="card panel">
      <h3>Cronograma de pagos — Consultores EDA</h3>
      <div class="hint">Secuencia de fases del contrato con Consultores EDA. Modalidad de pago y montos por fase todavía por definir (ver Backoffice → Contratos); las fechas se toman del hito equivalente del plan cuando existe.</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Fase</th><th>Fecha estimada</th><th>Estado</th></tr></thead>
        <tbody>${PAGOS_EDA.map(p=>{
          const hito = p.hitoNombre ? STATE.collections.hitos.find(h=>h.nombre===p.hitoNombre) : null;
          const fecha = hito ? fmtDate(hito.fecha) : "Por definir";
          const estadoChip = hito
            ? chip(hito.estado==='completado'?'verde':hito.estado==='en_riesgo'?'rojo':hito.estado==='en_curso'?'celeste':'gris', hito.estado==='en_curso'?'en progreso':(hito.estado?hito.estado.replace('_',' '):''))
            : chip('gris','por definir');
          return `<tr>
            <td>${p.fase}</td>
            <td>${fecha}</td>
            <td>${estadoChip}</td>
          </tr>`;
        }).join("")}
        </tbody>
      </table></div>
    </div>
  `;
}

function viewMinutas(){
  const items = [...STATE.collections.minutas].sort((a,b)=>new Date(b.fecha)-new Date(a.fecha));
  return `
    <div class="section-head">
      <div class="eyebrow">Trazabilidad de gobierno</div>
      <h2>Bitácora de Comité Ejecutivo</h2>
      <p>Decisiones, acciones y recomendaciones de cada sesión — mantiene la consistencia solicitada por el Comité.</p>
    </div>
    ${items.map((m,idx)=>`
      <details class="acta card" ${idx===0?'open':''}>
        <summary>${fmtDate(m.fecha)} — ${m.tema}<span class="arrow">▸</span></summary>
        <div class="body">
          <div>
            <h5>Decisiones</h5>
            <ul>${(m.decisiones||[]).map(x=>`<li>${x}</li>`).join("")}</ul>
          </div>
          <div>
            <h5>Recomendaciones</h5>
            <ul>${(m.recomendaciones||[]).map(x=>`<li>${x}</li>`).join("")}</ul>
          </div>
          <div style="grid-column:1/-1;">
            <h5>Acciones y compromisos</h5>
            <div class="tablewrap"><table><thead><tr><th>Acción</th><th>Responsable</th><th>Fecha</th></tr></thead>
            <tbody>${(m.acciones||[]).map(a=>`<tr><td>${a.accion}</td><td>${a.responsable}</td><td>${a.fecha}</td></tr>`).join("")}</tbody></table></div>
          </div>
          <div style="grid-column:1/-1; font-size:12px; color:var(--text-faint);">Participantes: ${(m.participantes||[]).join(", ")}</div>
        </div>
      </details>
    `).join("") || `<div class="hint">Sin minutas registradas.</div>`}
  `;
}

/* ---------------------------------------------------------------------
   7) BACKOFFICE
--------------------------------------------------------------------- */

let adminTab = "config";
let editingId = null;

function viewBackoffice(){
  if(!STATE.backofficeUnlocked){
    return `
      <div class="card panel" style="max-width:380px;margin:32px auto 0;">
        <h3>Backoffice protegido</h3>
        <p class="hint">Esta sección tiene una contraseña propia, además del rol elegido al ingresar al tablero.</p>
        <form id="bofPassForm" style="display:flex;flex-direction:column;gap:10px;margin-top:14px;">
          <input type="password" id="bofPassInput" placeholder="Contraseña del backoffice" autocomplete="off" style="padding:10px 12px;border-radius:8px;border:1px solid var(--border);background:var(--surface-2);color:var(--text);font-size:14px;">
          <div id="bofPassError" class="hint" style="color:var(--flag-red);" hidden>Contraseña incorrecta.</div>
          <button class="btn primary" type="submit">Ingresar</button>
        </form>
      </div>
    `;
  }
  if(STATE.offline){
    return `<div class="card noaccess"><h3>Modo demo</h3><p>La capacidad de base de datos no está disponible en esta vista, por lo que el backoffice no puede escribir cambios. Abre este artefacto publicado en claude.ai con permisos de edición para administrar los datos.</p></div>`;
  }
  if(!STATE.isAdmin){
    return `<div class="card noaccess"><h3>Sin permisos de edición</h3><p>Este artefacto está compartido contigo en modo lectura. Pide al propietario (${STATE.config.pmResponsable||"PM del proyecto"}) que te agregue como editor desde el menú de compartir de claude.ai para habilitar el backoffice.</p></div>`;
  }

  const tabs = [
    ["config","Configuración general"],
    ["frentes","Frentes"],
    ["gantt","Cronograma"],
    ["riesgos","Riesgos"],
    ["problemas","Problemas"],
    ["cambios","Cambios"],
    ["decisiones","Decisiones"],
    ["hitos","Hitos"],
    ["contratos","Contratos"],
    ["minutas","Minutas"],
    ["auditoria","Reporte de ediciones"],
  ];

  return `
    <div class="section-head">
      <div class="eyebrow">Backoffice</div>
      <h2>Administración de datos</h2>
      <p>Los cambios se guardan en la base de datos del artefacto y se reflejan en vivo para todos los que lo tengan abierto.</p>
    </div>
    <div class="adminbar">${tabs.map(([id,label])=>`<button class="tab ${adminTab===id?'active':''}" data-atab="${id}">${label}</button>`).join("")}</div>
    <div id="adminBody"></div>
  `;
}

function renderAdminBody(){
  const el = document.getElementById("adminBody");
  if(!el) return;
  if(adminTab==="config"){ el.innerHTML = adminConfigForm(); bindConfigForm(); return; }
  if(adminTab==="gantt"){
    el.innerHTML = `
      <div class="card panel">
        <h3>Gantt operativo (editable)</h3>
        <div class="hint">Misma vista que ve el Comité Ejecutivo en Cronograma, con edición completa. Clic en una tarea para editar todos sus campos —incluyendo Inicio real y Fin real— en el formulario de abajo.</div>
        ${renderPMGantt(STATE.collections.gantt, {editable:true, panelId:"pmgRiskPanelAdmin"})}
      </div>
    ` + adminGanttExtra() + adminGenericSection("gantt");
    bindGenericSection("gantt"); bindCsvImporter(); bindPMGantt({editable:true, panelId:"pmgRiskPanelAdmin"});
    return;
  }
  if(adminTab==="minutas"){ el.innerHTML = adminMinutasExtra() + adminGenericSection("minutas"); bindGenericSection("minutas"); bindActaUploader(); return; }
  if(adminTab==="auditoria"){ el.innerHTML = adminAuditoriaReport(); return; }
  el.innerHTML = adminGenericSection(adminTab);
  bindGenericSection(adminTab);
}

/* Reporte de ediciones (auditoría) — de solo lectura: lista cada alta,
   edición o eliminación hecha desde el backoffice, más reciente primero. */
function adminAuditoriaReport(){
  const COL_LABELS = { frentes:"Frentes", gantt:"Cronograma", riesgos:"Riesgos", problemas:"Problemas", cambios:"Cambios", decisiones:"Decisiones", hitos:"Hitos", contratos:"Contratos", minutas:"Minutas", config:"Configuración general" };
  const TIPO_LABELS = { alta:"Alta", edicion:"Edición", eliminacion:"Eliminación" };
  const rows = clone(STATE.collections.auditoria||[]).sort((a,b)=> new Date(b.fecha||0) - new Date(a.fecha||0));
  const fmtTs = (iso)=>{
    if(!iso) return "—";
    const d = new Date(iso);
    if(isNaN(d.getTime())) return "—";
    return String(d.getDate()).padStart(2,'0')+'/'+String(d.getMonth()+1).padStart(2,'0')+'/'+d.getFullYear()+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
  };
  if(!rows.length){
    return `<div class="card panel"><h3>Reporte de ediciones</h3><p class="hint">Todavía no hay cambios registrados. Cada alta, edición o eliminación hecha desde el backoffice queda aquí automáticamente, con el detalle de qué campos cambiaron.</p></div>`;
  }
  return `
    <div class="card panel">
      <h3>Reporte de ediciones <span style="color:var(--text-faint);font-weight:500;">(${rows.length})</span></h3>
      <p class="hint">Historial de cambios manuales hechos desde el backoffice — más reciente primero. Es de solo lectura.</p>
      <div class="tablewrap" style="max-height:640px;overflow:auto;margin-top:10px;">
        <table>
          <thead><tr><th>Fecha</th><th>Usuario</th><th>Sección</th><th>Tipo</th><th>Cambios</th></tr></thead>
          <tbody>
            ${rows.map(r=>`
              <tr>
                <td style="white-space:nowrap;">${fmtTs(r.fecha)}</td>
                <td>${r.usuario||"—"}</td>
                <td>${COL_LABELS[r.coleccion]||r.coleccion||"—"}</td>
                <td>${TIPO_LABELS[r.tipo]||r.tipo||"—"}</td>
                <td>${(r.cambios||[]).map(c=>`<div><b>${c.campo}</b>: <span style="opacity:.65;">${String(c.anterior)}</span> → ${String(c.nuevo)}</div>`).join("") || "—"}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

/* Lee los valores de un formulario genérico (contenedor con inputs [data-k])
   según el esquema de la colección — usado tanto por el CRUD genérico como
   por la vista previa de actas subidas en PPT. */
function readFormValues(container, schema){
  const data = {};
  container.querySelectorAll("[data-k]").forEach(inp=>{
    const key = inp.dataset.k;
    const fieldDef = schema.fields.find(f=>f.key===key);
    if(!fieldDef) return;
    if(fieldDef.type==="checkbox"){ data[key] = !!inp.checked; return; }
    let v = inp.value;
    if(fieldDef.type==="number") v = v===""?null:Number(v);
    if(fieldDef.type==="select"){
      const opt = fieldDef.options.find(([ov])=>String(ov)===String(v));
      v = opt ? opt[0] : v;
    }
    if(fieldDef.type==="tags") v = v.split("\n").map(s=>s.trim()).filter(Boolean);
    if(fieldDef.type==="actions3") v = v.split("\n").map(s=>s.trim()).filter(Boolean).map(line=>{
      const parts = line.split("|").map(s=>s.trim());
      return { accion:parts[0]||"", responsable:parts[1]||"", fecha:parts[2]||"" };
    });
    if(fieldDef.type==="updates") v = v.split("\n").map(s=>s.trim()).filter(Boolean).map(line=>{
      const parts = line.split("|").map(s=>s.trim());
      return { fecha:parts[0]||"", autor:parts[1]||"", nota:parts[2]||"" };
    });
    data[key] = v;
  });
  return data;
}

function fieldInput(f, val){
  const v = val===undefined||val===null?"":val;
  if(f.type==="select"){
    return `<select data-k="${f.key}">${f.options.map(([ov,ol])=>`<option value="${ov}" ${String(v)===String(ov)?'selected':''}>${ol}</option>`).join("")}</select>`;
  }
  if(f.type==="textline"){
    return `<textarea data-k="${f.key}" rows="2">${v}</textarea>`;
  }
  if(f.type==="tags"){
    const arr = Array.isArray(v)?v.join("\n"):v;
    return `<textarea data-k="${f.key}" data-tags="1" rows="3" placeholder="Uno por línea">${arr}</textarea>`;
  }
  if(f.type==="actions3"){
    const arr = Array.isArray(v) ? v.map(o=>`${o.accion||""} | ${o.responsable||""} | ${o.fecha||""}`).join("\n") : (v||"");
    return `<textarea data-k="${f.key}" data-actions3="1" rows="4" placeholder="Acción | Responsable | Fecha">${arr}</textarea>`;
  }
  if(f.type==="updates"){
    const arr = Array.isArray(v) ? v.map(o=>`${o.fecha||""} | ${o.autor||""} | ${o.nota||""}`).join("\n") : (v||"");
    return `<textarea data-k="${f.key}" data-updates="1" rows="4" placeholder="2026-09-01 | Jorge Torres | Nota de la actualización">${arr}</textarea>`;
  }
  if(f.type==="checkbox"){
    return `<label class="checkboxfield"><input type="checkbox" data-k="${f.key}" data-checkbox="1" ${v===true?"checked":""}><span>${f.label}</span></label>`;
  }
  return `<input data-k="${f.key}" type="${f.type}" value="${v}">`;
}

function colDisplay(val, fieldDef){
  if(fieldDef && fieldDef.type==="checkbox") return val===true ? (fieldDef.key==="alertaRoja"?flagBadge(true):"Sí") : (fieldDef.key==="alertaRoja"?flagBadge(false):"—");
  if(Array.isArray(val)){
    if(!val.length) return "";
    if(typeof val[0]==="object") return `${val.length} registro${val.length===1?"":"s"}`;
    return val.join(", ");
  }
  if(val===null||val===undefined||val==="") return "";
  return val;
}

function adminGenericSection(col){
  const schema = SCHEMAS[col];
  const items = STATE.collections[col]||[];
  const editing = editingId!==null;
  const editItem = editing ? items.find(i=>i.id===editingId) || {} : {};

  return `
    <div class="card formcard" style="margin-bottom:16px;">
      <h3>${editing ? "Editar registro" : "Nuevo registro"}</h3>
      <div class="formgrid" id="genForm">
        ${schema.fields.map(f=>`
          <div class="field ${f.full?'full':''}">
            ${f.type==="checkbox" ? "" : `<label>${f.label}</label>`}
            ${fieldInput(f, editItem[f.key])}
            ${f.hint?`<div class="fhint">${f.hint}</div>`:""}
          </div>
        `).join("")}
      </div>
      <div class="rowactions">
        <button class="btn primary" id="genSave">${editing?"Guardar cambios":"Agregar"}</button>
        ${editing?`<button class="btn ghost" id="genCancel">Cancelar</button>`:""}
      </div>
    </div>
    <div class="card panel">
      <h3>${schema.label} <span style="color:var(--text-faint);font-weight:500;">(${items.length})</span></h3>
      <div class="tablewrap"><table>
        <thead><tr>${schema.cols.map(c=>`<th>${(schema.fields.find(f=>f.key===c)||{}).label||c}</th>`).join("")}<th></th></tr></thead>
        <tbody>${items.map(it=>`<tr>
          ${schema.cols.map(c=>`<td>${colDisplay(it[c], schema.fields.find(f=>f.key===c))}</td>`).join("")}
          <td class="rowactions">
            <button class="btn ghost sm" data-edit="${it.id}">Editar</button>
            <button class="btn danger sm" data-del="${it.id}">Eliminar</button>
          </td>
        </tr>`).join("") || `<tr><td colspan="${schema.cols.length+1}" class="hint">Sin registros.</td></tr>`}</tbody>
      </table></div>
    </div>
  `;
}

function bindGenericSection(col){
  const schema = SCHEMAS[col];
  const save = document.getElementById("genSave");
  const cancel = document.getElementById("genCancel");
  if(save) save.addEventListener("click", async ()=>{
    const data = readFormValues(document.getElementById("genForm"), schema);
    await dbSet(col, editingId, data);
    editingId = null;
    renderAdminBody();
  });
  if(cancel) cancel.addEventListener("click", ()=>{ editingId=null; renderAdminBody(); });
  document.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click", ()=>{ editingId=b.dataset.edit; renderAdminBody(); }));
  document.querySelectorAll("[data-del]").forEach(b=>b.addEventListener("click", async ()=>{
    if(!confirm("¿Eliminar este registro?")) return;
    await dbDelete(col, b.dataset.del);
  }));
}

function adminConfigForm(){
  const c = STATE.config;
  const fields = [
    ["nombreProyecto","Nombre del proyecto","text"],
    ["subtitulo","Subtítulo","text"],
    ["semaforoGeneral","Semáforo general","select",RAG_OPTS],
    ["presupuestoTotal","Presupuesto total","number"],
    ["montoContratado","Monto contratado (cifra global, por ahora)","number"],
    ["montoEjecutado","Monto ejecutado","number"],
    ["monedaBase","Moneda base","select",[["USD","USD"],["BOB","BOB"]]],
    ["fechaInicio","Fecha de inicio","date"],
    ["fechaKickOff","Fecha de Kick Off","date"],
    ["fechaEntregaFinal","Fecha de entrega final (Go-Live)","date"],
    ["fechaCierrePlan","Fecha de cierre plan","date"],
    ["pmResponsable","Project Manager","text"],
    ["patrocinador","Patrocinador","text"],
    ["liderProyecto","Líder de proyecto","text"],
  ];
  const kpiFields = [
    ["avanceFisicoPct","Avance físico global (%)","number"],
    ["avancePlanificadoPct","Avance planificado a hoy (%)","number"],
  ];
  return `
    <div class="card formcard">
      <h3>Configuración general</h3>
      <div class="formgrid" id="cfgForm">
        ${fields.map(([k,label,type,opts])=>`
          <div class="field">
            <label>${label}</label>
            ${type==="select" ? `<select data-k="${k}">${opts.map(([ov,ol])=>`<option value="${ov}" ${String(c[k])===String(ov)?'selected':''}>${ol}</option>`).join("")}</select>` : `<input data-k="${k}" type="${type}" value="${c[k]===null||c[k]===undefined?'':c[k]}">`}
          </div>
        `).join("")}
      </div>
    </div>
    <div class="card formcard">
      <h3>Avance del proyecto (KPIs ejecutivos)</h3>
      <div class="hint" style="margin-bottom:10px;">Estos valores nunca se calculan solos a partir del Gantt (tareas de tamaño muy distinto darían un promedio engañoso) — son la cifra que vos confirmás, en base a tu lectura del avance real. ${staleBadgeHTML(c.fechaActualizacion)}</div>
      <div class="formgrid" id="cfgForm2">
        ${kpiFields.map(([k,label,type])=>`
          <div class="field">
            <label>${label}</label>
            <input data-k="${k}" type="${type}" value="${c[k]===null||c[k]===undefined?'':c[k]}">
          </div>
        `).join("")}
        <div class="field full">
          <label>Desviación de cronograma (frase para el Comité)</label>
          <textarea data-k="desviacionCronograma" rows="2">${c.desviacionCronograma||""}</textarea>
        </div>
        <div class="field full">
          <label>Mensajes clave (uno por línea)</label>
          <textarea data-k="mensajesClave" data-tags="1" rows="5">${(c.mensajesClave||[]).join("\n")}</textarea>
        </div>
      </div>
      <button class="btn primary" id="cfgSave">Guardar configuración</button>
    </div>
  `;
}
function bindConfigForm(){
  document.getElementById("cfgSave").addEventListener("click", async ()=>{
    const data = {};
    document.querySelectorAll("#cfgForm [data-k], #cfgForm2 [data-k]").forEach(inp=>{
      let v = inp.value;
      if(inp.type==="number") v = v===""?null:Number(v);
      if(inp.dataset.tags) v = v.split("\n").map(s=>s.trim()).filter(Boolean);
      data[inp.dataset.k] = v;
    });
    await dbSetConfig(data);
  });
}

function adminGanttExtra(){
  return `
    <div class="card panel">
      <h3>Importar Gantt desde ClickUp (CSV)</h3>
      <div class="hint">Exporta la lista de ClickUp como CSV ("Export" → "CSV") y súbela aquí. Como esta sesión no tiene una conexión en vivo verificada a ClickUp, la importación es manual — evita adivinar nombres de columna reales de tu workspace: revísalos en el paso de mapeo antes de importar.</div>
      <input type="file" id="csvFile" accept=".csv" style="max-width:320px;">
      <div id="csvMapArea" style="margin-top:14px;"></div>
    </div>
  `;
}

function parseCSV(text){
  const rows = text.split(/\r?\n/).filter(r=>r.trim().length);
  return rows.map(r=>{
    const out=[]; let cur=""; let q=false;
    for(let i=0;i<r.length;i++){
      const ch = r[i];
      if(ch==='"'){ q=!q; continue; }
      if(ch===','&&!q){ out.push(cur); cur=""; continue; }
      cur+=ch;
    }
    out.push(cur);
    return out.map(s=>s.trim());
  });
}

function bindCsvImporter(){
  const input = document.getElementById("csvFile");
  if(!input) return;
  input.addEventListener("change", (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const rows = parseCSV(reader.result);
      if(rows.length<2){ toast("El CSV no tiene filas de datos.", true); return; }
      const headers = rows[0];
      const dataRows = rows.slice(1);
      const targets = [["","(no importar)"],["nombre","Tarea / nombre"],["fase","Fase / lista"],["responsable","Responsable"],["inicioPlan","Inicio plan"],["finPlan","Fin plan"],["avance","Avance (%)"],["estado","Estado"],["frenteCodigo","Frente EDT (código F1–F6)"]];
      const guess = (h) => {
        const hl = h.toLowerCase();
        if(hl.includes("task name")||hl.includes("nombre")) return "nombre";
        if(hl.includes("list")||hl.includes("fase")) return "fase";
        if(hl.includes("assignee")||hl.includes("responsable")) return "responsable";
        if(hl.includes("start")) return "inicioPlan";
        if(hl.includes("due")||hl.includes("end")) return "finPlan";
        if(hl.includes("status")||hl.includes("estado")) return "estado";
        return "";
      };
      const mapArea = document.getElementById("csvMapArea");
      mapArea.innerHTML = `
        <div class="hint">${dataRows.length} filas detectadas. Confirma a qué campo corresponde cada columna del CSV antes de importar.</div>
        <div class="tablewrap"><table class="maptable"><thead><tr><th>Columna CSV</th><th>Ejemplo</th><th>Mapear a</th></tr></thead>
        <tbody>${headers.map((h,i)=>`<tr><td>${h}</td><td class="fcomment">${(dataRows[0]&&dataRows[0][i])||""}</td><td><select data-col="${i}">${targets.map(([tv,tl])=>`<option value="${tv}" ${guess(h)===tv?'selected':''}>${tl}</option>`).join("")}</select></td></tr>`).join("")}</tbody>
        </table></div>
        <button class="btn primary sm" id="csvImportBtn" style="margin-top:12px;">Importar ${dataRows.length} tareas</button>
      `;
      document.getElementById("csvImportBtn").addEventListener("click", async ()=>{
        const mapping = {};
        mapArea.querySelectorAll("[data-col]").forEach(sel=>{ if(sel.value) mapping[sel.dataset.col]=sel.value; });
        let count=0;
        for(const row of dataRows){
          const item = {estado:"pendiente", avance:0};
          Object.entries(mapping).forEach(([colIdx,field])=>{
            let v = row[colIdx];
            if(field==="avance") v = Number(String(v).replace(/[^0-9.]/g,""))||0;
            if((field==="inicioPlan"||field==="finPlan") && v){ const d=new Date(v); if(!isNaN(d)) v=d.toISOString().slice(0,10); }
            item[field]=v;
          });
          if(item.nombre){ await dbSet("gantt", null, item); count++; }
        }
        toast(`Importadas ${count} tareas desde ClickUp CSV.`);
        mapArea.innerHTML = "";
        input.value = "";
      });
    };
    reader.readAsText(file);
  });
}

/* ---------------------------------------------------------------------
   ACTAS EN PPT — subir el .pptx de una sesión, extraer su texto, pedirle
   a la IA (capability "sample") que lo reescriba en el formato de la
   plataforma, y dejar que un administrador revise y confirme antes de
   guardar nada en la base de datos compartida.
--------------------------------------------------------------------- */
function adminMinutasExtra(){
  return `
    <div class="card panel">
      <h3>Subir acta de sesión (PowerPoint)</h3>
      <div class="hint">Sube el .pptx del acta o minuta de una sesión. La IA lee el texto de las diapositivas y propone la nueva entrada de bitácora junto con los riesgos, problemas, decisiones, hitos y cambios que detecte — en el mismo formato que ya usa este backoffice. No se guarda nada hasta que revises la propuesta y presiones "Aplicar actualización".</div>
      <input type="file" id="actaFile" accept=".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation" style="max-width:340px;">
      <div id="actaStatus" class="hint" style="margin-top:8px;"></div>
      <div id="actaReviewArea" style="margin-top:14px;"></div>
    </div>
  `;
}

async function extractPptxText(file){
  const buf = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(buf);
  const slideFiles = Object.keys(zip.files)
    .filter(name=>/^ppt\/slides\/slide\d+\.xml$/.test(name))
    .sort((a,b)=>Number(a.match(/slide(\d+)\.xml/)[1]) - Number(b.match(/slide(\d+)\.xml/)[1]));
  const decodeXmlEntities = (s) => s
    .replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"')
    .replace(/&apos;/g,"'").replace(/&amp;/g,"&");
  const parts = [];
  for(const name of slideFiles){
    const xml = await zip.file(name).async("string");
    const texts = [...xml.matchAll(/<a:t>([^<]*)<\/a:t>/g)].map(m=>decodeXmlEntities(m[1])).filter(Boolean);
    if(texts.length) parts.push(`--- Diapositiva ${parts.length+1} ---\n` + texts.join(" "));
  }
  return parts.join("\n\n");
}

function schemaPromptSpec(col){
  return SCHEMAS[col].fields.map(f=>{
    let t = f.type;
    if(f.type==="select") t = "uno de estos valores exactos: " + f.options.map(([ov])=>JSON.stringify(ov)).join(", ");
    if(f.type==="tags") t = "array de strings";
    if(f.type==="actions3") t = "array de objetos {accion, responsable, fecha}";
    if(f.type==="checkbox") t = "boolean";
    return `  - "${f.key}" (${t})`;
  }).join("\n");
}

function buildActaPrompt(actaText){
  return `Eres un asistente de PMO del proyecto Toborochi (upgrade Oracle EBS R12.1.3 → R12.2.15).
Te paso el texto extraído de una presentación de PowerPoint (.pptx) con el acta o minuta de una sesión del Comité o de trabajo.

Tu tarea: leer el texto y reescribirlo en el FORMATO EXACTO de la plataforma (los mismos campos que ya usa su backoffice), proponiendo únicamente los cambios que ese texto realmente respalda. No inventes información que no esté en el texto: si un dato no se puede determinar, usa null (o un array vacío en las listas) en vez de inventarlo.

Contexto actual del proyecto — si el acta se refiere claramente a uno de estos códigos existentes, reutiliza EL MISMO código en tu propuesta para que se actualice ese registro en vez de crear uno duplicado; si es una situación nueva, propone un código nuevo siguiendo el mismo patrón (ej. próximo correlativo):
- Frentes (EDT): ${STATE.collections.frentes.map(f=>`${f.codigo} (${f.nombre})`).join(", ") || "sin datos"}
- Riesgos existentes: ${STATE.collections.riesgos.map(r=>`${r.codigo}: ${r.descripcion}`).join(" | ") || "ninguno registrado"}
- Problemas existentes: ${STATE.collections.problemas.map(p=>`${p.codigo}: ${p.descripcion}`).join(" | ") || "ninguno registrado"}
- Decisiones existentes: ${STATE.collections.decisiones.map(d=>`${d.codigo}: ${d.tema}`).join(" | ") || "ninguna registrada"}
- Cambios existentes: ${STATE.collections.cambios.map(c=>`${c.codigo}: ${c.descripcion}`).join(" | ") || "ninguno registrado"}

Responde ÚNICAMENTE con un objeto JSON (sin texto adicional antes ni después) con esta forma exacta:
{
  "resumen": "1-2 frases resumiendo de qué trata esta acta",
  "minuta": {
${schemaPromptSpec("minutas")}
  },
  "riesgos": [ { ${SCHEMAS.riesgos.fields.map(f=>`"${f.key}"`).join(", ")} } ],
  "problemas": [ { ${SCHEMAS.problemas.fields.map(f=>`"${f.key}"`).join(", ")} } ],
  "decisiones": [ { ${SCHEMAS.decisiones.fields.map(f=>`"${f.key}"`).join(", ")} } ],
  "hitos": [ { ${SCHEMAS.hitos.fields.map(f=>`"${f.key}"`).join(", ")} } ],
  "cambios": [ { ${SCHEMAS.cambios.fields.map(f=>`"${f.key}"`).join(", ")} } ]
}
Especificación de campos por lista (usa exactamente estas claves y tipos):

riesgos:
${schemaPromptSpec("riesgos")}

problemas:
${schemaPromptSpec("problemas")}

decisiones:
${schemaPromptSpec("decisiones")}

hitos:
${schemaPromptSpec("hitos")}

cambios:
${schemaPromptSpec("cambios")}

Si el acta no menciona nada para alguna de estas listas, devuélvela vacía ([]). No agregues campos fuera de los indicados. Todas las fechas en formato AAAA-MM-DD.

--- TEXTO DEL ACTA (extraído del PPTX, por diapositiva) ---
${actaText}
--- FIN DEL TEXTO ---`;
}

function renderActaReview(p){
  p = p || {};
  const minuta = p.minuta || {};
  const cols = ["riesgos","problemas","decisiones","hitos","cambios"];
  const sectionHtml = (col) => {
    const items = Array.isArray(p[col]) ? p[col] : [];
    if(!items.length) return `<div class="hint">Sin cambios propuestos.</div>`;
    const schema = SCHEMAS[col];
    return items.map((it,idx)=>{
      const existing = it && it.codigo ? STATE.collections[col].find(x=>x.codigo===it.codigo) : null;
      return `
      <div class="card formcard acta-proposal" data-col="${col}" data-idx="${idx}" style="margin-bottom:12px;">
        <label class="checkboxfield" style="margin-bottom:8px;">
          <input type="checkbox" class="acta-include" checked><span>Incluir — ${existing?`actualiza <b>${existing.codigo}</b> existente`:'registro nuevo'}</span>
        </label>
        <div class="formgrid">
          ${schema.fields.map(f=>`
            <div class="field ${f.full?'full':''}">
              ${f.type==="checkbox" ? "" : `<label>${f.label}</label>`}
              ${fieldInput(f, it[f.key])}
            </div>
          `).join("")}
        </div>
      </div>`;
    }).join("");
  };

  return `
    ${p.resumen ? `<div class="card panel"><h3>Resumen detectado por la IA</h3><p>${p.resumen}</p></div>` : ""}
    <div class="card formcard" style="margin-bottom:16px;">
      <h3>Nueva entrada de bitácora
        <label class="checkboxfield" style="float:right;font-size:12.5px;">
          <input type="checkbox" id="actaIncludeMinuta" checked><span>Incluir</span>
        </label>
      </h3>
      <div class="formgrid" id="actaMinutaForm">
        ${SCHEMAS.minutas.fields.map(f=>`
          <div class="field ${f.full?'full':''}">
            <label>${f.label}</label>
            ${fieldInput(f, minuta[f.key])}
          </div>
        `).join("")}
      </div>
    </div>
    ${cols.map(col=>`
      <h4 style="margin:18px 0 8px;color:var(--text-muted);text-transform:uppercase;font-size:11.5px;letter-spacing:.06em;">${SCHEMAS[col].label}</h4>
      ${sectionHtml(col)}
    `).join("")}
    <div class="rowactions" style="margin-top:10px;">
      <button class="btn primary" id="actaApplyBtn">Aplicar actualización</button>
      <button class="btn ghost" id="actaDiscardBtn">Descartar</button>
    </div>
  `;
}

function bindActaReview(){
  const discardBtn = document.getElementById("actaDiscardBtn");
  const applyBtn = document.getElementById("actaApplyBtn");
  if(discardBtn) discardBtn.addEventListener("click", ()=>{
    document.getElementById("actaReviewArea").innerHTML = "";
    document.getElementById("actaStatus").textContent = "Propuesta descartada — no se guardó nada.";
    const fileInput = document.getElementById("actaFile");
    if(fileInput) fileInput.value = "";
  });
  if(!applyBtn) return;
  applyBtn.addEventListener("click", async ()=>{
    applyBtn.disabled = true; applyBtn.textContent = "Aplicando…";

    // FASE 1 — leer TODO del DOM primero (a memoria plana). Importante: cada
    // dbSet dispara un re-render en vivo (la base de datos es reactiva) que
    // puede reconstruir #adminBody y borrar el resto de esta vista previa a
    // mitad de camino — por eso no se lee el DOM entre una escritura y otra.
    const pending = [];
    const includeMinuta = document.getElementById("actaIncludeMinuta");
    if(includeMinuta && includeMinuta.checked){
      pending.push({ col:"minutas", id:null, data: readFormValues(document.getElementById("actaMinutaForm"), SCHEMAS.minutas) });
    }
    document.querySelectorAll(".acta-proposal").forEach(card=>{
      const include = card.querySelector(".acta-include");
      if(!include || !include.checked) return;
      const col = card.dataset.col;
      const schema = SCHEMAS[col];
      const data = readFormValues(card, schema);
      const existing = data.codigo ? STATE.collections[col].find(x=>x.codigo===data.codigo) : null;
      pending.push({ col, id: existing ? existing.id : null, data });
    });

    // FASE 2 — escribir, ya sin volver a tocar el DOM de la vista previa.
    for(const w of pending){ await dbSet(w.col, w.id, w.data); }
    await dbSetConfig({}); // refresca fechaActualizacion — se nota en el topbar y en toda la plataforma

    toast(`Acta aplicada: ${pending.length} registro(s) actualizados.`);
    const reviewArea = document.getElementById("actaReviewArea");
    if(reviewArea) reviewArea.innerHTML = "";
    const statusEl = document.getElementById("actaStatus");
    if(statusEl) statusEl.textContent = "Aplicado — los cambios ya están reflejados en el dashboard.";
    const fileInput = document.getElementById("actaFile");
    if(fileInput) fileInput.value = "";
  });
}

function bindActaUploader(){
  const input = document.getElementById("actaFile");
  if(!input) return;
  input.addEventListener("change", async (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const statusEl = document.getElementById("actaStatus");
    const reviewArea = document.getElementById("actaReviewArea");
    reviewArea.innerHTML = "";
    statusEl.textContent = "Leyendo el archivo PPTX…";

    let actaText;
    try{ actaText = await extractPptxText(file); }
    catch(err){ statusEl.textContent = "No se pudo leer el archivo. ¿Es un .pptx válido?"; return; }
    if(!actaText || !actaText.trim()){ statusEl.textContent = "No se encontró texto en las diapositivas de este archivo."; return; }

    statusEl.textContent = "Analizando el acta con IA…";
    let sample = null;
    try{ sample = await window.claude.use("sample"); }catch(err){ sample = null; }
    if(!sample){ statusEl.textContent = "La función de análisis con IA no está disponible en este visor."; return; }

    try{
      const proposal = await sample.json(buildActaPrompt(actaText.slice(0,18000)));
      statusEl.textContent = "Propuesta lista — revisa y ajusta cada campo antes de aplicar. Nada se ha guardado todavía.";
      reviewArea.innerHTML = renderActaReview(proposal);
      bindActaReview();
    }catch(err){
      statusEl.textContent = "No se pudo analizar el acta (" + ((err && err.code) || "error") + "). Puedes intentar de nuevo.";
    }
  });
}

/* ---------------------------------------------------------------------
   8) ROUTER PRINCIPAL
--------------------------------------------------------------------- */

/* ---------------------------------------------------------------------
   7.5) VISTAS — PMO Integrada y Equipo Técnico
   Reutilizan STATE.collections/STATE.config (misma base de datos que el
   Comité) con otro recorte y otra presentación por audiencia.
--------------------------------------------------------------------- */

function frentesActivos(){ return STATE.collections.frentes.filter(f=>f.semaforo && f.semaforo!=="gris"); }

function viewPMOEstado(){
  const c = STATE.config;
  const activos = frentesActivos();
  const hitosEnCurso = [...STATE.collections.hitos].filter(h=>h.estado==="en_curso").sort((a,b)=>new Date(a.fecha)-new Date(b.fecha));
  const diasProyecto = c.fechaEntregaFinal ? daysBetween(todayISO(), c.fechaEntregaFinal) : null;

  return `
    <div class="section-head">
      <div class="eyebrow">PMO Integrada</div>
      <h2>Estado del proyecto</h2>
      <p>Etapas con actividad hoy según el cronograma, % de avance y desviación reportados por el PM, y el conteo de días para cerrar cada etapa activa y el proyecto completo.</p>
    </div>

    <div class="grid kpirow">
      <div class="card kpi"><div class="label">Avance físico global</div><div class="value">${c.avanceFisicoPct??"—"}%</div><div class="foot">Cifra confirmada por el PM (no un promedio de frentes)</div></div>
      <div class="card kpi"><div class="label">Desviación de cronograma</div><div class="value" style="font-size:13.5px;line-height:1.4;font-weight:600;">${c.desviacionCronograma||"Sin dato registrado"}</div></div>
      <div class="card kpi"><div class="label">Días a entrega final</div><div class="value">${diasProyecto!=null?diasProyecto:"—"}</div><div class="foot">${c.fechaEntregaFinal?("Go-Live: "+fmtDate(c.fechaEntregaFinal)):""}</div></div>
    </div>

    <div class="card panel">
      <h3>Etapas activas según cronograma</h3>
      <div class="hint">Frentes de trabajo con semáforo distinto de gris (actividad reportada por el PM), con su avance y el comentario que indica si hay desviación.</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Frente</th><th>Avance</th><th>Semáforo</th><th>Comentario del PM</th></tr></thead>
        <tbody>${activos.map(f=>`<tr>
          <td><b>${f.nombre}</b></td>
          <td>${f.avancePct??0}%</td>
          <td>${chip(f.semaforo, RAG_LABEL[f.semaforo])}</td>
          <td style="max-width:420px;">${f.comentario||"—"}</td>
        </tr>`).join("") || `<tr><td colspan="4" class="hint">Ningún frente tiene actividad reportada hoy.</td></tr>`}</tbody>
      </table></div>
    </div>

    <div class="card panel">
      <h3>Días para finalizar la etapa / el proyecto</h3>
      <div class="hint">Cuenta regresiva a los hitos marcados "en progreso" hoy — son los que tienen una fecha de cierre de etapa vigente — y al cierre del proyecto.</div>
      <div class="tablewrap"><table>
        <thead><tr><th>Etapa / hito</th><th>Fecha</th><th>Días restantes</th></tr></thead>
        <tbody>
          ${hitosEnCurso.map(h=>{
            const dias = daysBetween(todayISO(), h.fecha);
            return `<tr><td>${h.nombre}</td><td>${fmtDate(h.fecha)}</td><td>${dias>=0?dias+" días":("Vencido hace "+Math.abs(dias)+" días")}</td></tr>`;
          }).join("") || `<tr><td colspan="3" class="hint">Ningún hito está marcado "en progreso" hoy — ver Próximos hitos para el resto del plan.</td></tr>`}
          <tr style="border-top:2px solid var(--border);"><td><b>Cierre del proyecto (Go-Live)</b></td><td>${c.fechaEntregaFinal?fmtDate(c.fechaEntregaFinal):"—"}</td><td><b>${diasProyecto!=null?diasProyecto+" días":"—"}</b></td></tr>
        </tbody>
      </table></div>
    </div>
  `;
}

const DOMINIOS_PMBOK = [
  {key:"interesados", num:1, nombre:"Interesados", status:"pending",
    desc:"Se enfoca en identificar, analizar y mantener una comunicación y participación activa con todas las personas u organizaciones afectadas por el proyecto.",
    sources:[{label:"marcocalle.com — Qué es el PMBOK 7: principios y dominios",url:"https://marcocalle.com/que-es-el-pmbok-7-principios-y-dominios-explicados/"},{label:"LinkedIn — Los 8 dominios de desempeño (Valio SpA)",url:"https://es.linkedin.com/pulse/los-8-dominios-de-desempe%C3%B1o-del-proyecto-la-gu%C3%ADa-pmbok7-valio-spa"}],
    modelos:[{n:"Matriz de poder / interés (Mendelow)",d:"Clasifica a cada interesado según su influencia y su interés, para decidir el nivel de comunicación que necesita."},{n:"Registro de interesados",d:"Listado vivo con rol, expectativas, canal de comunicación preferido y nivel de involucramiento actual."}]},
  {key:"equipo", num:2, nombre:"Equipo", status:"pending",
    desc:"Busca crear un entorno de trabajo colaborativo y un equipo de alto rendimiento, fomentando el liderazgo servicial y la cultura de apoyo mutuo.",
    sources:[{label:"Studocu — Dominio de desempeño del equipo (PMBOK 7a ed.)",url:"https://www.studocu.com/es-mx/document/universidad-autonoma-de-san-luis-potosi/principios-de-administracion/dominio-de-desempeno-del-equipo-pmbok-7a-edicion/152275152"},{label:"LinkedIn — Los 8 dominios de desempeño (Valio SpA)",url:"https://es.linkedin.com/pulse/los-8-dominios-de-desempe%C3%B1o-del-proyecto-la-gu%C3%ADa-pmbok7-valio-spa"}],
    modelos:[{n:"Modelo de Tuckman",d:"Ubica al equipo en su etapa de formación (formación, conflicto, normalización, desempeño) para ajustar el estilo de liderazgo."},{n:"Team Charter + RACI",d:"Acuerdo de funcionamiento del equipo y matriz de responsabilidades por rol/frente."}]},
  {key:"enfoque", num:3, nombre:"Enfoque de desarrollo y ciclo de vida", status:"pending",
    desc:"Define la estrategia general del proyecto, decidiendo si se usará un enfoque predictivo (en cascada), ágil o híbrido.",
    sources:[{label:"LinkedIn — Los 8 dominios de desempeño (Valio SpA)",url:"https://es.linkedin.com/pulse/los-8-dominios-de-desempe%C3%B1o-del-proyecto-la-gu%C3%ADa-pmbok7-valio-spa"},{label:"YouTube — 8 dominios de desempeño PMBOK 7",url:"https://www.youtube.com/watch?v=8zoUOwJnzGA&t=124"}],
    modelos:[{n:"Comparación predictivo / ágil / híbrido",d:"Justifica el enfoque elegido para Toborochi (hoy, predictivo por fases de upgrade) frente a las alternativas."},{n:"Cono de incertidumbre",d:"Muestra cómo se va reduciendo el margen de error de las estimaciones a medida que avanza cada etapa."}]},
  {key:"planificacion", num:4, nombre:"Planificación", status:"pending",
    desc:"Organiza las acciones, estimaciones y coordinaciones necesarias para estructurar cómo se entregarán los objetivos del proyecto.",
    sources:[{label:"LinkedIn — Los 8 dominios de desempeño (Valio SpA)",url:"https://es.linkedin.com/pulse/los-8-dominios-de-desempe%C3%B1o-del-proyecto-la-gu%C3%ADa-pmbok7-valio-spa"},{label:"YouTube — 8 dominios de desempeño PMBOK 7",url:"https://www.youtube.com/watch?v=8zoUOwJnzGA&t=124"}],
    modelos:[{n:"Rolling wave planning",d:"Planifica en detalle la etapa próxima y a grueso nivel las etapas lejanas, refinando a medida que se acercan."},{n:"Estimación PERT (3 puntos)",d:"Estima duración con escenario optimista/probable/pesimista para las tareas con mayor incertidumbre."}]},
  {key:"trabajo", num:5, nombre:"Trabajo del proyecto", status:"pending",
    desc:"Se encarga de ejecutar las tareas, gestionar los recursos físicos, mantener los procesos funcionando y asegurar el flujo de trabajo.",
    sources:[{label:"LinkedIn — Los 8 dominios de desempeño (Valio SpA)",url:"https://es.linkedin.com/pulse/los-8-dominios-de-desempe%C3%B1o-del-proyecto-la-gu%C3%ADa-pmbok7-valio-spa"},{label:"YouTube — 8 dominios de desempeño PMBOK 7",url:"https://www.youtube.com/watch?v=8zoUOwJnzGA&t=124"}],
    modelos:[{n:"Tablero Kanban de flujo",d:"Visualiza el trabajo en curso por frente técnico y detecta cuellos de botella."},{n:"Gestión de impedimentos",d:"Registro simple de bloqueos operativos del día a día, distinto del log de Problemas y bloqueos del Comité."}]},
  {key:"entrega", num:6, nombre:"Entrega", status:"pending",
    desc:"Se concentra en cumplir con los requisitos de alcance y calidad, asegurando que el proyecto entregue los beneficios y resultados esperados.",
    sources:[{label:"modoproyecto.com — Los 8 performance domain de PMBOK7",url:"https://modoproyecto.com/los-8-performance-domain-de-pmbok7/"},{label:"YouTube — 8 dominios de desempeño PMBOK 7",url:"https://www.youtube.com/watch?v=8zoUOwJnzGA&t=124"}],
    modelos:[{n:"Burn-up de alcance",d:"Compara el alcance completado contra el alcance total, mostrando si el alcance total también está creciendo."},{n:"Definition of Done + trazabilidad de requisitos",d:"Criterios de aceptación por entregable y matriz que los vincula con el requisito de origen."}]},
  {key:"medicion", num:7, nombre:"Medición", status:"pending",
    desc:"Evalúa el desempeño actual del proyecto mediante métricas para comparar lo planificado frente a la ejecución real y tomar decisiones de mejora.",
    sources:[{label:"YouTube — 8 dominios de desempeño PMBOK 7",url:"https://www.youtube.com/watch?v=8zoUOwJnzGA&t=124"},{label:"modoproyecto.com — Los 8 performance domain de PMBOK7",url:"https://modoproyecto.com/los-8-performance-domain-de-pmbok7/"}],
    modelos:[{n:"EVM (curva S) + SPI",d:"Ya implementado parcialmente en Estructura del proyecto (EDT): curva S global y por frente. Este dominio consolidaría el tablero de métricas."},{n:"Control charts / tablero de KPIs",d:"Serie histórica de los indicadores clave del proyecto, no sólo la foto de hoy."}]},
  {key:"incertidumbre", num:8, nombre:"Incertidumbre", status:"live",
    desc:"Identifica y gestiona los riesgos, ambigüedades y amenazas, así como las oportunidades que surgen durante el proyecto.",
    sources:[],
    modelos:[{n:"Matriz de riesgos — ya implementada",d:"97 riesgos con matriz de calor probabilidad × impacto, ya cargados y editables. Ver el detalle completo abajo."},{n:"Registro de supuestos",d:"Lista aparte de hipótesis de planificación no verificadas (distinta del registro de riesgos)."},{n:"Análisis Monte Carlo",d:"Si se necesita cuantificar la probabilidad de cumplir una fecha, a partir de rangos de duración por tarea."}]},
];

function viewPMODominios(){
  return `
    <div class="section-head">
      <div class="eyebrow">PMBOK 7 · PMO Integrada</div>
      <h2>8 Dominios de desempeño</h2>
      <p>Marco de PMBOK 7 aplicado a Toborochi. Por ahora es un esqueleto: 7 de los 8 dominios están pendientes de que definamos juntos, dominio por dominio, qué datos vamos a usar y qué modelo o teoría aplicar antes de mostrar algo. El dominio de Incertidumbre ya tiene datos reales (la matriz de 97 riesgos del Comité).</p>
    </div>
    <div class="domain-grid">
      ${DOMINIOS_PMBOK.map(d=>`
        <button class="domain-card" type="button" data-route="pmo-dominio:${d.key}">
          <div class="domain-num">Dominio ${d.num}/8</div>
          <div class="domain-name">${d.nombre}</div>
          <div class="domain-desc">${d.desc}</div>
          <div class="domain-status ${d.status}">${d.status==="live"?"Con datos reales":"Pendiente de datos"}</div>
        </button>
      `).join("")}
    </div>
  `;
}

function viewPMODominioDetalle(key){
  const d = DOMINIOS_PMBOK.find(x=>x.key===key);
  if(!d){
    return `<button class="backlink" data-route="pmo-dominios">&larr; Volver a los 8 dominios</button><div class="card panel"><div class="hint">Dominio no encontrado.</div></div>`;
  }
  return `
    <button class="backlink" data-route="pmo-dominios">&larr; Volver a los 8 dominios</button>
    <div class="section-head">
      <div class="domain-detail-head">
        <div>
          <div class="eyebrow">Dominio ${d.num}/8 · PMBOK 7</div>
          <h2>${d.nombre}</h2>
        </div>
        <div class="domain-status ${d.status}" style="margin-top:4px;">${d.status==="live"?"Con datos reales":"Pendiente de datos"}</div>
      </div>
      <p>${d.desc}</p>
      ${d.sources.length?`<div class="domain-sources">Fuente${d.sources.length===1?"":"s"}: ${d.sources.map((s,i)=>`<a href="${s.url}" target="_blank" rel="noopener">[${i+1}] ${s.label}</a>`).join(" · ")}</div>`:""}
    </div>

    ${d.status==="live" ? `
    <div class="card panel">
      <h3>Ya implementado con datos reales</h3>
      <div class="hint">La gestión de riesgos e incertidumbre del proyecto ya vive en el Mapa de riesgos del Comité: 97 riesgos, matriz de calor, Top 10 de frentes activos y registro completo con plan de mitigación. Esta vista lo reutiliza en vez de duplicar los datos.</div>
      <button class="btn primary" data-route="riesgos" type="button" style="margin-top:6px;">Ver el mapa de riesgos completo</button>
    </div>
    ` : `
    <div class="pending-box">
      Todavía no tenemos datos cargados para este dominio.<br>
      Decime qué información querés usar (por ejemplo, para Interesados: quiénes son y su nivel de interés/poder) y qué modelo de los de abajo preferís aplicar — o si querés uno distinto — y lo armamos en el próximo paso.
    </div>
    `}

    <div class="card panel">
      <h3>Modelos y teorías sugeridos para este dominio</h3>
      <div class="hint">Son sugerencias sobre las que decidir juntos — no se aplicó ninguna todavía.</div>
      <div class="model-list">
        ${d.modelos.map(m=>`<div class="model-item"><b>${m.n}</b><p>${m.d}</p></div>`).join("")}
      </div>
    </div>
  `;
}

/* -------------------- Equipo Técnico -------------------- */

function viewTecResumen(){
  const c = STATE.config;
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico · Mamayatech</div>
      <h2>Datos generales del proyecto</h2>
      <p>Información general de Toborochi para el equipo técnico. El detalle operativo día a día está en Cronograma, EDT gráfico y Riesgos del equipo técnico.</p>
    </div>
    <div class="card panel">
      <h3>Proyecto</h3>
      <div class="tablewrap"><table>
        <tbody>
          <tr><td style="width:220px;"><b>Nombre interno</b></td><td>Toborochi</td></tr>
          <tr><td><b>Alcance técnico</b></td><td>Migración / actualización de Oracle EBS de la versión R12.1.3 a R12.2.15</td></tr>
          <tr><td><b>Kick Off</b></td><td>19/08/2026</td></tr>
          <tr><td><b>Entrega (Go-Live)</b></td><td>${c.fechaEntregaFinal?fmtDate(c.fechaEntregaFinal):"Por confirmar"}</td></tr>
          <tr><td><b>Empresas en alcance</b></td><td>Sofía, Agrosofía (MamayaTech / Indatta) y PASSA</td></tr>
          <tr><td><b>Fuera de alcance</b></td><td>EBS Clientes de Servicio, archiving, tuning de reportes y mejoras evolutivas</td></tr>
          <tr><td><b>Freeze de desarrollos</b></td><td>EBS y satélites en freeze desde julio de 2026; los proyectos no Core siguen su roadmap sin comprometer la ventana de upgrade</td></tr>
        </tbody>
      </table></div>
    </div>
    <div class="card panel">
      <h3>Colaboradores del upgrade EBS R12.2.15</h3>
      <div class="tablewrap"><table>
        <thead><tr><th>Equipo / proveedor</th><th>Alcance técnico</th></tr></thead>
        <tbody>
          <tr><td><b>MamayaTech</b></td><td>Remediación de objetos CEMLIs</td></tr>
          <tr><td><b>Consultores Mexicanos 4CE</b></td><td>Remediación capa MIT, desarrollos e integraciones</td></tr>
          <tr><td><b>Consultores Argentinos EDA</b></td><td>Objetos Pandora</td></tr>
          <tr><td><b>APPS DBA</b></td><td>Especializados en actualización técnica de sistemas EBS</td></tr>
        </tbody>
      </table></div>
    </div>
  `;
}

function viewTecCronograma(){
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico</div>
      <h2>Cronograma</h2>
      <p>Roadmap oficial del proyecto y el detalle operativo de las 306 tareas del export de ClickUp, con búsqueda, filtros y detalle por tarea.</p>
    </div>
    <div class="card panel">
      <div style="overflow-x:auto;">
        <img src="data:image/png;base64,${ROADMAP_IMG_B64}" alt="Cronograma integrado del proyecto — roadmap oficial" style="display:block; width:100%; min-width:900px; border-radius:10px; border:1px solid var(--border);">
      </div>
    </div>
    <div class="card panel">
      <h3>Cronograma detallado (export ClickUp)</h3>
      ${interactiveGanttHTML("igt")}
    </div>
  `;
}

function viewTecGanttPersona(){
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico</div>
      <h2>Gantt por persona</h2>
      <p>Mismo detalle operativo del export de ClickUp (306 tareas), filtrado por responsable: cada persona ve solo las tareas que tiene asignadas.</p>
    </div>
    <div class="card panel">
      ${personGanttHTML("pg")}
    </div>
  `;
}

function viewTecEDT(){
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico</div>
      <h2>EDT gráfico</h2>
      <p>Estructura de desglose del trabajo (fases → tareas) tal como viene del export de ClickUp: 22 fases de nivel superior y 306 nodos en total. Clic para expandir cada fase.</p>
    </div>
    <div class="card panel">
      <div class="edttree">
        ${TREE_TECNICO.map(n=>edtNodeHTML(n,0)).join("")}
      </div>
    </div>
  `;
}

function viewTecRiesgos(){
  const codigosTec = ["F1","F2"]; // F1 Upgrade Técnico EBS, F2 Remediación CEMLIs/MIT/Pandora — los dos frentes técnicos
  const riesgos = STATE.collections.riesgos.filter(r=>codigosTec.includes(r.frenteCodigo))
    .sort((a,b)=>riskLevel(b.probabilidad,b.impacto).score-riskLevel(a.probabilidad,a.impacto).score);
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico</div>
      <h2>Riesgos del equipo técnico</h2>
      <p>Riesgos de la matriz del proyecto vinculados a los dos frentes técnicos (Upgrade Técnico EBS y Remediación CEMLIs/MIT/Pandora). El registro completo de los 97 riesgos vive en el Comité Ejecutivo.</p>
    </div>
    <div class="card panel">
      <div class="tablewrap"><table>
        <thead><tr><th>Código</th><th>Riesgo</th><th>Nivel</th><th>Estrategia</th><th>Responsable</th><th>Estado</th></tr></thead>
        <tbody>${riesgos.map(r=>{
          const lvl = riskLevel(r.probabilidad,r.impacto);
          return `<tr class="decisionrow" data-toggle="rtec-${r.id}">
            <td><span class="code">${r.codigo}</span></td>
            <td style="max-width:320px;">${r.descripcion}</td>
            <td>${riskBadge(lvl.tier)}</td>
            <td>${r.estrategia||""}</td>
            <td>${r.responsable||""}</td>
            <td>${chip(riskEstadoRag(r.estado), riskEstadoLabel(r.estado))}</td>
          </tr>
          <tr class="decisiondetail" id="rtec-${r.id}" hidden><td colspan="6">
            <div class="hint" style="margin-bottom:6px;"><b>Impacto en el negocio:</b> ${r.impactoNegocio||"—"}</div>
            <div style="font-size:12px;font-weight:700;color:var(--text-muted);margin:8px 0 4px;">PLAN DE MITIGACIÓN</div>
            <div style="font-size:13px;">${r.plan||"Sin plan registrado."}</div>
          </td></tr>`;
        }).join("") || `<tr><td colspan="6" class="hint">Sin riesgos vinculados a los frentes técnicos.</td></tr>`}</tbody>
      </table></div>
    </div>
  `;
}

function viewTecBitacora(){
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico</div>
      <h2>Bitácora — planning de lunes</h2>
      <p>Seguimiento de las reuniones semanales de planning técnico (lunes) del equipo de upgrade Mamayatech.</p>
    </div>
    <div class="pending-box">
      Todavía no hay actas cargadas acá.<br>
      Cuando compartas las actas de las reuniones de planning técnico de los lunes (o las de upgrade), las cargamos acá con fecha, temas tratados, acuerdos y pendientes de la semana.
    </div>
  `;
}

function viewTecProximos(){
  return `
    <div class="section-head">
      <div class="eyebrow">Equipo Técnico</div>
      <h2>Próximos pasos</h2>
      <p>Esta sección muestra únicamente lo que surja de las actas de upgrade del equipo técnico — no se completa con información de otras fuentes.</p>
    </div>
    <div class="pending-box">
      Todavía no hay actas de upgrade cargadas.<br>
      En cuanto las compartas, acá van a aparecer los próximos pasos tal como surgen de esas actas.
    </div>
  `;
}


const TITLES = {
  resumen:["Resumen ejecutivo","Vista general del proyecto"],
  edt:["Estructura del proyecto","EDT · curva S · SPI"],
  cronograma:["Cronograma","Plan vs. real"],
  presupuesto:["Presupuesto y contratos","Situación financiera"],
  riesgos:["Mapa de riesgos","Registro de riesgos"],
  problemas:["Problemas y bloqueos","Issue log"],
  cambios:["Control de cambios","Change log"],
  decisiones:["Decisiones del Comité","Decision log"],
  hitos:["Próximos hitos","Milestone plan"],
  minutas:["Bitácora de Comité","Actas y seguimiento"],
  backoffice:["Backoffice","Administración de datos"],
  "pmo-estado":["Estado del proyecto","PMO Integrada"],
  "pmo-dominios":["8 Dominios de desempeño","PMBOK 7 · PMO Integrada"],
  "tec-resumen":["Datos generales","Equipo Técnico"],
  "tec-cronograma":["Cronograma","Equipo Técnico"],
  "tec-gantt-persona":["Gantt por persona","Equipo Técnico · tareas por responsable"],
  "tec-edt":["EDT gráfico","Equipo Técnico · fases y tareas"],
  "tec-riesgos":["Riesgos del equipo técnico","Equipo Técnico"],
  "tec-bitacora":["Bitácora — planning de lunes","Equipo Técnico"],
  "tec-proximos":["Próximos pasos","Equipo Técnico · desde actas de upgrade"],
};

function render(){
  if(!STATE.ready) return;
  renderNav();
  const base = routeBase(STATE.route);
  const param = routeParam(STATE.route);
  let title, crumb;
  if(base==="frente"){
    const f = frenteByCodigo(param);
    title = f ? f.nombre : "Frente de trabajo";
    crumb = "Detalle de actividades" + (f?` · ${f.codigo}`:"");
  } else if(base==="pmo-dominio"){
    const d = DOMINIOS_PMBOK.find(x=>x.key===param);
    title = d ? d.nombre : "Dominio de desempeño";
    crumb = "PMO Integrada · 8 dominios (PMBOK 7)";
  } else {
    [title, crumb] = TITLES[base] || TITLES.resumen;
  }
  document.getElementById("pageTitle").textContent = title;
  document.getElementById("pageCrumb").textContent = "Toborochi · " + crumb;
  document.getElementById("updatedText").textContent = STATE.offline ? "Modo demo — sin conexión a datos en vivo" : ("Actualizado " + fmtDate(STATE.config.fechaActualizacion));
  document.getElementById("liveDot").style.background = STATE.offline ? "var(--rag-gray)" : "var(--rag-green)";

  const root = document.getElementById("viewRoot");
  const viewFns = {
    resumen:viewResumen, edt:viewEDT, cronograma:viewCronograma, presupuesto:viewPresupuesto,
    riesgos:viewRiesgos, problemas:viewProblemas, cambios:viewCambios,
    decisiones:viewDecisiones, hitos:viewHitos, minutas:viewMinutas, backoffice:viewBackoffice,
    "pmo-estado":viewPMOEstado, "pmo-dominios":viewPMODominios,
    "tec-resumen":viewTecResumen, "tec-cronograma":viewTecCronograma, "tec-gantt-persona":viewTecGanttPersona, "tec-edt":viewTecEDT,
    "tec-riesgos":viewTecRiesgos, "tec-bitacora":viewTecBitacora, "tec-proximos":viewTecProximos,
  };
  if(base==="frente"){
    root.innerHTML = viewFrenteDetalle(param);
  } else if(base==="pmo-dominio"){
    root.innerHTML = viewPMODominioDetalle(param);
  } else {
    const fn = viewFns[base] || viewResumen;
    root.innerHTML = fn();
  }

  if(base==="backoffice" && !STATE.backofficeUnlocked){
    const bofForm = document.getElementById("bofPassForm");
    if(bofForm) bofForm.addEventListener("submit", (e)=>{
      e.preventDefault();
      const val = document.getElementById("bofPassInput").value;
      if(val === "coco"){
        STATE.backofficeUnlocked = true;
        try{ sessionStorage.setItem("toborochi_backoffice_unlocked", "1"); }catch(e){}
        render();
      } else {
        const err = document.getElementById("bofPassError");
        if(err) err.hidden = false;
        document.getElementById("bofPassInput").focus();
      }
    });
  } else if(base==="backoffice" && (STATE.isAdmin||STATE.offline)){
    document.querySelectorAll("[data-atab]").forEach(b=>b.addEventListener("click", ()=>{ adminTab=b.dataset.atab; editingId=null; render(); }));
    renderAdminBody();
  }
  if(base==="cronograma"){ mountInteractiveGantt("igc"); bindPMGantt({editable:false, panelId:"pmgRiskPanel"}); }
  if(base==="tec-cronograma") mountInteractiveGantt("igt");
  if(base==="tec-gantt-persona") mountPersonGantt("pg");
}


/* ---------------------------------------------------------------------
   9) ARRANQUE
--------------------------------------------------------------------- */

(function boot(){
  initLogin();
  const initialRoute = location.hash.replace("#","");
  if(STATE.role){
    STATE.route = initialRoute || ROLE_DEFAULT_ROUTE[STATE.role] || "resumen";
  } else if(initialRoute){
    STATE.route = initialRoute; // se aplica recién después del login
  }
  initData();
})();
