# Dashboard Ejecutivo Toborochi — Versión standalone

Esta es una copia **standalone** (independiente) del Dashboard Ejecutivo del
proyecto Toborochi: corre por completo en el navegador, sin depender de
Claude ni de la conexión a internet, y guarda los datos en este mismo
dispositivo.

## Cómo abrirla

Hacé doble clic en `index.html`. Se abre en tu navegador (Chrome, Edge,
Firefox) como cualquier página web. No necesita instalación ni servidor.

## Qué diferencia tiene con el Artifact publicado en claude.ai

| | Artifact (claude.ai) | Esta versión standalone |
|---|---|---|
| Dónde vive el dashboard | En la nube, con un link para compartir | En este dispositivo, como carpeta de archivos |
| Dónde se guardan los datos | Base de datos en vivo de Claude, compartida con todos los que abren el link | En este navegador (localStorage), sólo en esta computadora |
| Quién ve tus cambios | Cualquiera con el link, en tiempo real | Sólo vos, en este navegador |
| Funciona sin internet | No | Sí (salvo la tipografía de Google Fonts, que es un detalle visual — sin internet usa una tipografía de reemplazo) |

**Recomendación:** para el trabajo del día a día con el Comité, seguí usando
el Artifact publicado (es el que se comparte y se actualiza para todos). Usá
esta versión standalone como respaldo — por ejemplo, para tener el tablero
disponible sin conexión, para una demo local, o como copia de resguardo de
la información.

## Estructura de archivos

```
version-standalone/
├── index.html              ← abrí este archivo
├── css/
│   └── styles.css          ← estilos visuales (front-end)
├── js/
│   ├── app.js               ← lógica de la aplicación: vistas, Gantt, EDT,
│   │                          Backoffice, etc. (front-end)
│   ├── backend.js           ← capa de datos: guarda/lee/borra registros,
│   │                          registro de auditoría (back-end)
│   └── database-seed.js     ← datos de referencia con los que arranca la
│                               base la primera vez ("base de datos" inicial)
└── README.md                ← este archivo
```

Front (`app.js` + `index.html` + `css/`), back (`backend.js`) y base de
datos (`database-seed.js`, más lo que vos cargues después en localStorage)
están separados en archivos distintos, tal como se pidió.

## Contraseñas (las mismas que en el Artifact)

- Comité Ejecutivo: `toborochi`
- PMO Integrada: `proyectos`
- Equipo Técnico: `1234`
- Backoffice (edición de datos): `coco`

Igual que en el Artifact, esto es sólo un filtro simple para separar qué ve
cada audiencia — no es una medida de seguridad real. Cualquiera que abra
este archivo puede editar el Backoffice si conoce (o adivina) la contraseña.

## Cómo se guardan los cambios

Todo lo que cargues desde el Backoffice (frentes, cronograma, riesgos,
contratos, etc.) se guarda automáticamente en el `localStorage` de tu
navegador, en este dispositivo. Eso significa:

- Los cambios quedan guardados aunque cierres y vuelvas a abrir el archivo,
  **en el mismo navegador**.
- Si abrís `index.html` en otro navegador, o en otra computadora, vas a ver
  los datos de referencia originales (`database-seed.js`), no tus cambios.
- Si borrás el historial/datos de navegación de este sitio, se borra la
  base local.
- No hay sincronización con el Artifact publicado en claude.ai: son dos
  bases de datos independientes. Si querés que un cambio quede también en
  el Artifact compartido con el Comité, hacelo ahí directamente.

## Registro de ediciones

Backoffice → "Reporte de ediciones" muestra el historial de cambios
manuales (qué se cambió, cuándo y en qué sección), igual que en el
Artifact.

## Sesión

Por seguridad en pantallas compartidas, la sesión vuelve sola a la pantalla
de login después de 2 minutos sin actividad — igual que en el Artifact.
